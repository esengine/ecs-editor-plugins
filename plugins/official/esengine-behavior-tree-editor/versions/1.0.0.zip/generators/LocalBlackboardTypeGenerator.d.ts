/**
 * 局部黑板变量信息
 */
export interface LocalBlackboardVariable {
    name: string;
    type: string;
    value: any;
}
/**
 * 局部黑板类型生成配置
 */
export interface LocalTypeGenerationOptions {
    /** 行为树名称 */
    behaviorTreeName: string;
    /** 是否生成常量枚举 */
    includeConstants?: boolean;
    /** 是否生成默认值 */
    includeDefaults?: boolean;
    /** 是否生成辅助函数 */
    includeHelpers?: boolean;
    /** 使用单引号还是双引号 */
    quoteStyle?: 'single' | 'double';
}
/**
 * 局部黑板 TypeScript 类型生成器
 *
 * 为行为树的局部黑板变量生成类型安全的 TypeScript 定义
 */
export declare class LocalBlackboardTypeGenerator {
    /**
     * 生成局部黑板的 TypeScript 类型定义
     *
     * @param variables 黑板变量列表
     * @param options 生成配置
     * @returns TypeScript 代码
     */
    static generate(variables: Record<string, any>, options: LocalTypeGenerationOptions): string;
    /**
     * 推断 TypeScript 类型
     */
    private static inferType;
    /**
     * 格式化值为 TypeScript 字面量
     */
    private static formatValue;
    /**
     * 转换为 UPPER_SNAKE_CASE
     */
    private static toConstantName;
    /**
     * 转换为 PascalCase
     */
    private static toPascalCase;
}
//# sourceMappingURL=LocalBlackboardTypeGenerator.d.ts.map