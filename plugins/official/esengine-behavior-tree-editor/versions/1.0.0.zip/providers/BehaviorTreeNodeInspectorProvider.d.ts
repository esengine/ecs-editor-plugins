import React from 'react';
import { IInspectorProvider, InspectorContext } from '@esengine/editor-core';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
/**
 * 行为树节点Inspector提供器
 * 为行为树节点提供检视面板
 */
export declare class BehaviorTreeNodeInspectorProvider implements IInspectorProvider<BehaviorTreeNode> {
    readonly id = "behavior-tree-node-inspector";
    readonly name = "\u884C\u4E3A\u6811\u8282\u70B9\u68C0\u89C6\u5668";
    readonly priority = 100;
    canHandle(target: unknown): target is BehaviorTreeNode;
    render(node: BehaviorTreeNode, context: InspectorContext): React.ReactElement;
}
//# sourceMappingURL=BehaviorTreeNodeInspectorProvider.d.ts.map