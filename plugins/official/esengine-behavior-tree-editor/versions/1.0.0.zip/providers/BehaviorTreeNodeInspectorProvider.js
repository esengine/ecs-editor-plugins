import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Node as BehaviorTreeNode } from '../domain/models/Node';
/**
 * 行为树节点Inspector提供器
 * 为行为树节点提供检视面板
 */
export class BehaviorTreeNodeInspectorProvider {
    constructor() {
        this.id = 'behavior-tree-node-inspector';
        this.name = '行为树节点检视器';
        this.priority = 100;
    }
    canHandle(target) {
        return target instanceof BehaviorTreeNode ||
            (typeof target === 'object' &&
                target !== null &&
                'template' in target &&
                'data' in target &&
                'position' in target &&
                'children' in target);
    }
    render(node, context) {
        return (_jsxs("div", { className: "entity-inspector", children: [_jsx("div", { className: "inspector-header", children: _jsx("span", { className: "entity-name", children: node.template.displayName || '未命名节点' }) }), _jsxs("div", { className: "inspector-content", children: [_jsxs("div", { className: "inspector-section", children: [_jsx("div", { className: "section-title", children: "\u57FA\u672C\u4FE1\u606F" }), _jsxs("div", { className: "property-field", children: [_jsx("label", { className: "property-label", children: "\u8282\u70B9\u7C7B\u578B" }), _jsx("span", { className: "property-value-text", children: node.template.type })] }), _jsxs("div", { className: "property-field", children: [_jsx("label", { className: "property-label", children: "\u5206\u7C7B" }), _jsx("span", { className: "property-value-text", children: node.template.category })] }), node.template.description && (_jsxs("div", { className: "property-field", children: [_jsx("label", { className: "property-label", children: "\u63CF\u8FF0" }), _jsx("span", { className: "property-value-text", style: { color: '#999' }, children: node.template.description })] }))] }), _jsxs("div", { className: "inspector-section", children: [_jsx("div", { className: "section-title", children: "\u8C03\u8BD5\u4FE1\u606F" }), _jsxs("div", { className: "property-field", children: [_jsx("label", { className: "property-label", children: "\u8282\u70B9ID" }), _jsx("span", { className: "property-value-text", style: {
                                                fontFamily: 'Consolas, Monaco, monospace',
                                                color: '#666',
                                                fontSize: '11px'
                                            }, children: node.id })] }), _jsxs("div", { className: "property-field", children: [_jsx("label", { className: "property-label", children: "\u4F4D\u7F6E" }), _jsxs("span", { className: "property-value-text", style: { color: '#999' }, children: ["(", node.position.x.toFixed(0), ", ", node.position.y.toFixed(0), ")"] })] })] })] })] }));
    }
}
//# sourceMappingURL=BehaviorTreeNodeInspectorProvider.js.map