var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { singleton } from 'tsyringe';
import { useBehaviorTreeDataStore } from '../application/state/BehaviorTreeDataStore';
import { useTreeStore } from '../stores';
let BehaviorTreeService = class BehaviorTreeService {
    async createNew() {
        useTreeStore.getState().reset();
        useBehaviorTreeDataStore.getState().reset();
    }
    async loadFromFile(filePath) {
        console.log('[BehaviorTreeService] Loading tree from:', filePath);
    }
    async saveToFile(filePath) {
        console.log('[BehaviorTreeService] Saving tree to:', filePath);
    }
    getCurrentTree() {
        return useBehaviorTreeDataStore.getState().tree;
    }
    setTree(tree) {
        useBehaviorTreeDataStore.getState().setTree(tree);
    }
};
BehaviorTreeService = __decorate([
    singleton()
], BehaviorTreeService);
export { BehaviorTreeService };
//# sourceMappingURL=BehaviorTreeService.js.map