var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { singleton } from 'tsyringe';
import { Core } from '@esengine/ecs-framework';
import { CompilerRegistry } from '@esengine/editor-core';
import { BehaviorTreeService } from './services/BehaviorTreeService';
import { BehaviorTreeCompiler } from './compiler/BehaviorTreeCompiler';
import { BehaviorTreeNodeInspectorProvider } from './providers/BehaviorTreeNodeInspectorProvider';
let BehaviorTreeModule = class BehaviorTreeModule {
    constructor() {
        this.id = 'behavior-tree';
        this.name = 'Behavior Tree Editor';
        this.version = '1.0.0';
    }
    async load(context) {
        console.log('[BehaviorTreeModule] Loading behavior tree editor module...');
        this.registerServices(context);
        this.registerCompilers();
        this.registerInspectors(context);
        this.registerCommands(context);
        this.registerPanels(context);
        this.subscribeEvents(context);
        console.log('[BehaviorTreeModule] Behavior tree editor module loaded');
    }
    registerServices(context) {
        context.container.register(BehaviorTreeService, { useClass: BehaviorTreeService });
        console.log('[BehaviorTreeModule] Services registered');
    }
    registerCompilers() {
        const compilerRegistry = Core.services.resolve(CompilerRegistry);
        if (compilerRegistry) {
            const compiler = new BehaviorTreeCompiler();
            compilerRegistry.register(compiler);
            console.log('[BehaviorTreeModule] Compiler registered');
        }
    }
    registerInspectors(context) {
        const provider = new BehaviorTreeNodeInspectorProvider();
        context.inspectorRegistry.register(provider);
        console.log('[BehaviorTreeModule] Inspector provider registered');
    }
    async unload() {
        console.log('[BehaviorTreeModule] Unloading behavior tree editor module...');
    }
    registerCommands(context) {
        context.commands.register({
            id: 'behavior-tree.new',
            label: 'New Behavior Tree',
            icon: 'file-plus',
            execute: async () => {
                const service = context.container.resolve(BehaviorTreeService);
                await service.createNew();
            }
        });
        context.commands.register({
            id: 'behavior-tree.open',
            label: 'Open Behavior Tree',
            icon: 'folder-open',
            execute: async () => {
                console.log('Open behavior tree');
            }
        });
        context.commands.register({
            id: 'behavior-tree.save',
            label: 'Save Behavior Tree',
            icon: 'save',
            keybinding: { key: 'S', ctrl: true },
            execute: async () => {
                console.log('Save behavior tree');
            }
        });
    }
    registerPanels(context) {
        console.log('[BehaviorTreeModule] Registering panels...');
    }
    subscribeEvents(context) {
        // 文件加载由 BehaviorTreeEditorPanel 处理
    }
};
BehaviorTreeModule = __decorate([
    singleton()
], BehaviorTreeModule);
export { BehaviorTreeModule };
//# sourceMappingURL=BehaviorTreeModule.js.map