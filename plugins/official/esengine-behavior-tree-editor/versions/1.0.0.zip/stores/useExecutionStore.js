import { create } from 'zustand';
export const useExecutionStore = create((set) => ({
    isExecuting: false,
    nodeExecutionStatuses: new Map(),
    nodeExecutionOrders: new Map(),
    setIsExecuting: (isExecuting) => set({ isExecuting }),
    setNodeExecutionStatus: (nodeId, status) => set((state) => {
        const newStatuses = new Map(state.nodeExecutionStatuses);
        newStatuses.set(nodeId, status);
        return { nodeExecutionStatuses: newStatuses };
    }),
    updateNodeExecutionStatuses: (statuses, orders) => set((state) => ({
        nodeExecutionStatuses: new Map(statuses),
        nodeExecutionOrders: orders ? new Map(orders) : state.nodeExecutionOrders
    })),
    clearNodeExecutionStatuses: () => set({
        nodeExecutionStatuses: new Map(),
        nodeExecutionOrders: new Map()
    })
}));
//# sourceMappingURL=useExecutionStore.js.map