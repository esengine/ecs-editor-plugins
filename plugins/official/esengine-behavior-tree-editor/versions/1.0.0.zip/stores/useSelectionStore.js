import { create } from 'zustand';
export const useSelectionStore = create((set) => ({
    selectedNodeIds: [],
    isBoxSelecting: false,
    boxSelectStart: null,
    boxSelectEnd: null,
    setSelectedNodeIds: (nodeIds) => set({ selectedNodeIds: nodeIds }),
    toggleNodeSelection: (nodeId) => set((state) => {
        const isSelected = state.selectedNodeIds.includes(nodeId);
        return {
            selectedNodeIds: isSelected
                ? state.selectedNodeIds.filter(id => id !== nodeId)
                : [...state.selectedNodeIds, nodeId]
        };
    }),
    clearSelection: () => set({ selectedNodeIds: [] }),
    setIsBoxSelecting: (isSelecting) => set({ isBoxSelecting: isSelecting }),
    setBoxSelectStart: (pos) => set({ boxSelectStart: pos }),
    setBoxSelectEnd: (pos) => set({ boxSelectEnd: pos }),
    clearBoxSelect: () => set({
        isBoxSelecting: false,
        boxSelectStart: null,
        boxSelectEnd: null
    })
}));
//# sourceMappingURL=useSelectionStore.js.map