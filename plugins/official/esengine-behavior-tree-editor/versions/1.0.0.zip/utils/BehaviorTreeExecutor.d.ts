import type { Node as BehaviorTreeNode } from '../domain/models/Node';
export interface ExecutionStatus {
    nodeId: string;
    status: 'running' | 'success' | 'failure' | 'idle';
    message?: string;
    executionOrder?: number;
}
export interface ExecutionLog {
    timestamp: number;
    message: string;
    level: 'info' | 'success' | 'error' | 'warning';
    nodeId?: string;
}
export type ExecutionCallback = (statuses: ExecutionStatus[], logs: ExecutionLog[], blackboardVariables?: Record<string, any>) => void;
/**
 * 行为树执行器
 *
 * 使用新的Runtime架构执行行为树
 */
export declare class BehaviorTreeExecutor {
    private world;
    private scene;
    private entity;
    private runtime;
    private treeData;
    private callback;
    private isRunning;
    private isPaused;
    private executionLogs;
    private lastStatuses;
    private persistentStatuses;
    private executionOrders;
    private tickCount;
    private nodeIdMap;
    private blackboardKeys;
    private rootNodeId;
    private assetManager;
    private executionSystem;
    constructor();
    /**
     * 从编辑器节点构建行为树数据
     */
    buildTree(nodes: BehaviorTreeNode[], rootNodeId: string, blackboard: Record<string, any>, connections: Array<{
        from: string;
        to: string;
        fromProperty?: string;
        toProperty?: string;
        connectionType: 'node' | 'property';
    }>, callback: ExecutionCallback): void;
    /**
     * 将编辑器节点转换为BehaviorTreeData
     */
    private convertToTreeData;
    /**
     * 转换节点类型
     */
    private convertNodeType;
    /**
     * 根据显示名称获取实现类型
     */
    private getImplementationType;
    /**
     * 开始执行
     */
    start(): void;
    /**
     * 暂停执行
     */
    pause(): void;
    /**
     * 恢复执行
     */
    resume(): void;
    /**
     * 停止执行
     */
    stop(): void;
    /**
     * 执行一帧
     */
    tick(deltaTime: number): void;
    /**
     * 收集所有节点的执行状态
     */
    private collectExecutionStatus;
    /**
     * 节点状态变化时记录日志
     */
    private onNodeStatusChanged;
    /**
     * 添加日志
     */
    private addLog;
    /**
     * 获取当前tick计数
     */
    getTickCount(): number;
    /**
     * 获取黑板变量
     */
    getBlackboardVariables(): Record<string, any>;
    /**
     * 更新黑板变量
     */
    updateBlackboardVariable(key: string, value: any): void;
    /**
     * 清理资源
     */
    cleanup(): void;
    /**
     * 检查节点的执行器是否存在
     */
    hasExecutor(implementationType: string): boolean;
    /**
     * 销毁
     */
    destroy(): void;
}
//# sourceMappingURL=BehaviorTreeExecutor.d.ts.map