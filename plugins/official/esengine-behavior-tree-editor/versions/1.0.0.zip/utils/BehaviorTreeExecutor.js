import { World, createLogger, Time, Core } from '@esengine/ecs-framework';
import { BehaviorTreeRuntimeComponent, BehaviorTreeAssetManager, BehaviorTreeExecutionSystem, TaskStatus, NodeType } from '@esengine/behavior-tree';
const logger = createLogger('BehaviorTreeExecutor');
/**
 * 行为树执行器
 *
 * 使用新的Runtime架构执行行为树
 */
export class BehaviorTreeExecutor {
    constructor() {
        this.entity = null;
        this.runtime = null;
        this.treeData = null;
        this.callback = null;
        this.isRunning = false;
        this.isPaused = false;
        this.executionLogs = [];
        this.lastStatuses = new Map();
        this.persistentStatuses = new Map();
        this.executionOrders = new Map();
        this.tickCount = 0;
        this.nodeIdMap = new Map();
        this.blackboardKeys = [];
        this.rootNodeId = '';
        this.world = new World({ name: 'BehaviorTreeWorld' });
        this.scene = this.world.createScene('BehaviorTreeScene');
        // 尝试获取已存在的 assetManager，如果不存在则创建新的
        try {
            this.assetManager = Core.services.resolve(BehaviorTreeAssetManager);
        }
        catch {
            this.assetManager = new BehaviorTreeAssetManager();
            Core.services.registerInstance(BehaviorTreeAssetManager, this.assetManager);
        }
        this.executionSystem = new BehaviorTreeExecutionSystem();
        this.scene.addSystem(this.executionSystem);
    }
    /**
     * 从编辑器节点构建行为树数据
     */
    buildTree(nodes, rootNodeId, blackboard, connections, callback) {
        this.cleanup();
        this.callback = callback;
        this.treeData = this.convertToTreeData(nodes, rootNodeId, blackboard, connections);
        this.rootNodeId = this.treeData.rootNodeId;
        this.assetManager.loadAsset(this.treeData);
        this.entity = this.scene.createEntity('BehaviorTreeEntity');
        this.runtime = new BehaviorTreeRuntimeComponent();
        // 在添加组件之前设置资产ID和autoStart
        this.runtime.treeAssetId = this.treeData.id;
        this.runtime.autoStart = false;
        this.entity.addComponent(this.runtime);
        if (this.treeData.blackboardVariables) {
            this.blackboardKeys = Array.from(this.treeData.blackboardVariables.keys());
            for (const [key, value] of this.treeData.blackboardVariables.entries()) {
                this.runtime.setBlackboardValue(key, value);
            }
        }
        else {
            this.blackboardKeys = [];
        }
        this.addLog('行为树构建完成', 'info');
    }
    /**
     * 将编辑器节点转换为BehaviorTreeData
     */
    convertToTreeData(nodes, rootNodeId, blackboard, connections) {
        const rootNode = nodes.find((n) => n.id === rootNodeId);
        if (!rootNode) {
            throw new Error('未找到根节点');
        }
        // 如果根节点是编辑器特有的"根节点"且只有一个子节点，使用第一个子节点作为实际根节点
        let actualRootId = rootNodeId;
        if (rootNode.template.displayName === '根节点' && rootNode.children.length === 1) {
            actualRootId = rootNode.children[0];
        }
        const treeData = {
            id: `tree_${Date.now()}`,
            name: 'EditorTree',
            rootNodeId: actualRootId,
            nodes: new Map(),
            blackboardVariables: new Map()
        };
        this.nodeIdMap.clear();
        for (const node of nodes) {
            // 跳过编辑器的虚拟根节点
            if (node.id === rootNodeId && node.template.displayName === '根节点' && rootNode.children.length === 1) {
                continue;
            }
            this.nodeIdMap.set(node.id, node.id);
            const nodeData = {
                id: node.id,
                name: node.template.displayName,
                nodeType: this.convertNodeType(node.template.type),
                implementationType: node.template.className || this.getImplementationType(node.template.displayName),
                config: { ...node.data },
                children: Array.from(node.children)
            };
            treeData.nodes.set(node.id, nodeData);
        }
        // 处理属性连接，转换为 bindings
        for (const conn of connections) {
            if (conn.connectionType === 'property' && conn.toProperty) {
                const targetNodeData = treeData.nodes.get(conn.to);
                const sourceNode = nodes.find((n) => n.id === conn.from);
                if (targetNodeData && sourceNode) {
                    // 检查源节点是否是黑板变量节点
                    if (sourceNode.data.nodeType === 'blackboard-variable') {
                        // 从黑板变量节点获取实际的变量名
                        const variableName = sourceNode.data.variableName;
                        if (variableName) {
                            // 初始化 bindings 如果不存在
                            if (!targetNodeData.bindings) {
                                targetNodeData.bindings = {};
                            }
                            // 添加绑定：属性名 -> 黑板变量名
                            targetNodeData.bindings[conn.toProperty] = variableName;
                        }
                    }
                }
            }
        }
        for (const [key, value] of Object.entries(blackboard)) {
            treeData.blackboardVariables.set(key, value);
        }
        return treeData;
    }
    /**
     * 转换节点类型
     */
    convertNodeType(type) {
        if (type === NodeType.Composite)
            return NodeType.Composite;
        if (type === NodeType.Decorator)
            return NodeType.Decorator;
        if (type === NodeType.Action)
            return NodeType.Action;
        if (type === NodeType.Condition)
            return NodeType.Condition;
        return NodeType.Action;
    }
    /**
     * 根据显示名称获取实现类型
     */
    getImplementationType(displayName) {
        const typeMap = {
            '序列': 'Sequence',
            '选择': 'Selector',
            '并行': 'Parallel',
            '并行选择': 'ParallelSelector',
            '随机序列': 'RandomSequence',
            '随机选择': 'RandomSelector',
            '反转': 'Inverter',
            '重复': 'Repeater',
            '直到成功': 'UntilSuccess',
            '直到失败': 'UntilFail',
            '总是成功': 'AlwaysSucceed',
            '总是失败': 'AlwaysFail',
            '条件装饰器': 'Conditional',
            '冷却': 'Cooldown',
            '超时': 'Timeout',
            '等待': 'Wait',
            '日志': 'Log',
            '设置变量': 'SetBlackboardValue',
            '修改变量': 'ModifyBlackboardValue',
            '自定义动作': 'ExecuteAction',
            '比较变量': 'BlackboardCompare',
            '变量存在': 'BlackboardExists',
            '随机概率': 'RandomProbability',
            '执行条件': 'ExecuteCondition'
        };
        return typeMap[displayName] || displayName;
    }
    /**
     * 开始执行
     */
    start() {
        if (!this.runtime || !this.treeData) {
            logger.error('未构建行为树');
            return;
        }
        this.isRunning = true;
        this.isPaused = false;
        this.executionLogs = [];
        this.lastStatuses.clear();
        this.persistentStatuses.clear();
        this.tickCount = 0;
        this.runtime.resetAllStates();
        this.runtime.isRunning = true;
        this.addLog('开始执行行为树', 'info');
    }
    /**
     * 暂停执行
     */
    pause() {
        this.isPaused = true;
        if (this.runtime) {
            this.runtime.isRunning = false;
        }
    }
    /**
     * 恢复执行
     */
    resume() {
        this.isPaused = false;
        if (this.runtime) {
            this.runtime.isRunning = true;
        }
    }
    /**
     * 停止执行
     */
    stop() {
        this.isRunning = false;
        this.isPaused = false;
        if (this.runtime) {
            this.runtime.isRunning = false;
            this.runtime.resetAllStates();
        }
        this.addLog('行为树已停止', 'info');
    }
    /**
     * 执行一帧
     */
    tick(deltaTime) {
        if (!this.isRunning || this.isPaused || !this.runtime) {
            return;
        }
        Time.update(deltaTime);
        this.tickCount++;
        this.scene.update();
        this.collectExecutionStatus();
    }
    /**
     * 收集所有节点的执行状态
     */
    collectExecutionStatus() {
        if (!this.callback || !this.runtime || !this.treeData)
            return;
        const rootState = this.runtime.getNodeState(this.rootNodeId);
        let rootCurrentStatus = 'idle';
        if (rootState) {
            switch (rootState.status) {
                case TaskStatus.Running:
                    rootCurrentStatus = 'running';
                    break;
                case TaskStatus.Success:
                    rootCurrentStatus = 'success';
                    break;
                case TaskStatus.Failure:
                    rootCurrentStatus = 'failure';
                    break;
                default:
                    rootCurrentStatus = 'idle';
            }
        }
        const rootLastStatus = this.lastStatuses.get(this.rootNodeId);
        if (rootLastStatus &&
            (rootLastStatus === 'success' || rootLastStatus === 'failure') &&
            rootCurrentStatus === 'running') {
            this.persistentStatuses.clear();
            this.executionOrders.clear();
        }
        const statuses = [];
        for (const [nodeId, nodeData] of this.treeData.nodes.entries()) {
            const state = this.runtime.getNodeState(nodeId);
            let currentStatus = 'idle';
            if (state) {
                switch (state.status) {
                    case TaskStatus.Success:
                        currentStatus = 'success';
                        break;
                    case TaskStatus.Failure:
                        currentStatus = 'failure';
                        break;
                    case TaskStatus.Running:
                        currentStatus = 'running';
                        break;
                    default:
                        currentStatus = 'idle';
                }
            }
            const persistentStatus = this.persistentStatuses.get(nodeId) || 'idle';
            const lastStatus = this.lastStatuses.get(nodeId);
            let displayStatus = currentStatus;
            if (currentStatus === 'running') {
                displayStatus = 'running';
                this.persistentStatuses.set(nodeId, 'running');
            }
            else if (currentStatus === 'success') {
                displayStatus = 'success';
                this.persistentStatuses.set(nodeId, 'success');
            }
            else if (currentStatus === 'failure') {
                displayStatus = 'failure';
                this.persistentStatuses.set(nodeId, 'failure');
            }
            else if (currentStatus === 'idle') {
                if (persistentStatus !== 'idle') {
                    displayStatus = persistentStatus;
                }
                else if (this.executionOrders.has(nodeId)) {
                    displayStatus = 'success';
                    this.persistentStatuses.set(nodeId, 'success');
                }
                else {
                    displayStatus = 'idle';
                }
            }
            // 检测状态变化
            const hasStateChanged = lastStatus !== currentStatus;
            // 从运行时状态读取执行顺序
            if (state?.executionOrder !== undefined && !this.executionOrders.has(nodeId)) {
                this.executionOrders.set(nodeId, state.executionOrder);
                console.log(`[ExecutionOrder READ] ${nodeData.name} | ID: ${nodeId} | Order: ${state.executionOrder}`);
            }
            // 记录状态变化日志
            if (hasStateChanged && currentStatus !== 'idle') {
                this.onNodeStatusChanged(nodeId, nodeData.name, lastStatus || 'idle', currentStatus);
            }
            this.lastStatuses.set(nodeId, currentStatus);
            statuses.push({
                nodeId,
                status: displayStatus,
                executionOrder: this.executionOrders.get(nodeId)
            });
        }
        const currentBlackboardVars = this.getBlackboardVariables();
        this.callback(statuses, this.executionLogs, currentBlackboardVars);
    }
    /**
     * 节点状态变化时记录日志
     */
    onNodeStatusChanged(nodeId, nodeName, oldStatus, newStatus) {
        if (newStatus === 'running') {
            this.addLog(`[${nodeName}](${nodeId}) 开始执行`, 'info', nodeId);
        }
        else if (newStatus === 'success') {
            this.addLog(`[${nodeName}](${nodeId}) 执行成功`, 'success', nodeId);
        }
        else if (newStatus === 'failure') {
            this.addLog(`[${nodeName}](${nodeId}) 执行失败`, 'error', nodeId);
        }
    }
    /**
     * 添加日志
     */
    addLog(message, level, nodeId) {
        this.executionLogs.push({
            timestamp: Date.now(),
            message,
            level,
            nodeId
        });
        if (this.executionLogs.length > 1000) {
            this.executionLogs.shift();
        }
    }
    /**
     * 获取当前tick计数
     */
    getTickCount() {
        return this.tickCount;
    }
    /**
     * 获取黑板变量
     */
    getBlackboardVariables() {
        if (!this.runtime)
            return {};
        const variables = {};
        for (const name of this.blackboardKeys) {
            variables[name] = this.runtime.getBlackboardValue(name);
        }
        return variables;
    }
    /**
     * 更新黑板变量
     */
    updateBlackboardVariable(key, value) {
        if (!this.runtime) {
            logger.warn('无法更新黑板变量：未构建行为树');
            return;
        }
        this.runtime.setBlackboardValue(key, value);
        logger.info(`黑板变量已更新: ${key} = ${JSON.stringify(value)}`);
    }
    /**
     * 清理资源
     */
    cleanup() {
        this.stop();
        this.nodeIdMap.clear();
        this.lastStatuses.clear();
        this.persistentStatuses.clear();
        this.blackboardKeys = [];
        if (this.entity) {
            this.entity.destroy();
            this.entity = null;
        }
        // 卸载旧的行为树资产
        if (this.treeData) {
            this.assetManager.unloadAsset(this.treeData.id);
        }
        this.runtime = null;
        this.treeData = null;
    }
    /**
     * 检查节点的执行器是否存在
     */
    hasExecutor(implementationType) {
        const registry = this.executionSystem.getExecutorRegistry();
        return registry.has(implementationType);
    }
    /**
     * 销毁
     */
    destroy() {
        this.cleanup();
    }
}
//# sourceMappingURL=BehaviorTreeExecutor.js.map