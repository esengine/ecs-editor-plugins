type NodeExecutionStatus = 'idle' | 'running' | 'success' | 'failure';
export declare class DOMCache {
    private nodeElements;
    private connectionElements;
    private lastNodeStatus;
    private statusTimers;
    getNode(nodeId: string): Element | undefined;
    getConnection(connectionKey: string): Element | undefined;
    getLastStatus(nodeId: string): NodeExecutionStatus | undefined;
    setLastStatus(nodeId: string, status: NodeExecutionStatus): void;
    hasStatusChanged(nodeId: string, newStatus: NodeExecutionStatus): boolean;
    getStatusTimer(nodeId: string): number | undefined;
    setStatusTimer(nodeId: string, timerId: number): void;
    clearStatusTimer(nodeId: string): void;
    clearAllStatusTimers(): void;
    clearNodeCache(): void;
    clearConnectionCache(): void;
    clearStatusCache(): void;
    clearAll(): void;
    removeNodeClasses(nodeId: string, ...classes: string[]): void;
    addNodeClasses(nodeId: string, ...classes: string[]): void;
    hasNodeClass(nodeId: string, className: string): boolean;
    setConnectionAttribute(connectionKey: string, attribute: string, value: string): void;
    getConnectionAttribute(connectionKey: string, attribute: string): string | null;
    forEachNode(callback: (element: Element, nodeId: string) => void): void;
    forEachConnection(callback: (element: Element, connectionKey: string) => void): void;
}
export {};
//# sourceMappingURL=DOMCache.d.ts.map