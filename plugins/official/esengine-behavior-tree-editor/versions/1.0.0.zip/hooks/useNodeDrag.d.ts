import { RefObject } from 'react';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
import { useNodeOperations } from './useNodeOperations';
interface UseNodeDragParams {
    canvasRef: RefObject<HTMLDivElement>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    nodes: BehaviorTreeNode[];
    selectedNodeIds: string[];
    draggingNodeId: string | null;
    dragStartPositions: Map<string, {
        x: number;
        y: number;
    }>;
    isDraggingNode: boolean;
    dragDelta: {
        dx: number;
        dy: number;
    };
    nodeOperations: ReturnType<typeof useNodeOperations>;
    setSelectedNodeIds: (ids: string[]) => void;
    startDragging: (nodeId: string, startPositions: Map<string, {
        x: number;
        y: number;
    }>) => void;
    stopDragging: () => void;
    setIsDraggingNode: (isDragging: boolean) => void;
    setDragDelta: (delta: {
        dx: number;
        dy: number;
    }) => void;
    setIsBoxSelecting: (isSelecting: boolean) => void;
    setBoxSelectStart: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setBoxSelectEnd: (pos: {
        x: number;
        y: number;
    } | null) => void;
    sortChildrenByPosition: () => void;
}
export declare function useNodeDrag(params: UseNodeDragParams): {
    handleNodeMouseDown: (e: React.MouseEvent, nodeId: string) => void;
    handleNodeMouseMove: (e: React.MouseEvent) => void;
    handleNodeMouseUp: () => void;
    dragOffset: {
        x: number;
        y: number;
    };
    justFinishedDragRef: import("react").MutableRefObject<boolean>;
};
export {};
//# sourceMappingURL=useNodeDrag.d.ts.map