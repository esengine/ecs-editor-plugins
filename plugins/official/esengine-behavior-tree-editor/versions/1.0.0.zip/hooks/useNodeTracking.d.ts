import { Node as BehaviorTreeNode } from '../domain/models/Node';
import { ExecutionMode } from '../application/services/ExecutionController';
interface UseNodeTrackingParams {
    nodes: BehaviorTreeNode[];
    executionMode: ExecutionMode;
}
export declare function useNodeTracking(params: UseNodeTrackingParams): {
    uncommittedNodeIds: Set<string>;
};
export {};
//# sourceMappingURL=useNodeTracking.d.ts.map