import { RefObject } from 'react';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
interface QuickCreateMenuState {
    visible: boolean;
    position: {
        x: number;
        y: number;
    };
    searchText: string;
    selectedIndex: number;
    mode: 'create' | 'replace';
    replaceNodeId: string | null;
}
interface UseCanvasMouseEventsParams {
    canvasRef: RefObject<HTMLDivElement>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    connectingFrom: string | null;
    connectingFromProperty: string | null;
    connectingToPos: {
        x: number;
        y: number;
    } | null;
    isBoxSelecting: boolean;
    boxSelectStart: {
        x: number;
        y: number;
    } | null;
    boxSelectEnd: {
        x: number;
        y: number;
    } | null;
    nodes: BehaviorTreeNode[];
    selectedNodeIds: string[];
    quickCreateMenu: QuickCreateMenuState;
    setConnectingToPos: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setIsBoxSelecting: (isSelecting: boolean) => void;
    setBoxSelectStart: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setBoxSelectEnd: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setSelectedNodeIds: (ids: string[]) => void;
    setSelectedConnection: (connection: {
        from: string;
        to: string;
    } | null) => void;
    setQuickCreateMenu: (menu: QuickCreateMenuState) => void;
    clearConnecting: () => void;
    clearBoxSelect: () => void;
    showToast?: (message: string, type: 'success' | 'error' | 'warning' | 'info', duration?: number) => void;
}
export declare function useCanvasMouseEvents(params: UseCanvasMouseEventsParams): {
    handleCanvasMouseMove: (e: React.MouseEvent) => void;
    handleCanvasMouseUp: (e: React.MouseEvent) => void;
    handleCanvasMouseDown: (e: React.MouseEvent) => void;
};
export {};
//# sourceMappingURL=useCanvasMouseEvents.d.ts.map