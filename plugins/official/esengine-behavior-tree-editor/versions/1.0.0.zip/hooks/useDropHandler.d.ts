import { RefObject } from 'react';
import { NodeTemplate } from '@esengine/behavior-tree';
import { useNodeOperations } from './useNodeOperations';
interface UseDropHandlerParams {
    canvasRef: RefObject<HTMLDivElement>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    nodeOperations: ReturnType<typeof useNodeOperations>;
    onNodeCreate?: (template: NodeTemplate, position: {
        x: number;
        y: number;
    }) => void;
    isDraggingNode?: boolean;
}
export declare function useDropHandler(params: UseDropHandlerParams): {
    isDragging: boolean;
    handleDrop: (e: React.DragEvent) => void;
    handleDragOver: (e: React.DragEvent) => void;
    handleDragLeave: (e: React.DragEvent) => void;
    handleDragEnter: (e: React.DragEvent) => void;
};
export {};
//# sourceMappingURL=useDropHandler.d.ts.map