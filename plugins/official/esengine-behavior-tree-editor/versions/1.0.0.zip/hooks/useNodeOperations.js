import { useCallback, useMemo } from 'react';
import { TreeStateAdapter } from '../application/state/BehaviorTreeDataStore';
import { CreateNodeUseCase } from '../application/use-cases/CreateNodeUseCase';
import { DeleteNodeUseCase } from '../application/use-cases/DeleteNodeUseCase';
import { MoveNodeUseCase } from '../application/use-cases/MoveNodeUseCase';
import { UpdateNodeDataUseCase } from '../application/use-cases/UpdateNodeDataUseCase';
/**
 * 节点操作 Hook
 */
export function useNodeOperations(nodeFactory, validator, commandManager) {
    const treeState = useMemo(() => new TreeStateAdapter(), []);
    const createNodeUseCase = useMemo(() => new CreateNodeUseCase(nodeFactory, commandManager, treeState), [nodeFactory, commandManager, treeState]);
    const deleteNodeUseCase = useMemo(() => new DeleteNodeUseCase(commandManager, treeState), [commandManager, treeState]);
    const moveNodeUseCase = useMemo(() => new MoveNodeUseCase(commandManager, treeState), [commandManager, treeState]);
    const updateNodeDataUseCase = useMemo(() => new UpdateNodeDataUseCase(commandManager, treeState), [commandManager, treeState]);
    const createNode = useCallback((template, position, data) => {
        return createNodeUseCase.execute(template, position, data);
    }, [createNodeUseCase]);
    const createNodeByType = useCallback((nodeType, position, data) => {
        return createNodeUseCase.executeByType(nodeType, position, data);
    }, [createNodeUseCase]);
    const deleteNode = useCallback((nodeId) => {
        deleteNodeUseCase.execute(nodeId);
    }, [deleteNodeUseCase]);
    const deleteNodes = useCallback((nodeIds) => {
        deleteNodeUseCase.executeBatch(nodeIds);
    }, [deleteNodeUseCase]);
    const moveNode = useCallback((nodeId, position) => {
        moveNodeUseCase.execute(nodeId, position);
    }, [moveNodeUseCase]);
    const moveNodes = useCallback((moves) => {
        moveNodeUseCase.executeBatch(moves);
    }, [moveNodeUseCase]);
    const updateNodeData = useCallback((nodeId, data) => {
        updateNodeDataUseCase.execute(nodeId, data);
    }, [updateNodeDataUseCase]);
    return useMemo(() => ({
        createNode,
        createNodeByType,
        deleteNode,
        deleteNodes,
        moveNode,
        moveNodes,
        updateNodeData
    }), [createNode, createNodeByType, deleteNode, deleteNodes, moveNode, moveNodes, updateNodeData]);
}
//# sourceMappingURL=useNodeOperations.js.map