import { Node as BehaviorTreeNode } from '../domain/models/Node';
interface ContextMenuState {
    visible: boolean;
    position: {
        x: number;
        y: number;
    };
    nodeId: string | null;
}
export declare function useContextMenu(): {
    contextMenu: ContextMenuState;
    setContextMenu: import("react").Dispatch<import("react").SetStateAction<ContextMenuState>>;
    handleNodeContextMenu: (e: React.MouseEvent, node: BehaviorTreeNode) => void;
    handleCanvasContextMenu: (e: React.MouseEvent) => void;
    closeContextMenu: () => void;
};
export {};
//# sourceMappingURL=useContextMenu.d.ts.map