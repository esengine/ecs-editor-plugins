import { MutableRefObject } from 'react';
import { Node } from '../domain/models/Node';
import { NodeTemplate } from '@esengine/behavior-tree';
type BehaviorTreeNode = Node;
interface UseEditorHandlersParams {
    isDraggingNode: boolean;
    selectedNodeIds: string[];
    setSelectedNodeIds: (ids: string[]) => void;
    setNodes: (nodes: Node[]) => void;
    setConnections: (connections: any[]) => void;
    resetView: () => void;
    triggerForceUpdate: () => void;
    onNodeSelect?: (node: BehaviorTreeNode) => void;
    rootNodeId: string;
    rootNodeTemplate: NodeTemplate;
    justFinishedDragRef: MutableRefObject<boolean>;
}
export declare function useEditorHandlers(params: UseEditorHandlersParams): {
    handleNodeClick: (e: React.MouseEvent, node: BehaviorTreeNode) => void;
    handleResetView: () => void;
    handleClearCanvas: () => Promise<void>;
};
export {};
//# sourceMappingURL=useEditorHandlers.d.ts.map