import { Connection } from '../stores/behaviorTreeStore';
import { useNodeOperations } from './useNodeOperations';
import { useConnectionOperations } from './useConnectionOperations';
interface UseKeyboardShortcutsParams {
    selectedNodeIds: string[];
    selectedConnection: {
        from: string;
        to: string;
    } | null;
    connections: Connection[];
    nodeOperations: ReturnType<typeof useNodeOperations>;
    connectionOperations: ReturnType<typeof useConnectionOperations>;
    setSelectedNodeIds: (ids: string[]) => void;
    setSelectedConnection: (connection: {
        from: string;
        to: string;
    } | null) => void;
}
export declare function useKeyboardShortcuts(params: UseKeyboardShortcutsParams): void;
export {};
//# sourceMappingURL=useKeyboardShortcuts.d.ts.map