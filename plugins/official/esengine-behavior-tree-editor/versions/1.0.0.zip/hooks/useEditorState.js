import { useRef, useState } from 'react';
export function useEditorState() {
    const canvasRef = useRef(null);
    const stopExecutionRef = useRef(null);
    const executorRef = useRef(null);
    const [selectedConnection, setSelectedConnection] = useState(null);
    return {
        canvasRef,
        stopExecutionRef,
        executorRef,
        selectedConnection,
        setSelectedConnection
    };
}
//# sourceMappingURL=useEditorState.js.map