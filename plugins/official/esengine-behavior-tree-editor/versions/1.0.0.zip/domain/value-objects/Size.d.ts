/**
 * 尺寸值对象
 * 表示宽度和高度
 */
export declare class Size {
    private readonly _width;
    private readonly _height;
    constructor(width: number, height: number);
    get width(): number;
    get height(): number;
    /**
     * 获取面积
     */
    get area(): number;
    /**
     * 缩放尺寸
     */
    scale(factor: number): Size;
    /**
     * 值对象相等性比较
     */
    equals(other: Size): boolean;
    /**
     * 转换为普通对象
     */
    toObject(): {
        width: number;
        height: number;
    };
    /**
     * 从普通对象创建
     */
    static fromObject(obj: {
        width: number;
        height: number;
    }): Size;
}
//# sourceMappingURL=Size.d.ts.map