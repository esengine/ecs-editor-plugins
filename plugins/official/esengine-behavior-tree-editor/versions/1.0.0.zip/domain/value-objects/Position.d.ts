/**
 * 位置值对象
 * 表示二维空间中的坐标点
 */
export declare class Position {
    private readonly _x;
    private readonly _y;
    constructor(x: number, y: number);
    get x(): number;
    get y(): number;
    /**
     * 创建新的位置，加上偏移量
     */
    add(offset: Position): Position;
    /**
     * 创建新的位置，减去偏移量
     */
    subtract(other: Position): Position;
    /**
     * 计算到另一个位置的距离
     */
    distanceTo(other: Position): number;
    /**
     * 值对象相等性比较
     */
    equals(other: Position): boolean;
    /**
     * 转换为普通对象
     */
    toObject(): {
        x: number;
        y: number;
    };
    /**
     * 从普通对象创建
     */
    static fromObject(obj: {
        x: number;
        y: number;
    }): Position;
    /**
     * 创建零位置
     */
    static zero(): Position;
}
//# sourceMappingURL=Position.d.ts.map