import { DomainError } from './DomainError';
/**
 * 节点未找到错误
 */
export declare class NodeNotFoundError extends DomainError {
    readonly nodeId: string;
    constructor(nodeId: string);
}
//# sourceMappingURL=NodeNotFoundError.d.ts.map