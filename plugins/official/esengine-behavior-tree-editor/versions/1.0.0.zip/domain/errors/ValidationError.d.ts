import { DomainError } from './DomainError';
/**
 * 验证错误
 * 当业务规则验证失败时抛出
 */
export declare class ValidationError extends DomainError {
    readonly field?: string | undefined;
    readonly value?: unknown | undefined;
    constructor(message: string, field?: string | undefined, value?: unknown | undefined);
    static rootNodeMaxChildren(): ValidationError;
    static decoratorNodeMaxChildren(): ValidationError;
    static leafNodeNoChildren(): ValidationError;
    static circularReference(nodeId: string): ValidationError;
    static invalidConnection(from: string, to: string, reason: string): ValidationError;
}
//# sourceMappingURL=ValidationError.d.ts.map