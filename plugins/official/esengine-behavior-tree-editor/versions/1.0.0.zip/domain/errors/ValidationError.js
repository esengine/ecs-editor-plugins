import { DomainError } from './DomainError';
/**
 * 验证错误
 * 当业务规则验证失败时抛出
 */
export class ValidationError extends DomainError {
    constructor(message, field, value) {
        super(message);
        this.field = field;
        this.value = value;
    }
    static rootNodeMaxChildren() {
        return new ValidationError('根节点只能连接一个子节点', 'children');
    }
    static decoratorNodeMaxChildren() {
        return new ValidationError('装饰节点只能连接一个子节点', 'children');
    }
    static leafNodeNoChildren() {
        return new ValidationError('叶子节点不能有子节点', 'children');
    }
    static circularReference(nodeId) {
        return new ValidationError(`检测到循环引用，节点 ${nodeId} 不能连接到自己或其子节点`, 'connection', nodeId);
    }
    static invalidConnection(from, to, reason) {
        return new ValidationError(`无效的连接：${reason}`, 'connection', { from, to });
    }
}
//# sourceMappingURL=ValidationError.js.map