export { TreeValidator } from './TreeValidator';
//# sourceMappingURL=index.js.map