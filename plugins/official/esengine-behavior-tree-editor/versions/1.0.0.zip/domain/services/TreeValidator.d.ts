import { BehaviorTree } from '../models/BehaviorTree';
import { Node } from '../models/Node';
import { Connection } from '../models/Connection';
import { IValidator, ValidationResult } from '../interfaces/IValidator';
/**
 * 行为树验证服务
 * 实现所有业务验证规则
 */
export declare class TreeValidator implements IValidator {
    /**
     * 验证整个行为树
     */
    validateTree(tree: BehaviorTree): ValidationResult;
    /**
     * 验证节点
     */
    validateNode(node: Node): ValidationResult;
    /**
     * 验证连接
     */
    validateConnection(connection: Connection, tree: BehaviorTree): ValidationResult;
    /**
     * 验证是否存在循环引用
     */
    validateNoCycles(tree: BehaviorTree): ValidationResult;
}
//# sourceMappingURL=TreeValidator.d.ts.map