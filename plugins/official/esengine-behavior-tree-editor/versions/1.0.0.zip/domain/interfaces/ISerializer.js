export {};
//# sourceMappingURL=ISerializer.js.map