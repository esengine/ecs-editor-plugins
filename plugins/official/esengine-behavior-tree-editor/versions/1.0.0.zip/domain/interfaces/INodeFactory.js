export {};
//# sourceMappingURL=INodeFactory.js.map