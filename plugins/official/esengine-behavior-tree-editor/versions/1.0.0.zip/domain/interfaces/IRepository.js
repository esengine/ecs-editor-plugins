export {};
//# sourceMappingURL=IRepository.js.map