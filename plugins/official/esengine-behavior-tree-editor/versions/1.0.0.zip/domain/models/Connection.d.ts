/**
 * 连接类型
 */
export type ConnectionType = 'node' | 'property';
/**
 * 连接领域实体
 * 表示两个节点之间的连接关系
 */
export declare class Connection {
    private readonly _from;
    private readonly _to;
    private readonly _fromProperty?;
    private readonly _toProperty?;
    private readonly _connectionType;
    constructor(from: string, to: string, connectionType?: ConnectionType, fromProperty?: string, toProperty?: string);
    get from(): string;
    get to(): string;
    get fromProperty(): string | undefined;
    get toProperty(): string | undefined;
    get connectionType(): ConnectionType;
    /**
     * 检查是否为节点连接
     */
    isNodeConnection(): boolean;
    /**
     * 检查是否为属性连接
     */
    isPropertyConnection(): boolean;
    /**
     * 检查连接是否匹配指定的条件
     */
    matches(from: string, to: string, fromProperty?: string, toProperty?: string): boolean;
    /**
     * 相等性比较
     */
    equals(other: Connection): boolean;
    /**
     * 转换为普通对象
     */
    toObject(): {
        from: string;
        to: string;
        fromProperty?: string;
        toProperty?: string;
        connectionType: ConnectionType;
    };
    /**
     * 从普通对象创建连接
     */
    static fromObject(obj: {
        from: string;
        to: string;
        fromProperty?: string;
        toProperty?: string;
        connectionType: ConnectionType;
    }): Connection;
}
//# sourceMappingURL=Connection.d.ts.map