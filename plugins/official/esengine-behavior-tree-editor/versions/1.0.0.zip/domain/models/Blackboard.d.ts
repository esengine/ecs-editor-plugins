/**
 * 黑板值类型
 */
export type BlackboardValue = string | number | boolean | null | undefined | Record<string, unknown> | unknown[];
/**
 * 黑板领域实体
 * 管理行为树的全局变量
 */
export declare class Blackboard {
    private _variables;
    constructor(variables?: Record<string, BlackboardValue>);
    /**
     * 获取变量值
     */
    get(key: string): BlackboardValue;
    /**
     * 设置变量值
     */
    set(key: string, value: BlackboardValue): Blackboard;
    /**
     * 设置变量值（别名方法）
     */
    setValue(key: string, value: BlackboardValue): void;
    /**
     * 删除变量
     */
    delete(key: string): Blackboard;
    /**
     * 检查变量是否存在
     */
    has(key: string): boolean;
    /**
     * 获取所有变量名
     */
    keys(): string[];
    /**
     * 获取所有变量
     */
    getAll(): Record<string, BlackboardValue>;
    /**
     * 批量设置变量
     */
    setAll(variables: Record<string, BlackboardValue>): Blackboard;
    /**
     * 清空所有变量
     */
    clear(): Blackboard;
    /**
     * 获取变量数量
     */
    size(): number;
    /**
     * 克隆黑板
     */
    clone(): Blackboard;
    /**
     * 转换为普通对象
     */
    toObject(): Record<string, BlackboardValue>;
    /**
     * 从普通对象创建黑板
     */
    static fromObject(obj: Record<string, unknown>): Blackboard;
    /**
     * 创建空黑板
     */
    static empty(): Blackboard;
}
//# sourceMappingURL=Blackboard.d.ts.map