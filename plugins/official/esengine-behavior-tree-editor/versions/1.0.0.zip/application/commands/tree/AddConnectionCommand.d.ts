import { Connection } from '../../../domain/models/Connection';
import { BaseCommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 添加连接命令
 */
export declare class AddConnectionCommand extends BaseCommand {
    private readonly state;
    private readonly connection;
    constructor(state: ITreeState, connection: Connection);
    execute(): void;
    undo(): void;
    getDescription(): string;
}
//# sourceMappingURL=AddConnectionCommand.d.ts.map