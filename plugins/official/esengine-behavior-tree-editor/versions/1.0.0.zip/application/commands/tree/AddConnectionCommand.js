import { BaseCommand } from '@esengine/editor-core';
/**
 * 添加连接命令
 */
export class AddConnectionCommand extends BaseCommand {
    constructor(state, connection) {
        super();
        this.state = state;
        this.connection = connection;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.addConnection(this.connection);
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.removeConnection(this.connection.from, this.connection.to, this.connection.fromProperty, this.connection.toProperty);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `添加连接: ${this.connection.from} -> ${this.connection.to}`;
    }
}
//# sourceMappingURL=AddConnectionCommand.js.map