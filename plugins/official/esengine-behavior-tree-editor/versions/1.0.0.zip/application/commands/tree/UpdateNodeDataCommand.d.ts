import { BaseCommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 更新节点数据命令
 */
export declare class UpdateNodeDataCommand extends BaseCommand {
    private readonly state;
    private readonly nodeId;
    private readonly newData;
    private oldData;
    constructor(state: ITreeState, nodeId: string, newData: Record<string, unknown>);
    execute(): void;
    undo(): void;
    getDescription(): string;
}
//# sourceMappingURL=UpdateNodeDataCommand.d.ts.map