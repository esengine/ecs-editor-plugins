import { BaseCommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 移除连接命令
 */
export declare class RemoveConnectionCommand extends BaseCommand {
    private readonly state;
    private readonly from;
    private readonly to;
    private readonly fromProperty?;
    private readonly toProperty?;
    private removedConnection;
    constructor(state: ITreeState, from: string, to: string, fromProperty?: string | undefined, toProperty?: string | undefined);
    execute(): void;
    undo(): void;
    getDescription(): string;
}
//# sourceMappingURL=RemoveConnectionCommand.d.ts.map