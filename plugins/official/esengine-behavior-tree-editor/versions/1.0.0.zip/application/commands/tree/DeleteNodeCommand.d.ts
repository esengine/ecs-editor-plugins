import { BaseCommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 删除节点命令
 */
export declare class DeleteNodeCommand extends BaseCommand {
    private readonly state;
    private readonly nodeId;
    private deletedNode;
    constructor(state: ITreeState, nodeId: string);
    execute(): void;
    undo(): void;
    getDescription(): string;
}
//# sourceMappingURL=DeleteNodeCommand.d.ts.map