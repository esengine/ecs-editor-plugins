import { Position } from '../../../domain/value-objects/Position';
import { BaseCommand, ICommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 移动节点命令
 * 支持合并连续的移动操作
 */
export declare class MoveNodeCommand extends BaseCommand {
    private readonly state;
    private readonly nodeId;
    private readonly newPosition;
    private oldPosition;
    constructor(state: ITreeState, nodeId: string, newPosition: Position);
    execute(): void;
    undo(): void;
    getDescription(): string;
    /**
     * 移动命令可以合并
     */
    canMergeWith(other: ICommand): boolean;
    /**
     * 合并移动命令
     * 保留初始位置，更新最终位置
     */
    mergeWith(other: ICommand): ICommand;
}
//# sourceMappingURL=MoveNodeCommand.d.ts.map