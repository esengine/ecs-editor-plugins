import { BaseCommand } from '@esengine/editor-core';
/**
 * 更新节点数据命令
 */
export class UpdateNodeDataCommand extends BaseCommand {
    constructor(state, nodeId, newData) {
        super();
        this.state = state;
        this.nodeId = nodeId;
        this.newData = newData;
        const tree = this.state.getTree();
        const node = tree.getNode(nodeId);
        this.oldData = node.data;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.updateData(this.newData));
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.updateData(this.oldData));
        this.state.setTree(newTree);
    }
    getDescription() {
        return `更新节点数据: ${this.nodeId}`;
    }
}
//# sourceMappingURL=UpdateNodeDataCommand.js.map