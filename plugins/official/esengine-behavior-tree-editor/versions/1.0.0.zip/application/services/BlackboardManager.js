export class BlackboardManager {
    constructor() {
        this.initialVariables = {};
        this.currentVariables = {};
    }
    setInitialVariables(variables) {
        this.initialVariables = JSON.parse(JSON.stringify(variables));
    }
    getInitialVariables() {
        return { ...this.initialVariables };
    }
    setCurrentVariables(variables) {
        this.currentVariables = { ...variables };
    }
    getCurrentVariables() {
        return { ...this.currentVariables };
    }
    updateVariable(key, value) {
        this.currentVariables[key] = value;
    }
    restoreInitialVariables() {
        this.currentVariables = { ...this.initialVariables };
        return this.getInitialVariables();
    }
    hasChanges() {
        return JSON.stringify(this.currentVariables) !== JSON.stringify(this.initialVariables);
    }
    clear() {
        this.initialVariables = {};
        this.currentVariables = {};
    }
}
//# sourceMappingURL=BlackboardManager.js.map