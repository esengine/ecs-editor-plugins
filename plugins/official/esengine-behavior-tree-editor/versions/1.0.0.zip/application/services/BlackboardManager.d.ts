import { BlackboardValue } from '../../domain/models/Blackboard';
type BlackboardVariables = Record<string, BlackboardValue>;
export declare class BlackboardManager {
    private initialVariables;
    private currentVariables;
    setInitialVariables(variables: BlackboardVariables): void;
    getInitialVariables(): BlackboardVariables;
    setCurrentVariables(variables: BlackboardVariables): void;
    getCurrentVariables(): BlackboardVariables;
    updateVariable(key: string, value: BlackboardValue): void;
    restoreInitialVariables(): BlackboardVariables;
    hasChanges(): boolean;
    clear(): void;
}
export {};
//# sourceMappingURL=BlackboardManager.d.ts.map