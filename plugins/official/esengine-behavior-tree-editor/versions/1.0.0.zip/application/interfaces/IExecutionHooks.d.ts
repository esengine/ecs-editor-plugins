import { Node as BehaviorTreeNode } from '../../domain/models/Node';
import { Connection } from '../../domain/models/Connection';
import { ExecutionLog } from '../../utils/BehaviorTreeExecutor';
import { BlackboardValue } from '../../domain/models/Blackboard';
type BlackboardVariables = Record<string, BlackboardValue>;
type NodeExecutionStatus = 'idle' | 'running' | 'success' | 'failure';
export interface ExecutionContext {
    nodes: BehaviorTreeNode[];
    connections: Connection[];
    blackboardVariables: BlackboardVariables;
    rootNodeId: string;
    tickCount: number;
}
export interface NodeStatusChangeEvent {
    nodeId: string;
    status: NodeExecutionStatus;
    previousStatus?: NodeExecutionStatus;
    timestamp: number;
}
export interface IExecutionHooks {
    beforePlay?(context: ExecutionContext): void | Promise<void>;
    afterPlay?(context: ExecutionContext): void | Promise<void>;
    beforePause?(): void | Promise<void>;
    afterPause?(): void | Promise<void>;
    beforeResume?(): void | Promise<void>;
    afterResume?(): void | Promise<void>;
    beforeStop?(): void | Promise<void>;
    afterStop?(): void | Promise<void>;
    beforeStep?(deltaTime: number): void | Promise<void>;
    afterStep?(deltaTime: number): void | Promise<void>;
    onTick?(tickCount: number, deltaTime: number): void | Promise<void>;
    onNodeStatusChange?(event: NodeStatusChangeEvent): void | Promise<void>;
    onExecutionComplete?(logs: ExecutionLog[]): void | Promise<void>;
    onBlackboardUpdate?(variables: BlackboardVariables): void | Promise<void>;
    onError?(error: Error, context?: string): void | Promise<void>;
}
export declare class ExecutionHooksManager {
    private hooks;
    register(hook: IExecutionHooks): void;
    unregister(hook: IExecutionHooks): void;
    clear(): void;
    triggerBeforePlay(context: ExecutionContext): Promise<void>;
    triggerAfterPlay(context: ExecutionContext): Promise<void>;
    triggerBeforePause(): Promise<void>;
    triggerAfterPause(): Promise<void>;
    triggerBeforeResume(): Promise<void>;
    triggerAfterResume(): Promise<void>;
    triggerBeforeStop(): Promise<void>;
    triggerAfterStop(): Promise<void>;
    triggerBeforeStep(deltaTime: number): Promise<void>;
    triggerAfterStep(deltaTime: number): Promise<void>;
    triggerOnTick(tickCount: number, deltaTime: number): Promise<void>;
    triggerOnNodeStatusChange(event: NodeStatusChangeEvent): Promise<void>;
    triggerOnExecutionComplete(logs: ExecutionLog[]): Promise<void>;
    triggerOnBlackboardUpdate(variables: BlackboardVariables): Promise<void>;
    triggerOnError(error: Error, context?: string): Promise<void>;
}
export {};
//# sourceMappingURL=IExecutionHooks.d.ts.map