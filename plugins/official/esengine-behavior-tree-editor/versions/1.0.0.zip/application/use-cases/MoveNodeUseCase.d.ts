import { Position } from '../../domain/value-objects/Position';
import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
/**
 * 移动节点用例
 */
export declare class MoveNodeUseCase {
    private readonly commandManager;
    private readonly treeState;
    constructor(commandManager: CommandManager, treeState: ITreeState);
    /**
     * 移动单个节点
     */
    execute(nodeId: string, newPosition: Position): void;
    /**
     * 批量移动节点
     */
    executeBatch(moves: Array<{
        nodeId: string;
        position: Position;
    }>): void;
}
//# sourceMappingURL=MoveNodeUseCase.d.ts.map