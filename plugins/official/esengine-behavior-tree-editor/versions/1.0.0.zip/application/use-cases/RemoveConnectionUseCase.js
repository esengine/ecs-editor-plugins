import { RemoveConnectionCommand } from '../commands/tree/RemoveConnectionCommand';
/**
 * 移除连接用例
 */
export class RemoveConnectionUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 执行移除连接操作
     */
    execute(from, to, fromProperty, toProperty) {
        const command = new RemoveConnectionCommand(this.treeState, from, to, fromProperty, toProperty);
        this.commandManager.execute(command);
    }
}
//# sourceMappingURL=RemoveConnectionUseCase.js.map