import { NodeTemplate } from '@esengine/behavior-tree';
import { Node } from '../../domain/models/Node';
import { Position } from '../../domain/value-objects/Position';
import { INodeFactory } from '../../domain/interfaces/INodeFactory';
import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
/**
 * 创建节点用例
 */
export declare class CreateNodeUseCase {
    private readonly nodeFactory;
    private readonly commandManager;
    private readonly treeState;
    constructor(nodeFactory: INodeFactory, commandManager: CommandManager, treeState: ITreeState);
    /**
     * 执行创建节点操作
     */
    execute(template: NodeTemplate, position: Position, data?: Record<string, unknown>): Node;
    /**
     * 根据类型创建节点
     */
    executeByType(nodeType: string, position: Position, data?: Record<string, unknown>): Node;
}
//# sourceMappingURL=CreateNodeUseCase.d.ts.map