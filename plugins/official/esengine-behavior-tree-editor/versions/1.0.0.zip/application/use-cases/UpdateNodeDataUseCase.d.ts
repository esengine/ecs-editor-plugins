import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
/**
 * 更新节点数据用例
 */
export declare class UpdateNodeDataUseCase {
    private readonly commandManager;
    private readonly treeState;
    constructor(commandManager: CommandManager, treeState: ITreeState);
    /**
     * 更新节点数据
     */
    execute(nodeId: string, data: Record<string, unknown>): void;
}
//# sourceMappingURL=UpdateNodeDataUseCase.d.ts.map