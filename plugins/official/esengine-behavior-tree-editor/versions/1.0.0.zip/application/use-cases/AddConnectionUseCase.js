import { Connection } from '../../domain/models/Connection';
import { AddConnectionCommand } from '../commands/tree/AddConnectionCommand';
/**
 * 添加连接用例
 */
export class AddConnectionUseCase {
    constructor(commandManager, treeState, validator) {
        this.commandManager = commandManager;
        this.treeState = treeState;
        this.validator = validator;
    }
    /**
     * 执行添加连接操作
     */
    execute(from, to, connectionType = 'node', fromProperty, toProperty) {
        const connection = new Connection(from, to, connectionType, fromProperty, toProperty);
        const tree = this.treeState.getTree();
        const validationResult = this.validator.validateConnection(connection, tree);
        if (!validationResult.isValid) {
            const errorMessages = validationResult.errors.map((e) => e.message).join(', ');
            throw new Error(`连接验证失败: ${errorMessages}`);
        }
        const command = new AddConnectionCommand(this.treeState, connection);
        this.commandManager.execute(command);
        return connection;
    }
}
//# sourceMappingURL=AddConnectionUseCase.js.map