import { Connection, ConnectionType } from '../../domain/models/Connection';
import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
import { IValidator } from '../../domain/interfaces/IValidator';
/**
 * 添加连接用例
 */
export declare class AddConnectionUseCase {
    private readonly commandManager;
    private readonly treeState;
    private readonly validator;
    constructor(commandManager: CommandManager, treeState: ITreeState, validator: IValidator);
    /**
     * 执行添加连接操作
     */
    execute(from: string, to: string, connectionType?: ConnectionType, fromProperty?: string, toProperty?: string): Connection;
}
//# sourceMappingURL=AddConnectionUseCase.d.ts.map