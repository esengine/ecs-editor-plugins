import { CreateNodeCommand } from '../commands/tree/CreateNodeCommand';
/**
 * 创建节点用例
 */
export class CreateNodeUseCase {
    constructor(nodeFactory, commandManager, treeState) {
        this.nodeFactory = nodeFactory;
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 执行创建节点操作
     */
    execute(template, position, data) {
        const node = this.nodeFactory.createNode(template, position, data);
        const command = new CreateNodeCommand(this.treeState, node);
        this.commandManager.execute(command);
        return node;
    }
    /**
     * 根据类型创建节点
     */
    executeByType(nodeType, position, data) {
        const node = this.nodeFactory.createNodeByType(nodeType, position, data);
        const command = new CreateNodeCommand(this.treeState, node);
        this.commandManager.execute(command);
        return node;
    }
}
//# sourceMappingURL=CreateNodeUseCase.js.map