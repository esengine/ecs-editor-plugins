export class EditorExtensionRegistry {
    constructor() {
        this.nodeRenderers = new Set();
        this.propertyEditors = new Set();
        this.nodeProviders = new Set();
        this.toolbarButtons = new Set();
        this.panelProviders = new Set();
        this.validators = new Set();
        this.commandProviders = new Set();
    }
    registerNodeRenderer(renderer) {
        this.nodeRenderers.add(renderer);
    }
    unregisterNodeRenderer(renderer) {
        this.nodeRenderers.delete(renderer);
    }
    getNodeRenderer(node) {
        for (const renderer of this.nodeRenderers) {
            if (renderer.canRender(node)) {
                return renderer;
            }
        }
        return undefined;
    }
    registerPropertyEditor(editor) {
        this.propertyEditors.add(editor);
    }
    unregisterPropertyEditor(editor) {
        this.propertyEditors.delete(editor);
    }
    getPropertyEditor(propertyType) {
        for (const editor of this.propertyEditors) {
            if (editor.canEdit(propertyType)) {
                return editor;
            }
        }
        return undefined;
    }
    registerNodeProvider(provider) {
        this.nodeProviders.add(provider);
    }
    unregisterNodeProvider(provider) {
        this.nodeProviders.delete(provider);
    }
    getAllNodeTemplates() {
        const templates = [];
        this.nodeProviders.forEach((provider) => {
            templates.push(...provider.getNodeTemplates());
        });
        return templates;
    }
    registerToolbarButton(button) {
        this.toolbarButtons.add(button);
    }
    unregisterToolbarButton(button) {
        this.toolbarButtons.delete(button);
    }
    getToolbarButtons() {
        return Array.from(this.toolbarButtons).filter((btn) => {
            return btn.isVisible ? btn.isVisible() : true;
        });
    }
    registerPanelProvider(provider) {
        this.panelProviders.add(provider);
    }
    unregisterPanelProvider(provider) {
        this.panelProviders.delete(provider);
    }
    getPanelProviders() {
        return Array.from(this.panelProviders).filter((panel) => {
            return panel.canActivate ? panel.canActivate() : true;
        });
    }
    registerValidator(validator) {
        this.validators.add(validator);
    }
    unregisterValidator(validator) {
        this.validators.delete(validator);
    }
    async validateTree(nodes) {
        const results = [];
        for (const validator of this.validators) {
            try {
                const validationResults = validator.validate(nodes);
                results.push(...validationResults);
            }
            catch (error) {
                console.error(`Error in validator ${validator.name}:`, error);
                results.push({
                    severity: 'error',
                    message: `Validator ${validator.name} failed: ${error}`,
                    code: 'VALIDATOR_ERROR'
                });
            }
        }
        return results;
    }
    registerCommandProvider(provider) {
        this.commandProviders.add(provider);
    }
    unregisterCommandProvider(provider) {
        this.commandProviders.delete(provider);
    }
    getCommandProvider(commandId) {
        for (const provider of this.commandProviders) {
            if (provider.getCommandId() === commandId) {
                return provider;
            }
        }
        return undefined;
    }
    getAllCommandProviders() {
        return Array.from(this.commandProviders);
    }
    clear() {
        this.nodeRenderers.clear();
        this.propertyEditors.clear();
        this.nodeProviders.clear();
        this.toolbarButtons.clear();
        this.panelProviders.clear();
        this.validators.clear();
        this.commandProviders.clear();
    }
}
let globalExtensionRegistry = null;
export function getGlobalExtensionRegistry() {
    if (!globalExtensionRegistry) {
        globalExtensionRegistry = new EditorExtensionRegistry();
    }
    return globalExtensionRegistry;
}
export function resetGlobalExtensionRegistry() {
    globalExtensionRegistry = null;
}
//# sourceMappingURL=IEditorExtensions.js.map