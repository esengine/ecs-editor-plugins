export var EditorEvent;
(function (EditorEvent) {
    EditorEvent["NODE_CREATED"] = "node:created";
    EditorEvent["NODE_DELETED"] = "node:deleted";
    EditorEvent["NODE_UPDATED"] = "node:updated";
    EditorEvent["NODE_MOVED"] = "node:moved";
    EditorEvent["NODE_SELECTED"] = "node:selected";
    EditorEvent["CONNECTION_ADDED"] = "connection:added";
    EditorEvent["CONNECTION_REMOVED"] = "connection:removed";
    EditorEvent["EXECUTION_STARTED"] = "execution:started";
    EditorEvent["EXECUTION_PAUSED"] = "execution:paused";
    EditorEvent["EXECUTION_RESUMED"] = "execution:resumed";
    EditorEvent["EXECUTION_STOPPED"] = "execution:stopped";
    EditorEvent["EXECUTION_TICK"] = "execution:tick";
    EditorEvent["EXECUTION_NODE_STATUS_CHANGED"] = "execution:node_status_changed";
    EditorEvent["TREE_SAVED"] = "tree:saved";
    EditorEvent["TREE_LOADED"] = "tree:loaded";
    EditorEvent["TREE_VALIDATED"] = "tree:validated";
    EditorEvent["BLACKBOARD_VARIABLE_UPDATED"] = "blackboard:variable_updated";
    EditorEvent["BLACKBOARD_RESTORED"] = "blackboard:restored";
    EditorEvent["CANVAS_ZOOM_CHANGED"] = "canvas:zoom_changed";
    EditorEvent["CANVAS_PAN_CHANGED"] = "canvas:pan_changed";
    EditorEvent["CANVAS_RESET"] = "canvas:reset";
    EditorEvent["COMMAND_EXECUTED"] = "command:executed";
    EditorEvent["COMMAND_UNDONE"] = "command:undone";
    EditorEvent["COMMAND_REDONE"] = "command:redone";
})(EditorEvent || (EditorEvent = {}));
export class EditorEventBus {
    constructor() {
        this.listeners = new Map();
        this.eventHistory = [];
        this.maxHistorySize = 100;
    }
    on(event, handler) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event).add(handler);
        return {
            unsubscribe: () => this.off(event, handler)
        };
    }
    once(event, handler) {
        const wrappedHandler = (data) => {
            handler(data);
            this.off(event, wrappedHandler);
        };
        return this.on(event, wrappedHandler);
    }
    off(event, handler) {
        const handlers = this.listeners.get(event);
        if (handlers) {
            handlers.delete(handler);
            if (handlers.size === 0) {
                this.listeners.delete(event);
            }
        }
    }
    emit(event, data) {
        if (this.eventHistory.length >= this.maxHistorySize) {
            this.eventHistory.shift();
        }
        this.eventHistory.push({
            event,
            data,
            timestamp: Date.now()
        });
        const handlers = this.listeners.get(event);
        if (handlers) {
            handlers.forEach((handler) => {
                try {
                    handler(data);
                }
                catch (error) {
                    console.error(`Error in event handler for ${event}:`, error);
                }
            });
        }
    }
    clear(event) {
        if (event) {
            this.listeners.delete(event);
        }
        else {
            this.listeners.clear();
        }
    }
    getListenerCount(event) {
        return this.listeners.get(event)?.size || 0;
    }
    getAllEvents() {
        return Array.from(this.listeners.keys());
    }
    getEventHistory(count) {
        if (count) {
            return this.eventHistory.slice(-count);
        }
        return [...this.eventHistory];
    }
    clearHistory() {
        this.eventHistory = [];
    }
}
let globalEventBus = null;
export function getGlobalEventBus() {
    if (!globalEventBus) {
        globalEventBus = new EditorEventBus();
    }
    return globalEventBus;
}
export function resetGlobalEventBus() {
    globalEventBus = null;
}
//# sourceMappingURL=EditorEventBus.js.map