import { NodeTemplate } from '@esengine/behavior-tree';
import { Node } from '../../domain/models/Node';
import { Position } from '../../domain/value-objects/Position';
import { INodeFactory } from '../../domain/interfaces/INodeFactory';
/**
 * 节点工厂实现
 */
export declare class NodeFactory implements INodeFactory {
    /**
     * 创建节点
     */
    createNode(template: NodeTemplate, position: Position, data?: Record<string, unknown>): Node;
    /**
     * 根据模板类型创建节点
     */
    createNodeByType(nodeType: string, position: Position, data?: Record<string, unknown>): Node;
    /**
     * 克隆节点
     */
    cloneNode(node: Node, newPosition?: Position): Node;
    /**
     * 根据类型获取模板
     */
    private getTemplateByType;
}
//# sourceMappingURL=NodeFactory.d.ts.map