import { NodeTemplates } from '@esengine/behavior-tree';
import { Node } from '../../domain/models/Node';
/**
 * 生成唯一ID
 */
function generateUniqueId() {
    return `node-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
/**
 * 节点工厂实现
 */
export class NodeFactory {
    /**
     * 创建节点
     */
    createNode(template, position, data) {
        const nodeId = generateUniqueId();
        const nodeData = {
            ...template.defaultConfig,
            ...data
        };
        return new Node(nodeId, template, nodeData, position, []);
    }
    /**
     * 根据模板类型创建节点
     */
    createNodeByType(nodeType, position, data) {
        const template = this.getTemplateByType(nodeType);
        if (!template) {
            throw new Error(`未找到节点模板: ${nodeType}`);
        }
        return this.createNode(template, position, data);
    }
    /**
     * 克隆节点
     */
    cloneNode(node, newPosition) {
        const position = newPosition || node.position;
        const clonedId = generateUniqueId();
        return new Node(clonedId, node.template, node.data, position, []);
    }
    /**
     * 根据类型获取模板
     */
    getTemplateByType(nodeType) {
        const allTemplates = NodeTemplates.getAllTemplates();
        const template = allTemplates.find((t) => {
            const defaultNodeType = t.defaultConfig.nodeType;
            return defaultNodeType === nodeType;
        });
        return template || null;
    }
}
//# sourceMappingURL=NodeFactory.js.map