import { IValidator, ValidationResult } from '../../domain/interfaces/IValidator';
import { BehaviorTree } from '../../domain/models/BehaviorTree';
import { Node } from '../../domain/models/Node';
import { Connection } from '../../domain/models/Connection';
/**
 * 行为树验证器实现
 */
export declare class BehaviorTreeValidator implements IValidator {
    /**
     * 验证整个行为树
     */
    validateTree(tree: BehaviorTree): ValidationResult;
    /**
     * 验证节点
     */
    validateNode(node: Node): ValidationResult;
    /**
     * 验证连接
     */
    validateConnection(connection: Connection, tree: BehaviorTree): ValidationResult;
    /**
     * 验证是否会产生循环引用
     */
    validateNoCycles(tree: BehaviorTree): ValidationResult;
}
//# sourceMappingURL=BehaviorTreeValidator.d.ts.map