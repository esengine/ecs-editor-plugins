import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useRef, useCallback, forwardRef } from 'react';
import { useCanvasInteraction } from '../../hooks/useCanvasInteraction';
/**
 * 行为树画布组件
 * 负责画布的渲染、缩放、平移等基础功能
 */
export const BehaviorTreeCanvas = forwardRef(({ config, children, onClick, onDoubleClick, onContextMenu, onMouseMove, onMouseDown, onMouseUp, onMouseLeave, onDrop, onDragOver, onDragEnter, onDragLeave }, forwardedRef) => {
    const internalRef = useRef(null);
    const canvasRef = forwardedRef || internalRef;
    const { canvasOffset, canvasScale, isPanning, handleWheel, startPanning, updatePanning, stopPanning } = useCanvasInteraction();
    const handleMouseDown = useCallback((e) => {
        if (e.button === 1 || (e.button === 0 && e.altKey)) {
            e.preventDefault();
            startPanning(e.clientX, e.clientY);
        }
        onMouseDown?.(e);
    }, [startPanning, onMouseDown]);
    const handleMouseMove = useCallback((e) => {
        if (isPanning) {
            updatePanning(e.clientX, e.clientY);
        }
        onMouseMove?.(e);
    }, [isPanning, updatePanning, onMouseMove]);
    const handleMouseUp = useCallback((e) => {
        if (isPanning) {
            stopPanning();
        }
        onMouseUp?.(e);
    }, [isPanning, stopPanning, onMouseUp]);
    const handleContextMenu = useCallback((e) => {
        e.preventDefault();
        onContextMenu?.(e);
    }, [onContextMenu]);
    return (_jsxs("div", { ref: canvasRef, className: "behavior-tree-canvas", style: {
            position: 'relative',
            width: '100%',
            height: '100%',
            overflow: 'hidden',
            cursor: isPanning ? 'grabbing' : 'default',
            backgroundColor: '#1a1a1a'
        }, onWheel: handleWheel, onClick: onClick, onDoubleClick: onDoubleClick, onContextMenu: handleContextMenu, onMouseDown: handleMouseDown, onMouseMove: handleMouseMove, onMouseUp: handleMouseUp, onMouseLeave: onMouseLeave, onDrop: onDrop, onDragOver: onDragOver, onDragEnter: onDragEnter, onDragLeave: onDragLeave, children: [config.showGrid && (_jsx("div", { className: "canvas-grid", style: {
                    position: 'absolute',
                    inset: 0,
                    backgroundImage: `
                            linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)
                        `,
                    backgroundSize: `${(config.gridSize || 20) * canvasScale}px ${(config.gridSize || 20) * canvasScale}px`,
                    backgroundPosition: `${canvasOffset.x}px ${canvasOffset.y}px`
                } })), _jsx("div", { className: "canvas-content", style: {
                    position: 'absolute',
                    transformOrigin: '0 0',
                    transform: `translate(${canvasOffset.x}px, ${canvasOffset.y}px) scale(${canvasScale})`,
                    width: '100%',
                    height: '100%'
                }, children: children })] }));
});
BehaviorTreeCanvas.displayName = 'BehaviorTreeCanvas';
//# sourceMappingURL=BehaviorTreeCanvas.js.map