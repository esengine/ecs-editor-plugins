import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Node as BehaviorTreeNodeType } from '../../domain/models/Node';
import { Connection } from '../../domain/models/Connection';
import { NodeExecutionStatus } from '../../stores/useExecutionStore';
import { BehaviorTreeExecutor } from '../../utils/BehaviorTreeExecutor';
import { BlackboardValue } from '../../domain/models/Blackboard';
type BlackboardVariables = Record<string, BlackboardValue>;
interface BehaviorTreeNodeProps {
    node: BehaviorTreeNodeType;
    isSelected: boolean;
    isBeingDragged: boolean;
    dragDelta: {
        dx: number;
        dy: number;
    };
    uncommittedNodeIds: Set<string>;
    blackboardVariables: BlackboardVariables;
    initialBlackboardVariables: BlackboardVariables;
    isExecuting: boolean;
    executionStatus?: NodeExecutionStatus;
    executionOrder?: number;
    connections: Connection[];
    nodes: BehaviorTreeNodeType[];
    executorRef: React.RefObject<BehaviorTreeExecutor | null>;
    iconMap: Record<string, LucideIcon>;
    draggingNodeId: string | null;
    onNodeClick: (e: React.MouseEvent, node: BehaviorTreeNodeType) => void;
    onContextMenu: (e: React.MouseEvent, node: BehaviorTreeNodeType) => void;
    onNodeMouseDown: (e: React.MouseEvent, nodeId: string) => void;
    onNodeMouseUpForConnection: (e: React.MouseEvent, nodeId: string) => void;
    onPortMouseDown: (e: React.MouseEvent, nodeId: string, propertyName?: string) => void;
    onPortMouseUp: (e: React.MouseEvent, nodeId: string, propertyName?: string) => void;
}
export declare const BehaviorTreeNode: React.FC<BehaviorTreeNodeProps>;
export {};
//# sourceMappingURL=BehaviorTreeNode.d.ts.map