import { EditorPluginCategory, CompilerRegistry, BaseCommand, CommandManager } from '@esengine/editor-core';
import { singleton } from 'tsyringe';
import { create } from 'zustand';
import { EditorFormatConverter, BehaviorTreeAssetSerializer, BlackboardValueType, BehaviorTreeAssetManager, BehaviorTreeExecutionSystem, BehaviorTreeRuntimeComponent, NodeType as NodeType$1, TaskStatus, NodeTemplates } from '@esengine/behavior-tree';
import { jsx, jsxs } from 'react/jsx-runtime';
import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { FolderTree, File, FolderOpen, TreePine, Database, Settings, Dices, Equal, Code, Calculator, Edit, FileText, Clock, Timer, Snowflake, HelpCircle, CheckCheck, XCircle, CheckCircle, Repeat, RotateCcw, Shuffle, Layers, GitBranch, List } from 'lucide-react';
import { Core, createLogger, World, Time } from '@esengine/ecs-framework';

/**
 * 位置值对象
 * 表示二维空间中的坐标点
 */
class Position {
    constructor(x, y) {
        this._x = x;
        this._y = y;
    }
    get x() {
        return this._x;
    }
    get y() {
        return this._y;
    }
    /**
     * 创建新的位置，加上偏移量
     */
    add(offset) {
        return new Position(this._x + offset._x, this._y + offset._y);
    }
    /**
     * 创建新的位置，减去偏移量
     */
    subtract(other) {
        return new Position(this._x - other._x, this._y - other._y);
    }
    /**
     * 计算到另一个位置的距离
     */
    distanceTo(other) {
        const dx = this._x - other._x;
        const dy = this._y - other._y;
        return Math.sqrt(dx * dx + dy * dy);
    }
    /**
     * 值对象相等性比较
     */
    equals(other) {
        return this._x === other._x && this._y === other._y;
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return { x: this._x, y: this._y };
    }
    /**
     * 从普通对象创建
     */
    static fromObject(obj) {
        return new Position(obj.x, obj.y);
    }
    /**
     * 创建零位置
     */
    static zero() {
        return new Position(0, 0);
    }
}

/**
 * 尺寸值对象
 * 表示宽度和高度
 */
class Size {
    constructor(width, height) {
        if (width < 0 || height < 0) {
            throw new Error('Size dimensions must be non-negative');
        }
        this._width = width;
        this._height = height;
    }
    get width() {
        return this._width;
    }
    get height() {
        return this._height;
    }
    /**
     * 获取面积
     */
    get area() {
        return this._width * this._height;
    }
    /**
     * 缩放尺寸
     */
    scale(factor) {
        return new Size(this._width * factor, this._height * factor);
    }
    /**
     * 值对象相等性比较
     */
    equals(other) {
        return this._width === other._width && this._height === other._height;
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return { width: this._width, height: this._height };
    }
    /**
     * 从普通对象创建
     */
    static fromObject(obj) {
        return new Size(obj.width, obj.height);
    }
}

/**
 * 节点类型值对象
 * 封装节点类型的业务逻辑
 */
class NodeType {
    constructor(value) {
        this._value = value;
    }
    get value() {
        return this._value;
    }
    /**
     * 是否为根节点
     */
    isRoot() {
        return this._value === 'root';
    }
    /**
     * 是否为组合节点（可以有多个子节点）
     */
    isComposite() {
        return this._value === 'composite' ||
            ['sequence', 'selector', 'parallel'].includes(this._value);
    }
    /**
     * 是否为装饰节点（只能有一个子节点）
     */
    isDecorator() {
        return this._value === 'decorator' ||
            ['repeater', 'inverter', 'succeeder', 'failer', 'until-fail', 'until-success'].includes(this._value);
    }
    /**
     * 是否为叶子节点（不能有子节点）
     */
    isLeaf() {
        return this._value === 'action' || this._value === 'condition' ||
            this._value.includes('action-') || this._value.includes('condition-');
    }
    /**
     * 获取允许的最大子节点数
     * @returns 0 表示叶子节点，1 表示装饰节点，Infinity 表示组合节点
     */
    getMaxChildren() {
        if (this.isLeaf()) {
            return 0;
        }
        if (this.isRoot() || this.isDecorator()) {
            return 1;
        }
        if (this.isComposite()) {
            return Infinity;
        }
        return 0;
    }
    /**
     * 值对象相等性比较
     */
    equals(other) {
        return this._value === other._value;
    }
    toString() {
        return this._value;
    }
    /**
     * 从字符串创建节点类型
     */
    static fromString(value) {
        switch (value) {
            case 'root': return NodeType.ROOT;
            case 'sequence': return NodeType.SEQUENCE;
            case 'selector': return NodeType.SELECTOR;
            case 'parallel': return NodeType.PARALLEL;
            case 'repeater': return NodeType.REPEATER;
            case 'inverter': return NodeType.INVERTER;
            case 'succeeder': return NodeType.SUCCEEDER;
            case 'failer': return NodeType.FAILER;
            case 'until-fail': return NodeType.UNTIL_FAIL;
            case 'until-success': return NodeType.UNTIL_SUCCESS;
            default: return new NodeType(value);
        }
    }
}
/**
 * 预定义的节点类型
 */
NodeType.ROOT = new NodeType('root');
NodeType.SEQUENCE = new NodeType('sequence');
NodeType.SELECTOR = new NodeType('selector');
NodeType.PARALLEL = new NodeType('parallel');
NodeType.REPEATER = new NodeType('repeater');
NodeType.INVERTER = new NodeType('inverter');
NodeType.SUCCEEDER = new NodeType('succeeder');
NodeType.FAILER = new NodeType('failer');
NodeType.UNTIL_FAIL = new NodeType('until-fail');
NodeType.UNTIL_SUCCESS = new NodeType('until-success');

/**
 * 领域错误基类
 */
class DomainError extends Error {
    constructor(message) {
        super(message);
        this.name = this.constructor.name;
        Object.setPrototypeOf(this, new.target.prototype);
    }
}

/**
 * 验证错误
 * 当业务规则验证失败时抛出
 */
class ValidationError extends DomainError {
    constructor(message, field, value) {
        super(message);
        this.field = field;
        this.value = value;
    }
    static rootNodeMaxChildren() {
        return new ValidationError('根节点只能连接一个子节点', 'children');
    }
    static decoratorNodeMaxChildren() {
        return new ValidationError('装饰节点只能连接一个子节点', 'children');
    }
    static leafNodeNoChildren() {
        return new ValidationError('叶子节点不能有子节点', 'children');
    }
    static circularReference(nodeId) {
        return new ValidationError(`检测到循环引用，节点 ${nodeId} 不能连接到自己或其子节点`, 'connection', nodeId);
    }
    static invalidConnection(from, to, reason) {
        return new ValidationError(`无效的连接：${reason}`, 'connection', { from, to });
    }
}

/**
 * 节点未找到错误
 */
class NodeNotFoundError extends DomainError {
    constructor(nodeId) {
        super(`节点未找到: ${nodeId}`);
        this.nodeId = nodeId;
    }
}

/**
 * 行为树节点领域实体
 * 封装节点的业务逻辑和验证规则
 */
class Node {
    constructor(id, template, data, position, children = []) {
        this._id = id;
        this._template = template;
        this._data = { ...data };
        this._position = position;
        this._children = [...children];
        this._nodeType = NodeType.fromString(template.type);
    }
    get id() {
        return this._id;
    }
    get template() {
        return this._template;
    }
    get data() {
        return { ...this._data };
    }
    get position() {
        return this._position;
    }
    get children() {
        return this._children;
    }
    get nodeType() {
        return this._nodeType;
    }
    /**
     * 更新节点位置
     */
    moveToPosition(newPosition) {
        return new Node(this._id, this._template, this._data, newPosition, this._children);
    }
    /**
     * 更新节点数据
     */
    updateData(data) {
        return new Node(this._id, this._template, { ...this._data, ...data }, this._position, this._children);
    }
    /**
     * 添加子节点
     * @throws ValidationError 如果违反业务规则
     */
    addChild(childId) {
        // 使用模板定义的约束，undefined 表示无限制
        const maxChildren = (this._template.maxChildren ?? Infinity);
        if (maxChildren === 0) {
            throw ValidationError.leafNodeNoChildren();
        }
        if (this._children.length >= maxChildren) {
            if (this._nodeType.isRoot()) {
                throw ValidationError.rootNodeMaxChildren();
            }
            if (this._nodeType.isDecorator()) {
                throw ValidationError.decoratorNodeMaxChildren();
            }
            throw new ValidationError(`节点 ${this._id} 已达到最大子节点数 ${maxChildren}`);
        }
        if (this._children.includes(childId)) {
            throw new ValidationError(`子节点 ${childId} 已存在`);
        }
        return new Node(this._id, this._template, this._data, this._position, [...this._children, childId]);
    }
    /**
     * 移除子节点
     */
    removeChild(childId) {
        return new Node(this._id, this._template, this._data, this._position, this._children.filter((id) => id !== childId));
    }
    /**
     * 检查是否可以添加子节点
     */
    canAddChild() {
        // 使用模板定义的最大子节点数，undefined 表示无限制
        const maxChildren = (this._template.maxChildren ?? Infinity);
        return this._children.length < maxChildren;
    }
    /**
     * 检查是否有子节点
     */
    hasChildren() {
        return this._children.length > 0;
    }
    /**
     * 检查是否为根节点
     */
    isRoot() {
        return this._nodeType.isRoot();
    }
    /**
     * 转换为普通对象（用于序列化）
     */
    toObject() {
        return {
            id: this._id,
            template: this._template,
            data: this._data,
            position: this._position.toObject(),
            children: [...this._children]
        };
    }
    /**
     * 从普通对象创建节点
     */
    static fromObject(obj) {
        return new Node(obj.id, obj.template, obj.data, Position.fromObject(obj.position), obj.children);
    }
}

/**
 * 连接领域实体
 * 表示两个节点之间的连接关系
 */
class Connection {
    constructor(from, to, connectionType = 'node', fromProperty, toProperty) {
        if (from === to) {
            throw ValidationError.circularReference(from);
        }
        if (connectionType === 'property' && (!fromProperty || !toProperty)) {
            throw new ValidationError('属性连接必须指定源属性和目标属性');
        }
        this._from = from;
        this._to = to;
        this._connectionType = connectionType;
        this._fromProperty = fromProperty;
        this._toProperty = toProperty;
    }
    get from() {
        return this._from;
    }
    get to() {
        return this._to;
    }
    get fromProperty() {
        return this._fromProperty;
    }
    get toProperty() {
        return this._toProperty;
    }
    get connectionType() {
        return this._connectionType;
    }
    /**
     * 检查是否为节点连接
     */
    isNodeConnection() {
        return this._connectionType === 'node';
    }
    /**
     * 检查是否为属性连接
     */
    isPropertyConnection() {
        return this._connectionType === 'property';
    }
    /**
     * 检查连接是否匹配指定的条件
     */
    matches(from, to, fromProperty, toProperty) {
        if (this._from !== from || this._to !== to) {
            return false;
        }
        if (this._connectionType === 'property') {
            return this._fromProperty === fromProperty && this._toProperty === toProperty;
        }
        return true;
    }
    /**
     * 相等性比较
     */
    equals(other) {
        return (this._from === other._from &&
            this._to === other._to &&
            this._connectionType === other._connectionType &&
            this._fromProperty === other._fromProperty &&
            this._toProperty === other._toProperty);
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return {
            from: this._from,
            to: this._to,
            connectionType: this._connectionType,
            ...(this._fromProperty && { fromProperty: this._fromProperty }),
            ...(this._toProperty && { toProperty: this._toProperty })
        };
    }
    /**
     * 从普通对象创建连接
     */
    static fromObject(obj) {
        return new Connection(obj.from, obj.to, obj.connectionType, obj.fromProperty, obj.toProperty);
    }
}

/**
 * 黑板领域实体
 * 管理行为树的全局变量
 */
class Blackboard {
    constructor(variables = {}) {
        this._variables = new Map(Object.entries(variables));
    }
    /**
     * 获取变量值
     */
    get(key) {
        return this._variables.get(key);
    }
    /**
     * 设置变量值
     */
    set(key, value) {
        const newVariables = new Map(this._variables);
        newVariables.set(key, value);
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 设置变量值（别名方法）
     */
    setValue(key, value) {
        this._variables.set(key, value);
    }
    /**
     * 删除变量
     */
    delete(key) {
        const newVariables = new Map(this._variables);
        newVariables.delete(key);
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 检查变量是否存在
     */
    has(key) {
        return this._variables.has(key);
    }
    /**
     * 获取所有变量名
     */
    keys() {
        return Array.from(this._variables.keys());
    }
    /**
     * 获取所有变量
     */
    getAll() {
        return Object.fromEntries(this._variables);
    }
    /**
     * 批量设置变量
     */
    setAll(variables) {
        const newVariables = new Map(this._variables);
        Object.entries(variables).forEach(([key, value]) => {
            newVariables.set(key, value);
        });
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 清空所有变量
     */
    clear() {
        return new Blackboard();
    }
    /**
     * 获取变量数量
     */
    size() {
        return this._variables.size;
    }
    /**
     * 克隆黑板
     */
    clone() {
        return new Blackboard(this.getAll());
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return this.getAll();
    }
    /**
     * 从普通对象创建黑板
     */
    static fromObject(obj) {
        return new Blackboard(obj);
    }
    /**
     * 创建空黑板
     */
    static empty() {
        return new Blackboard();
    }
}

/**
 * 行为树聚合根
 * 管理整个行为树的节点、连接和黑板
 */
class BehaviorTree {
    constructor(nodes = [], connections = [], blackboard = Blackboard.empty(), rootNodeId = null) {
        this._nodes = new Map(nodes.map((node) => [node.id, node]));
        this._connections = [...connections];
        this._blackboard = blackboard;
        this._rootNodeId = rootNodeId;
        this.validateTree();
    }
    get nodes() {
        return Array.from(this._nodes.values());
    }
    get connections() {
        return this._connections;
    }
    get blackboard() {
        return this._blackboard;
    }
    get rootNodeId() {
        return this._rootNodeId;
    }
    /**
     * 获取指定节点
     */
    getNode(nodeId) {
        const node = this._nodes.get(nodeId);
        if (!node) {
            throw new NodeNotFoundError(nodeId);
        }
        return node;
    }
    /**
     * 检查节点是否存在
     */
    hasNode(nodeId) {
        return this._nodes.has(nodeId);
    }
    /**
     * 添加节点
     */
    addNode(node) {
        if (this._nodes.has(node.id)) {
            throw new ValidationError(`节点 ${node.id} 已存在`);
        }
        if (node.isRoot()) {
            if (this._rootNodeId) {
                throw new ValidationError('行为树只能有一个根节点');
            }
            return new BehaviorTree([...this.nodes, node], this._connections, this._blackboard, node.id);
        }
        return new BehaviorTree([...this.nodes, node], this._connections, this._blackboard, this._rootNodeId);
    }
    /**
     * 移除节点
     * 会同时移除相关的连接
     */
    removeNode(nodeId) {
        if (!this._nodes.has(nodeId)) {
            throw new NodeNotFoundError(nodeId);
        }
        const node = this.getNode(nodeId);
        const newNodes = Array.from(this.nodes.filter((n) => n.id !== nodeId));
        const newConnections = this._connections.filter((conn) => conn.from !== nodeId && conn.to !== nodeId);
        const newRootNodeId = node.isRoot() ? null : this._rootNodeId;
        return new BehaviorTree(newNodes, newConnections, this._blackboard, newRootNodeId);
    }
    /**
     * 更新节点
     */
    updateNode(nodeId, updater) {
        const node = this.getNode(nodeId);
        const updatedNode = updater(node);
        const newNodes = Array.from(this.nodes.map((n) => n.id === nodeId ? updatedNode : n));
        return new BehaviorTree(newNodes, this._connections, this._blackboard, this._rootNodeId);
    }
    /**
     * 添加连接
     * 会验证连接的合法性
     */
    addConnection(connection) {
        const fromNode = this.getNode(connection.from);
        const toNode = this.getNode(connection.to);
        if (this.hasConnection(connection.from, connection.to)) {
            throw new ValidationError(`连接已存在：${connection.from} -> ${connection.to}`);
        }
        if (this.wouldCreateCycle(connection.from, connection.to)) {
            throw ValidationError.circularReference(connection.to);
        }
        if (connection.isNodeConnection()) {
            if (!fromNode.canAddChild()) {
                if (fromNode.isRoot()) {
                    throw ValidationError.rootNodeMaxChildren();
                }
                if (fromNode.nodeType.isDecorator()) {
                    throw ValidationError.decoratorNodeMaxChildren();
                }
                throw new ValidationError(`节点 ${connection.from} 无法添加更多子节点`);
            }
            if (toNode.nodeType.getMaxChildren() === 0 && toNode.nodeType.isLeaf()) ;
            const updatedFromNode = fromNode.addChild(connection.to);
            const newNodes = Array.from(this.nodes.map((n) => n.id === connection.from ? updatedFromNode : n));
            return new BehaviorTree(newNodes, [...this._connections, connection], this._blackboard, this._rootNodeId);
        }
        return new BehaviorTree(Array.from(this.nodes), [...this._connections, connection], this._blackboard, this._rootNodeId);
    }
    /**
     * 移除连接
     */
    removeConnection(from, to, fromProperty, toProperty) {
        const connection = this._connections.find((c) => c.matches(from, to, fromProperty, toProperty));
        if (!connection) {
            throw new ValidationError(`连接不存在：${from} -> ${to}`);
        }
        const newConnections = this._connections.filter((c) => !c.matches(from, to, fromProperty, toProperty));
        if (connection.isNodeConnection()) {
            const fromNode = this.getNode(from);
            const updatedFromNode = fromNode.removeChild(to);
            const newNodes = Array.from(this.nodes.map((n) => n.id === from ? updatedFromNode : n));
            return new BehaviorTree(newNodes, newConnections, this._blackboard, this._rootNodeId);
        }
        return new BehaviorTree(Array.from(this.nodes), newConnections, this._blackboard, this._rootNodeId);
    }
    /**
     * 检查是否存在连接
     */
    hasConnection(from, to) {
        return this._connections.some((c) => c.from === from && c.to === to);
    }
    /**
     * 检查是否会创建循环引用
     */
    wouldCreateCycle(from, to) {
        const visited = new Set();
        const queue = [to];
        while (queue.length > 0) {
            const current = queue.shift();
            if (current === from) {
                return true;
            }
            if (visited.has(current)) {
                continue;
            }
            visited.add(current);
            const childConnections = this._connections.filter((c) => c.from === current && c.isNodeConnection());
            childConnections.forEach((conn) => queue.push(conn.to));
        }
        return false;
    }
    /**
     * 更新黑板
     */
    updateBlackboard(updater) {
        return new BehaviorTree(Array.from(this.nodes), this._connections, updater(this._blackboard), this._rootNodeId);
    }
    /**
     * 获取节点的子节点
     */
    getChildren(nodeId) {
        const node = this.getNode(nodeId);
        return node.children.map((childId) => this.getNode(childId));
    }
    /**
     * 获取节点的父节点
     */
    getParent(nodeId) {
        const parentConnection = this._connections.find((c) => c.to === nodeId && c.isNodeConnection());
        if (!parentConnection) {
            return null;
        }
        return this.getNode(parentConnection.from);
    }
    /**
     * 验证树的完整性
     */
    validateTree() {
        const rootNodes = this.nodes.filter((n) => n.isRoot());
        if (rootNodes.length > 1) {
            throw new ValidationError('行为树只能有一个根节点');
        }
        if (rootNodes.length === 1 && rootNodes[0] && this._rootNodeId !== rootNodes[0].id) {
            throw new ValidationError('根节点ID不匹配');
        }
        this._connections.forEach((conn) => {
            if (!this._nodes.has(conn.from)) {
                throw new NodeNotFoundError(conn.from);
            }
            if (!this._nodes.has(conn.to)) {
                throw new NodeNotFoundError(conn.to);
            }
        });
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return {
            nodes: this.nodes.map((n) => n.toObject()),
            connections: this._connections.map((c) => c.toObject()),
            blackboard: this._blackboard.toObject(),
            rootNodeId: this._rootNodeId
        };
    }
    /**
     * 从普通对象创建行为树
     */
    static fromObject(obj) {
        return new BehaviorTree(obj.nodes.map((n) => Node.fromObject(n)), obj.connections.map((c) => Connection.fromObject(c)), Blackboard.fromObject(obj.blackboard), obj.rootNodeId);
    }
    /**
     * 创建空行为树
     */
    static empty() {
        return new BehaviorTree();
    }
}

const useTreeStore = create((set, get) => ({
    isOpen: false,
    pendingFilePath: null,
    nodes: [],
    connections: [],
    blackboard: new Blackboard(),
    blackboardVariables: {},
    initialBlackboardVariables: {},
    initialNodesData: new Map(),
    forceUpdateCounter: 0,
    setNodes: (nodes) => set({ nodes }),
    updateNodes: (updater) => set((state) => ({
        nodes: updater(state.nodes)
    })),
    addNode: (node) => set((state) => ({
        nodes: [...state.nodes, node]
    })),
    removeNodes: (nodeIds) => set((state) => {
        const nodesToDelete = new Set(nodeIds);
        const remainingNodes = state.nodes
            .filter((n) => !nodesToDelete.has(n.id))
            .map((n) => {
            const newChildren = Array.from(n.children).filter((childId) => !nodesToDelete.has(childId));
            if (newChildren.length !== n.children.length) {
                return new Node(n.id, n.template, n.data, n.position, newChildren);
            }
            return n;
        });
        return { nodes: remainingNodes };
    }),
    updateNodePosition: (nodeId, position) => set((state) => ({
        nodes: state.nodes.map((n) => n.id === nodeId
            ? new Node(n.id, n.template, n.data, new Position(position.x, position.y), Array.from(n.children))
            : n)
    })),
    updateNodesPosition: (updates) => set((state) => ({
        nodes: state.nodes.map((node) => {
            const newPos = updates.get(node.id);
            return newPos
                ? new Node(node.id, node.template, node.data, new Position(newPos.x, newPos.y), Array.from(node.children))
                : node;
        })
    })),
    updateNodeData: (nodeId, data) => set((state) => ({
        nodes: state.nodes.map((n) => n.id === nodeId
            ? new Node(n.id, n.template, { ...n.data, ...data }, n.position, Array.from(n.children))
            : n)
    })),
    setConnections: (connections) => set({ connections }),
    addConnection: (connection) => set((state) => ({
        connections: [...state.connections, connection]
    })),
    removeConnections: (filter) => set((state) => ({
        connections: state.connections.filter((conn) => !filter(conn))
    })),
    setBlackboard: (blackboard) => set({ blackboard }),
    updateBlackboardVariable: (name, value) => set((state) => ({
        blackboardVariables: { ...state.blackboardVariables, [name]: value }
    })),
    setBlackboardVariables: (variables) => set({ blackboardVariables: variables }),
    setInitialBlackboardVariables: (variables) => set({ initialBlackboardVariables: variables }),
    saveNodesDataSnapshot: () => set((state) => {
        const snapshot = new Map();
        state.nodes.forEach((node) => {
            snapshot.set(node.id, { ...node.data });
        });
        return { initialNodesData: snapshot };
    }),
    restoreNodesData: () => set((state) => {
        const restoredNodes = state.nodes.map((node) => {
            const initialData = state.initialNodesData.get(node.id);
            if (initialData) {
                return new Node(node.id, node.template, { ...initialData }, node.position, Array.from(node.children));
            }
            return node;
        });
        return { nodes: restoredNodes };
    }),
    sortChildrenByPosition: () => set((state) => {
        const sortedNodes = state.nodes.map((node) => {
            if (node.children.length === 0)
                return node;
            const childrenWithPositions = Array.from(node.children)
                .map((childId) => {
                const childNode = state.nodes.find((n) => n.id === childId);
                return childNode ? { id: childId, x: childNode.position.x } : null;
            })
                .filter((item) => item !== null);
            childrenWithPositions.sort((a, b) => a.x - b.x);
            const sortedChildren = childrenWithPositions.map((item) => item.id);
            return new Node(node.id, node.template, node.data, node.position, sortedChildren);
        });
        return { nodes: sortedNodes };
    }),
    triggerForceUpdate: () => set((state) => ({
        forceUpdateCounter: state.forceUpdateCounter + 1
    })),
    exportToJSON: (metadata) => {
        const state = get();
        const now = new Date().toISOString();
        const data = {
            version: '1.0.0',
            metadata: {
                name: metadata.name,
                description: metadata.description,
                createdAt: now,
                modifiedAt: now
            },
            nodes: state.nodes.map((n) => n.toObject()),
            connections: state.connections.map((c) => c.toObject()),
            blackboard: state.blackboardVariables
        };
        return JSON.stringify(data, null, 2);
    },
    importFromJSON: (json) => {
        const data = JSON.parse(json);
        const blackboardData = data.blackboard || {};
        const loadedNodes = (data.nodes || []).map((nodeObj) => {
            const position = new Position(nodeObj.position.x, nodeObj.position.y);
            return new Node(nodeObj.id, nodeObj.template, nodeObj.data, position, nodeObj.children || []);
        });
        const loadedConnections = (data.connections || []).map((connObj) => {
            return new Connection(connObj.from, connObj.to, connObj.connectionType || 'node', connObj.fromProperty, connObj.toProperty);
        });
        const loadedBlackboard = Blackboard.fromObject(blackboardData);
        const newTree = new BehaviorTree(loadedNodes, loadedConnections, loadedBlackboard, loadedNodes[0]?.id || '');
        useBehaviorTreeDataStore.getState().setTree(newTree);
        set({
            nodes: loadedNodes,
            connections: loadedConnections,
            blackboard: loadedBlackboard,
            blackboardVariables: blackboardData,
            initialBlackboardVariables: blackboardData
        });
    },
    exportToRuntimeAsset: (metadata, format) => {
        const state = get();
        const editorFormat = {
            version: '1.0.0',
            metadata: {
                name: metadata.name,
                description: metadata.description,
                createdAt: new Date().toISOString(),
                modifiedAt: new Date().toISOString()
            },
            nodes: state.nodes.map((n) => n.toObject()),
            connections: state.connections.map((c) => c.toObject()),
            blackboard: state.blackboardVariables
        };
        const asset = EditorFormatConverter.toAsset(editorFormat, metadata);
        return BehaviorTreeAssetSerializer.serialize(asset, {
            format,
            pretty: format === 'json',
            validate: true
        });
    },
    setIsOpen: (isOpen) => set({ isOpen }),
    setPendingFilePath: (filePath) => set({ pendingFilePath: filePath }),
    reset: () => set({
        isOpen: false,
        pendingFilePath: null,
        nodes: [],
        connections: [],
        blackboard: new Blackboard(),
        blackboardVariables: {},
        initialBlackboardVariables: {},
        initialNodesData: new Map(),
        forceUpdateCounter: 0
    })
}));

const ROOT_NODE_ID = 'root-node';
const createRootNodeTemplate = () => ({
    type: 'root',
    displayName: '根节点',
    category: '根节点',
    icon: 'TreePine',
    description: '行为树根节点',
    color: '#FFD700',
    maxChildren: 1,
    defaultConfig: {
        nodeType: 'root'
    },
    properties: []
});
const createRootNode = () => {
    const template = createRootNodeTemplate();
    const position = new Position(400, 100);
    return new Node(ROOT_NODE_ID, template, { nodeType: 'root' }, position, []);
};

const createInitialTree = () => {
    const rootNode = createRootNode();
    return new BehaviorTree([rootNode], [], Blackboard.empty(), ROOT_NODE_ID);
};
/**
 * 行为树数据 Store
 * 实现 ITreeState 接口，供命令使用
 */
const useBehaviorTreeDataStore = create((set) => ({
    tree: createInitialTree(),
    setTree: (tree) => set({ tree }),
    reset: () => set({ tree: createInitialTree() })
}));
/**
 * TreeState 适配器
 * 将 Zustand Store 适配为 ITreeState 接口
 * 同步更新领域层和表现层的状态
 */
class TreeStateAdapter {
    getTree() {
        return useBehaviorTreeDataStore.getState().tree;
    }
    setTree(tree) {
        useBehaviorTreeDataStore.getState().setTree(tree);
        const nodes = Array.from(tree.nodes);
        const connections = Array.from(tree.connections);
        useTreeStore.getState().setNodes(nodes);
        useTreeStore.getState().setConnections(connections);
    }
}

const useCanvasStore = create((set) => ({
    offset: { x: 0, y: 0 },
    scale: 1,
    isPanning: false,
    panStart: { x: 0, y: 0 },
    setOffset: (offset) => set({ offset }),
    setScale: (scale) => set({ scale }),
    setIsPanning: (isPanning) => set({ isPanning }),
    setPanStart: (panStart) => set({ panStart }),
    resetView: () => set({ offset: { x: 0, y: 0 }, scale: 1 })
}));

const useSelectionStore = create((set) => ({
    selectedNodeIds: [],
    isBoxSelecting: false,
    boxSelectStart: null,
    boxSelectEnd: null,
    setSelectedNodeIds: (nodeIds) => set({ selectedNodeIds: nodeIds }),
    toggleNodeSelection: (nodeId) => set((state) => {
        const isSelected = state.selectedNodeIds.includes(nodeId);
        return {
            selectedNodeIds: isSelected
                ? state.selectedNodeIds.filter(id => id !== nodeId)
                : [...state.selectedNodeIds, nodeId]
        };
    }),
    clearSelection: () => set({ selectedNodeIds: [] }),
    setIsBoxSelecting: (isSelecting) => set({ isBoxSelecting: isSelecting }),
    setBoxSelectStart: (pos) => set({ boxSelectStart: pos }),
    setBoxSelectEnd: (pos) => set({ boxSelectEnd: pos }),
    clearBoxSelect: () => set({
        isBoxSelecting: false,
        boxSelectStart: null,
        boxSelectEnd: null
    })
}));

const useExecutionStore = create((set) => ({
    isExecuting: false,
    nodeExecutionStatuses: new Map(),
    nodeExecutionOrders: new Map(),
    setIsExecuting: (isExecuting) => set({ isExecuting }),
    setNodeExecutionStatus: (nodeId, status) => set((state) => {
        const newStatuses = new Map(state.nodeExecutionStatuses);
        newStatuses.set(nodeId, status);
        return { nodeExecutionStatuses: newStatuses };
    }),
    updateNodeExecutionStatuses: (statuses, orders) => set((state) => ({
        nodeExecutionStatuses: new Map(statuses),
        nodeExecutionOrders: orders ? new Map(orders) : state.nodeExecutionOrders
    })),
    clearNodeExecutionStatuses: () => set({
        nodeExecutionStatuses: new Map(),
        nodeExecutionOrders: new Map()
    })
}));

const useInteractionStore = create((set) => ({
    draggingNodeId: null,
    dragStartPositions: new Map(),
    isDraggingNode: false,
    dragDelta: { dx: 0, dy: 0 },
    connectingFrom: null,
    connectingFromProperty: null,
    connectingToPos: null,
    startDragging: (nodeId, startPositions) => set({
        draggingNodeId: nodeId,
        dragStartPositions: new Map(startPositions),
        isDraggingNode: true
    }),
    stopDragging: () => set({
        draggingNodeId: null,
        dragStartPositions: new Map(),
        isDraggingNode: false,
        dragDelta: { dx: 0, dy: 0 }
    }),
    setIsDraggingNode: (isDragging) => set({ isDraggingNode: isDragging }),
    setDragDelta: (delta) => set({ dragDelta: delta }),
    setConnectingFrom: (nodeId) => set({ connectingFrom: nodeId }),
    setConnectingFromProperty: (propertyName) => set({ connectingFromProperty: propertyName }),
    setConnectingToPos: (pos) => set({ connectingToPos: pos }),
    clearConnecting: () => set({
        connectingFrom: null,
        connectingFromProperty: null,
        connectingToPos: null
    })
}));

var __decorate$1 = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
let BehaviorTreeService = class BehaviorTreeService {
    async createNew() {
        useTreeStore.getState().reset();
        useBehaviorTreeDataStore.getState().reset();
    }
    async loadFromFile(filePath) {
        console.log('[BehaviorTreeService] Loading tree from:', filePath);
    }
    async saveToFile(filePath) {
        console.log('[BehaviorTreeService] Saving tree to:', filePath);
    }
    getCurrentTree() {
        return useBehaviorTreeDataStore.getState().tree;
    }
    setTree(tree) {
        useBehaviorTreeDataStore.getState().setTree(tree);
    }
    dispose() {
        console.log('[BehaviorTreeService] Disposing service');
    }
};
BehaviorTreeService = __decorate$1([
    singleton()
], BehaviorTreeService);

/**
 * 全局黑板 TypeScript 类型生成器
 *
 * 将全局黑板配置导出为 TypeScript 类型定义，提供：
 * - 编译时类型检查
 * - IDE 自动补全
 * - 避免拼写错误
 * - 重构友好
 */
class GlobalBlackboardTypeGenerator {
    /**
     * 生成 TypeScript 类型定义代码
     *
     * @param config 全局黑板配置
     * @param options 生成选项
     * @returns TypeScript 代码字符串
     *
     * @example
     * ```typescript
     * // 使用默认选项
     * const code = GlobalBlackboardTypeGenerator.generate(config);
     *
     * // 自定义命名
     * const code = GlobalBlackboardTypeGenerator.generate(config, {
     *     constantsName: 'GameVars',
     *     wrapperClassName: 'GameBlackboard'
     * });
     *
     * // 只生成接口和类型别名，不生成包装类
     * const code = GlobalBlackboardTypeGenerator.generate(config, {
     *     includeWrapperClass: false,
     *     includeDefaults: false
     * });
     * ```
     */
    static generate(config, options) {
        const opts = { ...this.DEFAULT_OPTIONS, ...options };
        const now = new Date().toLocaleString('zh-CN', { hour12: false });
        const variables = config.variables || [];
        const parts = [];
        // 生成文件头部注释
        parts.push(this.generateHeader(now, opts));
        // 根据配置生成各个部分
        if (opts.includeConstants) {
            parts.push(this.generateConstants(variables, opts));
        }
        if (opts.includeInterface) {
            parts.push(this.generateInterface(variables, opts));
        }
        if (opts.includeTypeAlias) {
            parts.push(this.generateTypeAliases(opts));
        }
        if (opts.includeWrapperClass) {
            parts.push(this.generateTypedClass(opts));
        }
        if (opts.includeDefaults) {
            parts.push(this.generateDefaults(variables, opts));
        }
        // 组合所有部分
        let code = parts.join('\n\n');
        // 添加文件末尾换行
        if (opts.trailingNewline && !code.endsWith('\n')) {
            code += '\n';
        }
        return code;
    }
    /**
     * 生成文件头部注释
     */
    static generateHeader(timestamp, opts) {
        const customHeader = opts.customHeader || `/**
 * 全局黑板类型定义
 *
 * ⚠️ 此文件由编辑器自动生成，请勿手动修改！
 * 生成时间: ${timestamp}
 */`;
        return `${customHeader}

import { GlobalBlackboardService } from '${opts.importPath}';`;
    }
    /**
     * 生成常量对象
     */
    static generateConstants(variables, opts) {
        const quote = opts.quoteStyle === 'single' ? "'" : '"';
        if (variables.length === 0) {
            return `/**
 * 全局变量名称常量
 */
export const ${opts.constantsName} = {} as const;`;
        }
        // 按命名空间分组
        const grouped = this.groupVariablesByNamespace(variables);
        if (Object.keys(grouped).length === 1 && grouped[''] !== undefined) {
            // 无命名空间，扁平结构
            const entries = variables
                .map((v) => `    ${this.transformName(v.name, opts.constantCase)}: ${quote}${v.name}${quote}`)
                .join(',\n');
            return `/**
 * 全局变量名称常量
 * 使用常量避免拼写错误
 */
export const ${opts.constantsName} = {
${entries}
} as const;`;
        }
        else {
            // 有命名空间，分组结构
            const namespaces = Object.entries(grouped)
                .map(([namespace, vars]) => {
                if (namespace === '') {
                    // 根级别变量
                    return vars
                        .map((v) => `    ${this.transformName(v.name, opts.constantCase)}: ${quote}${v.name}${quote}`)
                        .join(',\n');
                }
                else {
                    // 命名空间变量
                    const nsName = this.toPascalCase(namespace);
                    const entries = vars
                        .map((v) => {
                        const shortName = v.name.substring(namespace.length + 1);
                        return `        ${this.transformName(shortName, opts.constantCase)}: ${quote}${v.name}${quote}`;
                    })
                        .join(',\n');
                    return `    ${nsName}: {\n${entries}\n    }`;
                }
            })
                .join(',\n');
            return `/**
 * 全局变量名称常量
 * 使用常量避免拼写错误
 */
export const ${opts.constantsName} = {
${namespaces}
} as const;`;
        }
    }
    /**
     * 生成接口定义
     */
    static generateInterface(variables, opts) {
        if (variables.length === 0) {
            return `/**
 * 全局变量类型定义
 */
export interface ${opts.interfaceName} {}`;
        }
        const properties = variables
            .map((v) => {
            const tsType = this.mapBlackboardTypeToTS(v.type);
            const comment = v.description ? `    /** ${v.description} */\n` : '';
            return `${comment}    ${v.name}: ${tsType};`;
        })
            .join('\n');
        return `/**
 * 全局变量类型定义
 */
export interface ${opts.interfaceName} {
${properties}
}`;
    }
    /**
     * 生成类型别名
     */
    static generateTypeAliases(opts) {
        return `/**
 * 全局变量名称联合类型
 */
export type ${opts.typeAliasName} = keyof ${opts.interfaceName};`;
    }
    /**
     * 生成类型安全包装类
     */
    static generateTypedClass(opts) {
        return `/**
 * 类型安全的全局黑板服务包装器
 *
 * @example
 * \`\`\`typescript
 * // 游戏运行时使用
 * const service = core.services.resolve(GlobalBlackboardService);
 * const gb = new ${opts.wrapperClassName}(service);
 *
 * // 类型安全的获取
 * const hp = gb.getValue('playerHP');  // 类型: number | undefined
 *
 * // 类型安全的设置
 * gb.setValue('playerHP', 100);  // ✅ 正确
 * gb.setValue('playerHP', 'invalid');  // ❌ 编译错误
 * \`\`\`
 */
export class ${opts.wrapperClassName} {
    constructor(private service: GlobalBlackboardService) {}

    /**
     * 获取全局变量（类型安全）
     */
    getValue<K extends ${opts.typeAliasName}>(
        name: K
    ): ${opts.interfaceName}[K] | undefined {
        return this.service.getValue(name);
    }

    /**
     * 设置全局变量（类型安全）
     */
    setValue<K extends ${opts.typeAliasName}>(
        name: K,
        value: ${opts.interfaceName}[K]
    ): boolean {
        return this.service.setValue(name, value);
    }

    /**
     * 检查全局变量是否存在
     */
    hasVariable(name: ${opts.typeAliasName}): boolean {
        return this.service.hasVariable(name);
    }

    /**
     * 获取所有变量名
     */
    getVariableNames(): ${opts.typeAliasName}[] {
        return this.service.getVariableNames() as ${opts.typeAliasName}[];
    }
}`;
    }
    /**
     * 生成默认值配置
     */
    static generateDefaults(variables, opts) {
        if (variables.length === 0) {
            return `/**
 * 默认值配置
 */
export const ${opts.defaultsName}: ${opts.interfaceName} = {};`;
        }
        const properties = variables
            .map((v) => {
            const value = this.formatValue(v.value, v.type, opts);
            return `    ${v.name}: ${value}`;
        })
            .join(',\n');
        return `/**
 * 默认值配置
 *
 * 可在游戏启动时用于初始化全局黑板
 *
 * @example
 * \`\`\`typescript
 * // 获取服务
 * const service = core.services.resolve(GlobalBlackboardService);
 *
 * // 初始化配置
 * const config = {
 *     version: '1.0',
 *     variables: Object.entries(${opts.defaultsName}).map(([name, value]) => ({
 *         name,
 *         type: typeof value as BlackboardValueType,
 *         value
 *     }))
 * };
 * service.importConfig(config);
 * \`\`\`
 */
export const ${opts.defaultsName}: ${opts.interfaceName} = {
${properties}
};`;
    }
    /**
     * 按命名空间分组变量
     */
    static groupVariablesByNamespace(variables) {
        const groups = { '': [] };
        for (const variable of variables) {
            const dotIndex = variable.name.indexOf('.');
            if (dotIndex === -1) {
                groups[''].push(variable);
            }
            else {
                const namespace = variable.name.substring(0, dotIndex);
                if (!groups[namespace]) {
                    groups[namespace] = [];
                }
                groups[namespace].push(variable);
            }
        }
        return groups;
    }
    /**
     * 将变量名转换为常量名（UPPER_SNAKE_CASE）
     */
    static toConstantName(name) {
        // player.hp -> PLAYER_HP
        // playerHP -> PLAYER_HP
        return name
            .replace(/\./g, '_')
            .replace(/([a-z])([A-Z])/g, '$1_$2')
            .toUpperCase();
    }
    /**
     * 转换为 PascalCase
     */
    static toPascalCase(str) {
        return str
            .split(/[._-]/)
            .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
            .join('');
    }
    /**
     * 映射黑板类型到 TypeScript 类型
     */
    static mapBlackboardTypeToTS(type) {
        switch (type) {
            case BlackboardValueType.Number:
                return 'number';
            case BlackboardValueType.String:
                return 'string';
            case BlackboardValueType.Boolean:
                return 'boolean';
            case BlackboardValueType.Vector2:
                return '{ x: number; y: number }';
            case BlackboardValueType.Vector3:
                return '{ x: number; y: number; z: number }';
            case BlackboardValueType.Object:
                return 'any';
            case BlackboardValueType.Array:
                return 'any[]';
            default:
                return 'any';
        }
    }
    /**
     * 格式化值为 TypeScript 字面量
     */
    static formatValue(value, type, opts) {
        if (value === null || value === undefined) {
            return 'undefined';
        }
        const quote = opts.quoteStyle === 'single' ? "'" : '"';
        const escapeRegex = opts.quoteStyle === 'single' ? /'/g : /"/g;
        const escapeChar = opts.quoteStyle === 'single' ? "\\'" : '\\"';
        switch (type) {
            case BlackboardValueType.String:
                return `${quote}${value.toString().replace(escapeRegex, escapeChar)}${quote}`;
            case BlackboardValueType.Number:
            case BlackboardValueType.Boolean:
                return String(value);
            case BlackboardValueType.Vector2:
                if (typeof value === 'object' && value.x !== undefined && value.y !== undefined) {
                    return `{ x: ${value.x}, y: ${value.y} }`;
                }
                return '{ x: 0, y: 0 }';
            case BlackboardValueType.Vector3:
                if (typeof value === 'object' && value.x !== undefined && value.y !== undefined && value.z !== undefined) {
                    return `{ x: ${value.x}, y: ${value.y}, z: ${value.z} }`;
                }
                return '{ x: 0, y: 0, z: 0 }';
            case BlackboardValueType.Array:
                return '[]';
            case BlackboardValueType.Object:
                return '{}';
            default:
                return 'undefined';
        }
    }
    /**
     * 根据指定的大小写风格转换变量名
     */
    static transformName(name, caseStyle) {
        switch (caseStyle) {
            case 'UPPER_SNAKE':
                return this.toConstantName(name);
            case 'camelCase':
                return this.toCamelCase(name);
            case 'PascalCase':
                return this.toPascalCase(name);
            default:
                return name;
        }
    }
    /**
     * 转换为 camelCase
     */
    static toCamelCase(str) {
        const parts = str.split(/[._-]/);
        if (parts.length === 0)
            return str;
        return (parts[0] || '').toLowerCase() + parts.slice(1)
            .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
            .join('');
    }
}
/**
 * 默认生成选项
 */
GlobalBlackboardTypeGenerator.DEFAULT_OPTIONS = {
    constantCase: 'UPPER_SNAKE',
    constantsName: 'GlobalVars',
    interfaceName: 'GlobalBlackboardTypes',
    typeAliasName: 'GlobalVariableName',
    wrapperClassName: 'TypedGlobalBlackboard',
    defaultsName: 'GlobalBlackboardDefaults',
    importPath: '@esengine/behavior-tree',
    includeConstants: true,
    includeInterface: true,
    includeTypeAlias: true,
    includeWrapperClass: true,
    includeDefaults: true,
    customHeader: '',
    quoteStyle: 'single',
    trailingNewline: true
};

class BehaviorTreeCompiler {
    constructor() {
        this.id = 'behavior-tree';
        this.name = '行为树编译器';
        this.description = '将行为树文件编译为运行时资产和TypeScript类型定义';
        this.projectPath = null;
    }
    async compile(options, context) {
        this.projectPath = context.projectPath;
        const fileSystem = context.moduleContext.fileSystem;
        if (!this.projectPath) {
            return {
                success: false,
                message: '错误：没有打开的项目',
                errors: ['请先打开一个项目']
            };
        }
        try {
            const outputFiles = [];
            const errors = [];
            if (options.mode === 'workspace') {
                for (const fileId of options.selectedFiles) {
                    const format = options.fileFormats.get(fileId) || 'binary';
                    const result = await this.compileFile(fileId, options.assetOutputPath, options.typeOutputPath, format, fileSystem);
                    if (result.success) {
                        outputFiles.push(...(result.outputFiles || []));
                    }
                    else {
                        errors.push(`${fileId}: ${result.message}`);
                    }
                }
                const globalTypeResult = await this.generateGlobalBlackboardTypes(options.typeOutputPath, fileSystem);
                if (globalTypeResult.success) {
                    outputFiles.push(...(globalTypeResult.outputFiles || []));
                }
                else {
                    errors.push(globalTypeResult.message);
                }
            }
            else {
                const currentFileName = this.getCurrentFileName();
                if (!currentFileName) {
                    return {
                        success: false,
                        message: '错误：没有打开的行为树文件',
                        errors: ['请先打开一个行为树文件']
                    };
                }
                const format = options.fileFormats.get(currentFileName) || 'binary';
                const result = await this.compileFile(currentFileName, options.assetOutputPath, options.typeOutputPath, format, fileSystem);
                if (result.success) {
                    outputFiles.push(...(result.outputFiles || []));
                }
                else {
                    errors.push(result.message);
                }
            }
            if (errors.length > 0) {
                return {
                    success: false,
                    message: `编译完成，但有 ${errors.length} 个错误`,
                    outputFiles,
                    errors
                };
            }
            return {
                success: true,
                message: `成功编译 ${outputFiles.length} 个文件`,
                outputFiles
            };
        }
        catch (error) {
            return {
                success: false,
                message: `编译失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    async compileFile(fileId, assetOutputPath, typeOutputPath, format, fileSystem) {
        try {
            const btreePath = `${this.projectPath}/.ecs/behaviors/${fileId}.btree`;
            const fileContent = await fileSystem.readFile(btreePath);
            const treeData = JSON.parse(fileContent);
            const treeStore = useTreeStore.getState();
            const runtimeAsset = treeStore.exportToRuntimeAsset({
                name: fileId,
                description: treeData.metadata?.description || ''
            }, format);
            const extension = format === 'json' ? '.btree.json' : '.btree.bin';
            const assetPath = `${assetOutputPath}/${fileId}${extension}`;
            if (format === 'json') {
                await fileSystem.writeFile(assetPath, runtimeAsset);
            }
            else {
                await fileSystem.writeBinary(assetPath, runtimeAsset);
            }
            const blackboardVars = treeData.blackboard || {};
            const typeContent = this.generateBlackboardTypes(fileId, blackboardVars);
            const typePath = `${typeOutputPath}/${fileId}.d.ts`;
            await fileSystem.writeFile(typePath, typeContent);
            return {
                success: true,
                message: `成功编译 ${fileId}`,
                outputFiles: [assetPath, typePath]
            };
        }
        catch (error) {
            return {
                success: false,
                message: `编译 ${fileId} 失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    async generateGlobalBlackboardTypes(typeOutputPath, fileSystem) {
        try {
            if (!this.projectPath) {
                throw new Error('No project path');
            }
            const btreeFiles = await fileSystem.scanFiles(`${this.projectPath}/.ecs/behaviors`, '*.btree');
            const variables = [];
            for (const fileId of btreeFiles) {
                const btreePath = `${this.projectPath}/.ecs/behaviors/${fileId}.btree`;
                const fileContent = await fileSystem.readFile(btreePath);
                const treeData = JSON.parse(fileContent);
                const blackboard = treeData.blackboard || {};
                for (const [key, value] of Object.entries(blackboard)) {
                    variables.push({
                        name: key,
                        type: this.inferType(value),
                        defaultValue: value
                    });
                }
            }
            const config = {
                version: '1.0.0',
                variables
            };
            const typeContent = GlobalBlackboardTypeGenerator.generate(config);
            const typePath = `${typeOutputPath}/GlobalBlackboard.ts`;
            await fileSystem.writeFile(typePath, typeContent);
            return {
                success: true,
                message: '成功生成全局黑板类型',
                outputFiles: [typePath]
            };
        }
        catch (error) {
            return {
                success: false,
                message: `生成全局黑板类型失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    generateBlackboardTypes(behaviorName, blackboardVars) {
        const lines = [];
        lines.push(`export interface ${behaviorName}Blackboard {`);
        for (const [key, value] of Object.entries(blackboardVars)) {
            const type = this.inferType(value);
            lines.push(`    ${key}: ${type};`);
        }
        lines.push('}');
        return lines.join('\n');
    }
    inferType(value) {
        if (value === null)
            return 'null';
        if (value === undefined)
            return 'undefined';
        if (typeof value === 'string')
            return 'string';
        if (typeof value === 'number')
            return 'number';
        if (typeof value === 'boolean')
            return 'boolean';
        if (Array.isArray(value))
            return 'unknown[]';
        if (typeof value === 'object')
            return 'Record<string, unknown>';
        return 'unknown';
    }
    getCurrentFileName() {
        const treeStore = useTreeStore.getState();
        const pendingPath = treeStore.pendingFilePath;
        if (!pendingPath)
            return null;
        const fileName = pendingPath.split(/[/\\]/).pop();
        if (!fileName)
            return null;
        return fileName.replace('.btree', '');
    }
    validateOptions(options) {
        if (!options.assetOutputPath) {
            return '请选择资产输出路径';
        }
        if (!options.typeOutputPath) {
            return '请选择类型定义输出路径';
        }
        if (options.mode === 'workspace' && options.selectedFiles.length === 0) {
            return '请至少选择一个文件';
        }
        if (options.mode === 'single' && !this.getCurrentFileName()) {
            return '没有打开的行为树文件';
        }
        return null;
    }
    createConfigUI(onOptionsChange, context) {
        return jsx(BehaviorTreeCompileConfigUI, { onOptionsChange: onOptionsChange, context: context });
    }
}
function BehaviorTreeCompileConfigUI({ onOptionsChange, context }) {
    const { projectPath, moduleContext } = context;
    const { fileSystem, dialog } = moduleContext;
    const [mode, setMode] = useState('workspace');
    const [assetOutputPath, setAssetOutputPath] = useState('');
    const [typeOutputPath, setTypeOutputPath] = useState('');
    const [availableFiles, setAvailableFiles] = useState([]);
    const [selectedFiles, setSelectedFiles] = useState(new Set());
    const [fileFormats, setFileFormats] = useState(new Map());
    const [selectAll, setSelectAll] = useState(true);
    useEffect(() => {
        const loadFiles = async () => {
            if (projectPath) {
                const files = await fileSystem.scanFiles(`${projectPath}/.ecs/behaviors`, '*.btree');
                setAvailableFiles(files);
                setSelectedFiles(new Set(files));
                const formats = new Map();
                files.forEach((file) => formats.set(file, 'binary'));
                setFileFormats(formats);
            }
        };
        loadFiles();
        const savedAssetPath = localStorage.getItem('export-asset-path');
        const savedTypePath = localStorage.getItem('export-type-path');
        if (savedAssetPath)
            setAssetOutputPath(savedAssetPath);
        if (savedTypePath)
            setTypeOutputPath(savedTypePath);
    }, [projectPath]);
    useEffect(() => {
        onOptionsChange({
            mode,
            assetOutputPath,
            typeOutputPath,
            selectedFiles: mode === 'workspace' ? Array.from(selectedFiles) : [],
            fileFormats
        });
    }, [mode, assetOutputPath, typeOutputPath, selectedFiles, fileFormats, onOptionsChange]);
    const handleBrowseAssetPath = async () => {
        const selected = await dialog.openDialog({
            directory: true,
            multiple: false,
            title: '选择资产输出目录',
            defaultPath: assetOutputPath || projectPath || undefined
        });
        if (selected && typeof selected === 'string') {
            setAssetOutputPath(selected);
            localStorage.setItem('export-asset-path', selected);
        }
    };
    const handleBrowseTypePath = async () => {
        const selected = await dialog.openDialog({
            directory: true,
            multiple: false,
            title: '选择类型定义输出目录',
            defaultPath: typeOutputPath || projectPath || undefined
        });
        if (selected && typeof selected === 'string') {
            setTypeOutputPath(selected);
            localStorage.setItem('export-type-path', selected);
        }
    };
    const handleSelectAll = () => {
        if (selectAll) {
            setSelectedFiles(new Set());
            setSelectAll(false);
        }
        else {
            setSelectedFiles(new Set(availableFiles));
            setSelectAll(true);
        }
    };
    const handleToggleFile = (file) => {
        const newSelected = new Set(selectedFiles);
        if (newSelected.has(file)) {
            newSelected.delete(file);
        }
        else {
            newSelected.add(file);
        }
        setSelectedFiles(newSelected);
        setSelectAll(newSelected.size === availableFiles.length);
    };
    const handleFileFormatChange = (file, format) => {
        const newFormats = new Map(fileFormats);
        newFormats.set(file, format);
        setFileFormats(newFormats);
    };
    return (jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: '16px' }, children: [jsxs("div", { style: { display: 'flex', gap: '8px', borderBottom: '1px solid #3e3e3e', paddingBottom: '8px' }, children: [jsxs("button", { onClick: () => setMode('workspace'), style: {
                            flex: 1,
                            padding: '8px 16px',
                            background: mode === 'workspace' ? '#0e639c' : '#3a3a3a',
                            border: 'none',
                            borderRadius: '4px',
                            color: '#fff',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            fontSize: '13px'
                        }, children: [jsx(FolderTree, { size: 16 }), "\u5DE5\u4F5C\u533A\u7F16\u8BD1"] }), jsxs("button", { onClick: () => setMode('single'), style: {
                            flex: 1,
                            padding: '8px 16px',
                            background: mode === 'single' ? '#0e639c' : '#3a3a3a',
                            border: 'none',
                            borderRadius: '4px',
                            color: '#fff',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            fontSize: '13px'
                        }, children: [jsx(File, { size: 16 }), "\u5F53\u524D\u6587\u4EF6"] })] }), jsxs("div", { children: [jsx("div", { style: { marginBottom: '8px', fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: "\u8D44\u4EA7\u8F93\u51FA\u8DEF\u5F84" }), jsxs("div", { style: { display: 'flex', gap: '8px' }, children: [jsx("input", { type: "text", value: assetOutputPath, onChange: (e) => setAssetOutputPath(e.target.value), placeholder: "\u9009\u62E9\u8D44\u4EA7\u8F93\u51FA\u76EE\u5F55...", style: {
                                    flex: 1,
                                    padding: '8px 12px',
                                    background: '#2d2d2d',
                                    border: '1px solid #3a3a3a',
                                    borderRadius: '4px',
                                    color: '#ccc',
                                    fontSize: '12px'
                                } }), jsxs("button", { onClick: handleBrowseAssetPath, style: {
                                    padding: '8px 16px',
                                    background: '#0e639c',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }, children: [jsx(FolderOpen, { size: 14 }), "\u6D4F\u89C8"] })] })] }), jsxs("div", { children: [jsx("div", { style: { marginBottom: '8px', fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: "TypeScript \u7C7B\u578B\u5B9A\u4E49\u8F93\u51FA\u8DEF\u5F84" }), jsxs("div", { style: { display: 'flex', gap: '8px' }, children: [jsx("input", { type: "text", value: typeOutputPath, onChange: (e) => setTypeOutputPath(e.target.value), placeholder: "\u9009\u62E9\u7C7B\u578B\u5B9A\u4E49\u8F93\u51FA\u76EE\u5F55...", style: {
                                    flex: 1,
                                    padding: '8px 12px',
                                    background: '#2d2d2d',
                                    border: '1px solid #3a3a3a',
                                    borderRadius: '4px',
                                    color: '#ccc',
                                    fontSize: '12px'
                                } }), jsxs("button", { onClick: handleBrowseTypePath, style: {
                                    padding: '8px 16px',
                                    background: '#0e639c',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }, children: [jsx(FolderOpen, { size: 14 }), "\u6D4F\u89C8"] })] })] }), mode === 'workspace' && availableFiles.length > 0 && (jsxs("div", { children: [jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }, children: [jsxs("div", { style: { fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: ["\u9009\u62E9\u6587\u4EF6 (", selectedFiles.size, "/", availableFiles.length, ")"] }), jsx("button", { onClick: handleSelectAll, style: {
                                    padding: '4px 12px',
                                    background: '#3a3a3a',
                                    border: 'none',
                                    borderRadius: '3px',
                                    color: '#ccc',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                }, children: selectAll ? '取消全选' : '全选' })] }), jsx("div", { style: { maxHeight: '200px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '4px' }, children: availableFiles.map((file) => (jsxs("div", { style: {
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                padding: '8px',
                                background: selectedFiles.has(file) ? '#2a2d2e' : '#1e1e1e',
                                border: `1px solid ${selectedFiles.has(file) ? '#0e639c' : '#3a3a3a'}`,
                                borderRadius: '4px',
                                fontSize: '12px'
                            }, children: [jsx("input", { type: "checkbox", checked: selectedFiles.has(file), onChange: () => handleToggleFile(file), style: { cursor: 'pointer' } }), jsx(File, { size: 14, style: { color: '#ab47bc' } }), jsxs("span", { style: { flex: 1, color: '#ccc' }, children: [file, ".btree"] }), jsxs("select", { value: fileFormats.get(file) || 'binary', onChange: (e) => handleFileFormatChange(file, e.target.value), onClick: (e) => e.stopPropagation(), style: {
                                        padding: '4px 8px',
                                        background: '#2d2d2d',
                                        border: '1px solid #3a3a3a',
                                        borderRadius: '3px',
                                        color: '#ccc',
                                        fontSize: '11px',
                                        cursor: 'pointer'
                                    }, children: [jsx("option", { value: "binary", children: "\u4E8C\u8FDB\u5236" }), jsx("option", { value: "json", children: "JSON" })] })] }, file))) })] }))] }));
}

/**
 * Behavior Tree Editor Plugin
 */
class BehaviorTreePlugin {
    constructor() {
        this.name = '@esengine/behavior-tree-editor';
        this.version = '1.0.0';
        this.displayName = 'Behavior Tree Editor';
        this.category = EditorPluginCategory.Tool;
        this.description = 'Visual behavior tree editor for game AI development';
        this.icon = 'GitBranch';
    }
    async install(_core, services) {
        console.log('[BehaviorTreePlugin] Installing behavior tree editor plugin...');
        this.registerServices(services);
        this.registerCompilers(services);
        console.log('[BehaviorTreePlugin] Behavior tree editor plugin installed');
    }
    async uninstall() {
        console.log('[BehaviorTreePlugin] Uninstalling behavior tree editor plugin...');
    }
    registerServices(services) {
        services.registerSingleton(BehaviorTreeService);
        console.log('[BehaviorTreePlugin] Services registered');
    }
    registerCompilers(services) {
        const compilerRegistry = services.resolve(CompilerRegistry);
        if (compilerRegistry) {
            const compiler = new BehaviorTreeCompiler();
            compilerRegistry.register(compiler);
            console.log('[BehaviorTreePlugin] Compiler registered');
        }
    }
}

/**
 * 行为树节点Inspector提供器
 * 为行为树节点提供检视面板
 */
class BehaviorTreeNodeInspectorProvider {
    constructor() {
        this.id = 'behavior-tree-node-inspector';
        this.name = '行为树节点检视器';
        this.priority = 100;
    }
    canHandle(target) {
        return target instanceof Node ||
            (typeof target === 'object' &&
                target !== null &&
                'template' in target &&
                'data' in target &&
                'position' in target &&
                'children' in target);
    }
    render(node, context) {
        return (jsxs("div", { className: "entity-inspector", children: [jsx("div", { className: "inspector-header", children: jsx("span", { className: "entity-name", children: node.template.displayName || '未命名节点' }) }), jsxs("div", { className: "inspector-content", children: [jsxs("div", { className: "inspector-section", children: [jsx("div", { className: "section-title", children: "\u57FA\u672C\u4FE1\u606F" }), jsxs("div", { className: "property-field", children: [jsx("label", { className: "property-label", children: "\u8282\u70B9\u7C7B\u578B" }), jsx("span", { className: "property-value-text", children: node.template.type })] }), jsxs("div", { className: "property-field", children: [jsx("label", { className: "property-label", children: "\u5206\u7C7B" }), jsx("span", { className: "property-value-text", children: node.template.category })] }), node.template.description && (jsxs("div", { className: "property-field", children: [jsx("label", { className: "property-label", children: "\u63CF\u8FF0" }), jsx("span", { className: "property-value-text", style: { color: '#999' }, children: node.template.description })] }))] }), jsxs("div", { className: "inspector-section", children: [jsx("div", { className: "section-title", children: "\u8C03\u8BD5\u4FE1\u606F" }), jsxs("div", { className: "property-field", children: [jsx("label", { className: "property-label", children: "\u8282\u70B9ID" }), jsx("span", { className: "property-value-text", style: {
                                                fontFamily: 'Consolas, Monaco, monospace',
                                                color: '#666',
                                                fontSize: '11px'
                                            }, children: node.id })] }), jsxs("div", { className: "property-field", children: [jsx("label", { className: "property-label", children: "\u4F4D\u7F6E" }), jsxs("span", { className: "property-value-text", style: { color: '#999' }, children: ["(", node.position.x.toFixed(0), ", ", node.position.y.toFixed(0), ")"] })] })] })] })] }));
    }
}

var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
let BehaviorTreeModule = class BehaviorTreeModule {
    constructor() {
        this.id = 'behavior-tree';
        this.name = 'Behavior Tree Editor';
        this.version = '1.0.0';
    }
    async load(context) {
        console.log('[BehaviorTreeModule] Loading behavior tree editor module...');
        this.registerServices(context);
        this.registerCompilers();
        this.registerInspectors(context);
        this.registerCommands(context);
        this.registerPanels(context);
        this.subscribeEvents(context);
        console.log('[BehaviorTreeModule] Behavior tree editor module loaded');
    }
    registerServices(context) {
        context.container.register(BehaviorTreeService, { useClass: BehaviorTreeService });
        console.log('[BehaviorTreeModule] Services registered');
    }
    registerCompilers() {
        const compilerRegistry = Core.services.resolve(CompilerRegistry);
        if (compilerRegistry) {
            const compiler = new BehaviorTreeCompiler();
            compilerRegistry.register(compiler);
            console.log('[BehaviorTreeModule] Compiler registered');
        }
    }
    registerInspectors(context) {
        const provider = new BehaviorTreeNodeInspectorProvider();
        context.inspectorRegistry.register(provider);
        console.log('[BehaviorTreeModule] Inspector provider registered');
    }
    async unload() {
        console.log('[BehaviorTreeModule] Unloading behavior tree editor module...');
    }
    registerCommands(context) {
        context.commands.register({
            id: 'behavior-tree.new',
            label: 'New Behavior Tree',
            icon: 'file-plus',
            execute: async () => {
                const service = context.container.resolve(BehaviorTreeService);
                await service.createNew();
            }
        });
        context.commands.register({
            id: 'behavior-tree.open',
            label: 'Open Behavior Tree',
            icon: 'folder-open',
            execute: async () => {
                console.log('Open behavior tree');
            }
        });
        context.commands.register({
            id: 'behavior-tree.save',
            label: 'Save Behavior Tree',
            icon: 'save',
            keybinding: { key: 'S', ctrl: true },
            execute: async () => {
                console.log('Save behavior tree');
            }
        });
    }
    registerPanels(context) {
        console.log('[BehaviorTreeModule] Registering panels...');
    }
    subscribeEvents(context) {
        // 文件加载由 BehaviorTreeEditorPanel 处理
    }
};
BehaviorTreeModule = __decorate([
    singleton()
], BehaviorTreeModule);

/**
 * 行为树验证服务
 * 实现所有业务验证规则
 */
class TreeValidator {
    /**
     * 验证整个行为树
     */
    validateTree(tree) {
        const errors = [];
        if (!tree.rootNodeId) {
            errors.push({
                message: '行为树必须有一个根节点'
            });
        }
        const rootNodes = tree.nodes.filter((n) => n.isRoot());
        if (rootNodes.length > 1) {
            errors.push({
                message: '行为树只能有一个根节点',
                nodeId: rootNodes.map((n) => n.id).join(', ')
            });
        }
        tree.nodes.forEach((node) => {
            const nodeValidation = this.validateNode(node);
            errors.push(...nodeValidation.errors);
        });
        tree.connections.forEach((connection) => {
            const connValidation = this.validateConnection(connection, tree);
            errors.push(...connValidation.errors);
        });
        const cycleValidation = this.validateNoCycles(tree);
        errors.push(...cycleValidation.errors);
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证节点
     */
    validateNode(node) {
        const errors = [];
        // 使用模板定义的约束，undefined 表示无限制
        const maxChildren = (node.template.maxChildren ?? Infinity);
        const actualChildren = node.children.length;
        if (actualChildren > maxChildren) {
            if (node.isRoot()) {
                errors.push({
                    message: '根节点只能连接一个子节点',
                    nodeId: node.id,
                    field: 'children'
                });
            }
            else if (node.nodeType.isDecorator()) {
                errors.push({
                    message: '装饰节点只能连接一个子节点',
                    nodeId: node.id,
                    field: 'children'
                });
            }
            else if (node.nodeType.isLeaf()) {
                errors.push({
                    message: '叶子节点不能有子节点',
                    nodeId: node.id,
                    field: 'children'
                });
            }
            else {
                errors.push({
                    message: `节点子节点数量 (${actualChildren}) 超过最大限制 (${maxChildren})`,
                    nodeId: node.id,
                    field: 'children'
                });
            }
        }
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证连接
     */
    validateConnection(connection, tree) {
        const errors = [];
        if (!tree.hasNode(connection.from)) {
            errors.push({
                message: `源节点不存在: ${connection.from}`,
                nodeId: connection.from
            });
        }
        if (!tree.hasNode(connection.to)) {
            errors.push({
                message: `目标节点不存在: ${connection.to}`,
                nodeId: connection.to
            });
        }
        if (connection.from === connection.to) {
            errors.push({
                message: '节点不能连接到自己',
                nodeId: connection.from
            });
        }
        if (tree.hasNode(connection.from) && tree.hasNode(connection.to)) {
            const fromNode = tree.getNode(connection.from);
            const toNode = tree.getNode(connection.to);
            if (connection.isNodeConnection()) {
                if (!fromNode.canAddChild()) {
                    errors.push({
                        message: `节点 ${connection.from} 无法添加更多子节点`,
                        nodeId: connection.from
                    });
                }
                if (toNode.nodeType.isLeaf() && toNode.hasChildren()) {
                    errors.push({
                        message: `叶子节点 ${connection.to} 不能有子节点`,
                        nodeId: connection.to
                    });
                }
            }
        }
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证是否存在循环引用
     */
    validateNoCycles(tree) {
        const errors = [];
        const visited = new Set();
        const recursionStack = new Set();
        const dfs = (nodeId) => {
            if (recursionStack.has(nodeId)) {
                errors.push({
                    message: `检测到循环引用: 节点 ${nodeId}`,
                    nodeId
                });
                return true;
            }
            if (visited.has(nodeId)) {
                return false;
            }
            visited.add(nodeId);
            recursionStack.add(nodeId);
            const node = tree.getNode(nodeId);
            for (const childId of node.children) {
                if (dfs(childId)) {
                    return true;
                }
            }
            recursionStack.delete(nodeId);
            return false;
        };
        if (tree.rootNodeId) {
            dfs(tree.rootNodeId);
        }
        tree.nodes.forEach((node) => {
            if (!visited.has(node.id) && !node.isRoot()) {
                dfs(node.id);
            }
        });
        return {
            isValid: errors.length === 0,
            errors
        };
    }
}

/**
 * 创建节点命令
 */
class CreateNodeCommand extends BaseCommand {
    constructor(state, node) {
        super();
        this.state = state;
        this.node = node;
        this.createdNodeId = node.id;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.addNode(this.node);
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.removeNode(this.createdNodeId);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `创建节点: ${this.node.template.displayName}`;
    }
}

/**
 * 删除节点命令
 */
class DeleteNodeCommand extends BaseCommand {
    constructor(state, nodeId) {
        super();
        this.state = state;
        this.nodeId = nodeId;
        this.deletedNode = null;
    }
    execute() {
        const tree = this.state.getTree();
        this.deletedNode = tree.getNode(this.nodeId);
        const newTree = tree.removeNode(this.nodeId);
        this.state.setTree(newTree);
    }
    undo() {
        if (!this.deletedNode) {
            throw new Error('无法撤销：未保存已删除的节点');
        }
        const tree = this.state.getTree();
        const newTree = tree.addNode(this.deletedNode);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `删除节点: ${this.deletedNode?.template.displayName ?? this.nodeId}`;
    }
}

/**
 * 添加连接命令
 */
class AddConnectionCommand extends BaseCommand {
    constructor(state, connection) {
        super();
        this.state = state;
        this.connection = connection;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.addConnection(this.connection);
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.removeConnection(this.connection.from, this.connection.to, this.connection.fromProperty, this.connection.toProperty);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `添加连接: ${this.connection.from} -> ${this.connection.to}`;
    }
}

/**
 * 移除连接命令
 */
class RemoveConnectionCommand extends BaseCommand {
    constructor(state, from, to, fromProperty, toProperty) {
        super();
        this.state = state;
        this.from = from;
        this.to = to;
        this.fromProperty = fromProperty;
        this.toProperty = toProperty;
        this.removedConnection = null;
    }
    execute() {
        const tree = this.state.getTree();
        const connection = tree.connections.find((c) => c.matches(this.from, this.to, this.fromProperty, this.toProperty));
        if (!connection) {
            throw new Error(`连接不存在: ${this.from} -> ${this.to}`);
        }
        this.removedConnection = connection;
        const newTree = tree.removeConnection(this.from, this.to, this.fromProperty, this.toProperty);
        this.state.setTree(newTree);
    }
    undo() {
        if (!this.removedConnection) {
            throw new Error('无法撤销：未保存已删除的连接');
        }
        const tree = this.state.getTree();
        const newTree = tree.addConnection(this.removedConnection);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `移除连接: ${this.from} -> ${this.to}`;
    }
}

/**
 * 移动节点命令
 * 支持合并连续的移动操作
 */
class MoveNodeCommand extends BaseCommand {
    constructor(state, nodeId, newPosition) {
        super();
        this.state = state;
        this.nodeId = nodeId;
        this.newPosition = newPosition;
        const tree = this.state.getTree();
        const node = tree.getNode(nodeId);
        this.oldPosition = node.position;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.moveToPosition(this.newPosition));
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.moveToPosition(this.oldPosition));
        this.state.setTree(newTree);
    }
    getDescription() {
        return `移动节点: ${this.nodeId}`;
    }
    /**
     * 移动命令可以合并
     */
    canMergeWith(other) {
        if (!(other instanceof MoveNodeCommand)) {
            return false;
        }
        return this.nodeId === other.nodeId;
    }
    /**
     * 合并移动命令
     * 保留初始位置，更新最终位置
     */
    mergeWith(other) {
        if (!(other instanceof MoveNodeCommand)) {
            throw new Error('只能与 MoveNodeCommand 合并');
        }
        if (this.nodeId !== other.nodeId) {
            throw new Error('只能合并同一节点的移动命令');
        }
        const merged = new MoveNodeCommand(this.state, this.nodeId, other.newPosition);
        merged.oldPosition = this.oldPosition;
        return merged;
    }
}

/**
 * 更新节点数据命令
 */
class UpdateNodeDataCommand extends BaseCommand {
    constructor(state, nodeId, newData) {
        super();
        this.state = state;
        this.nodeId = nodeId;
        this.newData = newData;
        const tree = this.state.getTree();
        const node = tree.getNode(nodeId);
        this.oldData = node.data;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.updateData(this.newData));
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.updateNode(this.nodeId, (node) => node.updateData(this.oldData));
        this.state.setTree(newTree);
    }
    getDescription() {
        return `更新节点数据: ${this.nodeId}`;
    }
}

/**
 * 创建节点用例
 */
class CreateNodeUseCase {
    constructor(nodeFactory, commandManager, treeState) {
        this.nodeFactory = nodeFactory;
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 执行创建节点操作
     */
    execute(template, position, data) {
        const node = this.nodeFactory.createNode(template, position, data);
        const command = new CreateNodeCommand(this.treeState, node);
        this.commandManager.execute(command);
        return node;
    }
    /**
     * 根据类型创建节点
     */
    executeByType(nodeType, position, data) {
        const node = this.nodeFactory.createNodeByType(nodeType, position, data);
        const command = new CreateNodeCommand(this.treeState, node);
        this.commandManager.execute(command);
        return node;
    }
}

/**
 * 删除节点用例
 * 删除节点时会自动删除相关连接
 */
class DeleteNodeUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 删除单个节点
     */
    execute(nodeId) {
        const tree = this.treeState.getTree();
        const relatedConnections = tree.connections.filter((conn) => conn.from === nodeId || conn.to === nodeId);
        const commands = [];
        relatedConnections.forEach((conn) => {
            commands.push(new RemoveConnectionCommand(this.treeState, conn.from, conn.to, conn.fromProperty, conn.toProperty));
        });
        commands.push(new DeleteNodeCommand(this.treeState, nodeId));
        this.commandManager.executeBatch(commands);
    }
    /**
     * 批量删除节点
     */
    executeBatch(nodeIds) {
        const tree = this.treeState.getTree();
        const commands = [];
        const nodeIdSet = new Set(nodeIds);
        const relatedConnections = tree.connections.filter((conn) => nodeIdSet.has(conn.from) || nodeIdSet.has(conn.to));
        relatedConnections.forEach((conn) => {
            commands.push(new RemoveConnectionCommand(this.treeState, conn.from, conn.to, conn.fromProperty, conn.toProperty));
        });
        nodeIds.forEach((nodeId) => {
            commands.push(new DeleteNodeCommand(this.treeState, nodeId));
        });
        this.commandManager.executeBatch(commands);
    }
}

/**
 * 添加连接用例
 */
class AddConnectionUseCase {
    constructor(commandManager, treeState, validator) {
        this.commandManager = commandManager;
        this.treeState = treeState;
        this.validator = validator;
    }
    /**
     * 执行添加连接操作
     */
    execute(from, to, connectionType = 'node', fromProperty, toProperty) {
        const connection = new Connection(from, to, connectionType, fromProperty, toProperty);
        const tree = this.treeState.getTree();
        const validationResult = this.validator.validateConnection(connection, tree);
        if (!validationResult.isValid) {
            const errorMessages = validationResult.errors.map((e) => e.message).join(', ');
            throw new Error(`连接验证失败: ${errorMessages}`);
        }
        const command = new AddConnectionCommand(this.treeState, connection);
        this.commandManager.execute(command);
        return connection;
    }
}

/**
 * 移除连接用例
 */
class RemoveConnectionUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 执行移除连接操作
     */
    execute(from, to, fromProperty, toProperty) {
        const command = new RemoveConnectionCommand(this.treeState, from, to, fromProperty, toProperty);
        this.commandManager.execute(command);
    }
}

/**
 * 移动节点用例
 */
class MoveNodeUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 移动单个节点
     */
    execute(nodeId, newPosition) {
        const command = new MoveNodeCommand(this.treeState, nodeId, newPosition);
        this.commandManager.execute(command);
    }
    /**
     * 批量移动节点
     */
    executeBatch(moves) {
        const commands = moves.map(({ nodeId, position }) => new MoveNodeCommand(this.treeState, nodeId, position));
        this.commandManager.executeBatch(commands);
    }
}

/**
 * 更新节点数据用例
 */
class UpdateNodeDataUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 更新节点数据
     */
    execute(nodeId, data) {
        const command = new UpdateNodeDataCommand(this.treeState, nodeId, data);
        this.commandManager.execute(command);
    }
}

/**
 * 验证行为树用例
 */
class ValidateTreeUseCase {
    constructor(validator, treeState) {
        this.validator = validator;
        this.treeState = treeState;
    }
    /**
     * 验证当前行为树
     */
    execute() {
        const tree = this.treeState.getTree();
        return this.validator.validateTree(tree);
    }
    /**
     * 验证并抛出错误（如果验证失败）
     */
    executeAndThrow() {
        const result = this.execute();
        if (!result.isValid) {
            const errorMessages = result.errors.map((e) => e.message).join('\n');
            throw new Error(`行为树验证失败:\n${errorMessages}`);
        }
    }
}

class BlackboardManager {
    constructor() {
        this.initialVariables = {};
        this.currentVariables = {};
    }
    setInitialVariables(variables) {
        this.initialVariables = JSON.parse(JSON.stringify(variables));
    }
    getInitialVariables() {
        return { ...this.initialVariables };
    }
    setCurrentVariables(variables) {
        this.currentVariables = { ...variables };
    }
    getCurrentVariables() {
        return { ...this.currentVariables };
    }
    updateVariable(key, value) {
        this.currentVariables[key] = value;
    }
    restoreInitialVariables() {
        this.currentVariables = { ...this.initialVariables };
        return this.getInitialVariables();
    }
    hasChanges() {
        return JSON.stringify(this.currentVariables) !== JSON.stringify(this.initialVariables);
    }
    clear() {
        this.initialVariables = {};
        this.currentVariables = {};
    }
}

const logger = createLogger('BehaviorTreeExecutor');
/**
 * 行为树执行器
 *
 * 使用新的Runtime架构执行行为树
 */
class BehaviorTreeExecutor {
    constructor() {
        this.entity = null;
        this.runtime = null;
        this.treeData = null;
        this.callback = null;
        this.isRunning = false;
        this.isPaused = false;
        this.executionLogs = [];
        this.lastStatuses = new Map();
        this.persistentStatuses = new Map();
        this.executionOrders = new Map();
        this.tickCount = 0;
        this.nodeIdMap = new Map();
        this.blackboardKeys = [];
        this.rootNodeId = '';
        this.world = new World({ name: 'BehaviorTreeWorld' });
        this.scene = this.world.createScene('BehaviorTreeScene');
        // 尝试获取已存在的 assetManager，如果不存在则创建新的
        try {
            this.assetManager = Core.services.resolve(BehaviorTreeAssetManager);
        }
        catch {
            this.assetManager = new BehaviorTreeAssetManager();
            Core.services.registerInstance(BehaviorTreeAssetManager, this.assetManager);
        }
        this.executionSystem = new BehaviorTreeExecutionSystem();
        this.scene.addSystem(this.executionSystem);
    }
    /**
     * 从编辑器节点构建行为树数据
     */
    buildTree(nodes, rootNodeId, blackboard, connections, callback) {
        this.cleanup();
        this.callback = callback;
        this.treeData = this.convertToTreeData(nodes, rootNodeId, blackboard, connections);
        this.rootNodeId = this.treeData.rootNodeId;
        this.assetManager.loadAsset(this.treeData);
        this.entity = this.scene.createEntity('BehaviorTreeEntity');
        this.runtime = new BehaviorTreeRuntimeComponent();
        // 在添加组件之前设置资产ID和autoStart
        this.runtime.treeAssetId = this.treeData.id;
        this.runtime.autoStart = false;
        this.entity.addComponent(this.runtime);
        if (this.treeData.blackboardVariables) {
            this.blackboardKeys = Array.from(this.treeData.blackboardVariables.keys());
            for (const [key, value] of this.treeData.blackboardVariables.entries()) {
                this.runtime.setBlackboardValue(key, value);
            }
        }
        else {
            this.blackboardKeys = [];
        }
        this.addLog('行为树构建完成', 'info');
    }
    /**
     * 将编辑器节点转换为BehaviorTreeData
     */
    convertToTreeData(nodes, rootNodeId, blackboard, connections) {
        const rootNode = nodes.find((n) => n.id === rootNodeId);
        if (!rootNode) {
            throw new Error('未找到根节点');
        }
        // 如果根节点是编辑器特有的"根节点"且只有一个子节点，使用第一个子节点作为实际根节点
        let actualRootId = rootNodeId;
        if (rootNode.template.displayName === '根节点' && rootNode.children.length === 1) {
            actualRootId = rootNode.children[0];
        }
        const treeData = {
            id: `tree_${Date.now()}`,
            name: 'EditorTree',
            rootNodeId: actualRootId,
            nodes: new Map(),
            blackboardVariables: new Map()
        };
        this.nodeIdMap.clear();
        for (const node of nodes) {
            // 跳过编辑器的虚拟根节点
            if (node.id === rootNodeId && node.template.displayName === '根节点' && rootNode.children.length === 1) {
                continue;
            }
            this.nodeIdMap.set(node.id, node.id);
            const nodeData = {
                id: node.id,
                name: node.template.displayName,
                nodeType: this.convertNodeType(node.template.type),
                implementationType: node.template.className || this.getImplementationType(node.template.displayName),
                config: { ...node.data },
                children: Array.from(node.children)
            };
            treeData.nodes.set(node.id, nodeData);
        }
        // 处理属性连接，转换为 bindings
        for (const conn of connections) {
            if (conn.connectionType === 'property' && conn.toProperty) {
                const targetNodeData = treeData.nodes.get(conn.to);
                const sourceNode = nodes.find((n) => n.id === conn.from);
                if (targetNodeData && sourceNode) {
                    // 检查源节点是否是黑板变量节点
                    if (sourceNode.data.nodeType === 'blackboard-variable') {
                        // 从黑板变量节点获取实际的变量名
                        const variableName = sourceNode.data.variableName;
                        if (variableName) {
                            // 初始化 bindings 如果不存在
                            if (!targetNodeData.bindings) {
                                targetNodeData.bindings = {};
                            }
                            // 添加绑定：属性名 -> 黑板变量名
                            targetNodeData.bindings[conn.toProperty] = variableName;
                        }
                    }
                }
            }
        }
        for (const [key, value] of Object.entries(blackboard)) {
            treeData.blackboardVariables.set(key, value);
        }
        return treeData;
    }
    /**
     * 转换节点类型
     */
    convertNodeType(type) {
        if (type === NodeType$1.Composite)
            return NodeType$1.Composite;
        if (type === NodeType$1.Decorator)
            return NodeType$1.Decorator;
        if (type === NodeType$1.Action)
            return NodeType$1.Action;
        if (type === NodeType$1.Condition)
            return NodeType$1.Condition;
        return NodeType$1.Action;
    }
    /**
     * 根据显示名称获取实现类型
     */
    getImplementationType(displayName) {
        const typeMap = {
            '序列': 'Sequence',
            '选择': 'Selector',
            '并行': 'Parallel',
            '并行选择': 'ParallelSelector',
            '随机序列': 'RandomSequence',
            '随机选择': 'RandomSelector',
            '反转': 'Inverter',
            '重复': 'Repeater',
            '直到成功': 'UntilSuccess',
            '直到失败': 'UntilFail',
            '总是成功': 'AlwaysSucceed',
            '总是失败': 'AlwaysFail',
            '条件装饰器': 'Conditional',
            '冷却': 'Cooldown',
            '超时': 'Timeout',
            '等待': 'Wait',
            '日志': 'Log',
            '设置变量': 'SetBlackboardValue',
            '修改变量': 'ModifyBlackboardValue',
            '自定义动作': 'ExecuteAction',
            '比较变量': 'BlackboardCompare',
            '变量存在': 'BlackboardExists',
            '随机概率': 'RandomProbability',
            '执行条件': 'ExecuteCondition'
        };
        return typeMap[displayName] || displayName;
    }
    /**
     * 开始执行
     */
    start() {
        if (!this.runtime || !this.treeData) {
            logger.error('未构建行为树');
            return;
        }
        this.isRunning = true;
        this.isPaused = false;
        this.executionLogs = [];
        this.lastStatuses.clear();
        this.persistentStatuses.clear();
        this.tickCount = 0;
        this.runtime.resetAllStates();
        this.runtime.isRunning = true;
        this.addLog('开始执行行为树', 'info');
    }
    /**
     * 暂停执行
     */
    pause() {
        this.isPaused = true;
        if (this.runtime) {
            this.runtime.isRunning = false;
        }
    }
    /**
     * 恢复执行
     */
    resume() {
        this.isPaused = false;
        if (this.runtime) {
            this.runtime.isRunning = true;
        }
    }
    /**
     * 停止执行
     */
    stop() {
        this.isRunning = false;
        this.isPaused = false;
        if (this.runtime) {
            this.runtime.isRunning = false;
            this.runtime.resetAllStates();
        }
        this.addLog('行为树已停止', 'info');
    }
    /**
     * 执行一帧
     */
    tick(deltaTime) {
        if (!this.isRunning || this.isPaused || !this.runtime) {
            return;
        }
        Time.update(deltaTime);
        this.tickCount++;
        this.scene.update();
        this.collectExecutionStatus();
    }
    /**
     * 收集所有节点的执行状态
     */
    collectExecutionStatus() {
        if (!this.callback || !this.runtime || !this.treeData)
            return;
        const rootState = this.runtime.getNodeState(this.rootNodeId);
        let rootCurrentStatus = 'idle';
        if (rootState) {
            switch (rootState.status) {
                case TaskStatus.Running:
                    rootCurrentStatus = 'running';
                    break;
                case TaskStatus.Success:
                    rootCurrentStatus = 'success';
                    break;
                case TaskStatus.Failure:
                    rootCurrentStatus = 'failure';
                    break;
                default:
                    rootCurrentStatus = 'idle';
            }
        }
        const rootLastStatus = this.lastStatuses.get(this.rootNodeId);
        if (rootLastStatus &&
            (rootLastStatus === 'success' || rootLastStatus === 'failure') &&
            rootCurrentStatus === 'running') {
            this.persistentStatuses.clear();
            this.executionOrders.clear();
        }
        const statuses = [];
        for (const [nodeId, nodeData] of this.treeData.nodes.entries()) {
            const state = this.runtime.getNodeState(nodeId);
            let currentStatus = 'idle';
            if (state) {
                switch (state.status) {
                    case TaskStatus.Success:
                        currentStatus = 'success';
                        break;
                    case TaskStatus.Failure:
                        currentStatus = 'failure';
                        break;
                    case TaskStatus.Running:
                        currentStatus = 'running';
                        break;
                    default:
                        currentStatus = 'idle';
                }
            }
            const persistentStatus = this.persistentStatuses.get(nodeId) || 'idle';
            const lastStatus = this.lastStatuses.get(nodeId);
            let displayStatus = currentStatus;
            if (currentStatus === 'running') {
                displayStatus = 'running';
                this.persistentStatuses.set(nodeId, 'running');
            }
            else if (currentStatus === 'success') {
                displayStatus = 'success';
                this.persistentStatuses.set(nodeId, 'success');
            }
            else if (currentStatus === 'failure') {
                displayStatus = 'failure';
                this.persistentStatuses.set(nodeId, 'failure');
            }
            else if (currentStatus === 'idle') {
                if (persistentStatus !== 'idle') {
                    displayStatus = persistentStatus;
                }
                else if (this.executionOrders.has(nodeId)) {
                    displayStatus = 'success';
                    this.persistentStatuses.set(nodeId, 'success');
                }
                else {
                    displayStatus = 'idle';
                }
            }
            // 检测状态变化
            const hasStateChanged = lastStatus !== currentStatus;
            // 从运行时状态读取执行顺序
            if (state?.executionOrder !== undefined && !this.executionOrders.has(nodeId)) {
                this.executionOrders.set(nodeId, state.executionOrder);
                console.log(`[ExecutionOrder READ] ${nodeData.name} | ID: ${nodeId} | Order: ${state.executionOrder}`);
            }
            // 记录状态变化日志
            if (hasStateChanged && currentStatus !== 'idle') {
                this.onNodeStatusChanged(nodeId, nodeData.name, lastStatus || 'idle', currentStatus);
            }
            this.lastStatuses.set(nodeId, currentStatus);
            statuses.push({
                nodeId,
                status: displayStatus,
                executionOrder: this.executionOrders.get(nodeId)
            });
        }
        const currentBlackboardVars = this.getBlackboardVariables();
        this.callback(statuses, this.executionLogs, currentBlackboardVars);
    }
    /**
     * 节点状态变化时记录日志
     */
    onNodeStatusChanged(nodeId, nodeName, oldStatus, newStatus) {
        if (newStatus === 'running') {
            this.addLog(`[${nodeName}](${nodeId}) 开始执行`, 'info', nodeId);
        }
        else if (newStatus === 'success') {
            this.addLog(`[${nodeName}](${nodeId}) 执行成功`, 'success', nodeId);
        }
        else if (newStatus === 'failure') {
            this.addLog(`[${nodeName}](${nodeId}) 执行失败`, 'error', nodeId);
        }
    }
    /**
     * 添加日志
     */
    addLog(message, level, nodeId) {
        this.executionLogs.push({
            timestamp: Date.now(),
            message,
            level,
            nodeId
        });
        if (this.executionLogs.length > 1000) {
            this.executionLogs.shift();
        }
    }
    /**
     * 获取当前tick计数
     */
    getTickCount() {
        return this.tickCount;
    }
    /**
     * 获取黑板变量
     */
    getBlackboardVariables() {
        if (!this.runtime)
            return {};
        const variables = {};
        for (const name of this.blackboardKeys) {
            variables[name] = this.runtime.getBlackboardValue(name);
        }
        return variables;
    }
    /**
     * 更新黑板变量
     */
    updateBlackboardVariable(key, value) {
        if (!this.runtime) {
            logger.warn('无法更新黑板变量：未构建行为树');
            return;
        }
        this.runtime.setBlackboardValue(key, value);
        logger.info(`黑板变量已更新: ${key} = ${JSON.stringify(value)}`);
    }
    /**
     * 清理资源
     */
    cleanup() {
        this.stop();
        this.nodeIdMap.clear();
        this.lastStatuses.clear();
        this.persistentStatuses.clear();
        this.blackboardKeys = [];
        if (this.entity) {
            this.entity.destroy();
            this.entity = null;
        }
        // 卸载旧的行为树资产
        if (this.treeData) {
            this.assetManager.unloadAsset(this.treeData.id);
        }
        this.runtime = null;
        this.treeData = null;
    }
    /**
     * 检查节点的执行器是否存在
     */
    hasExecutor(implementationType) {
        const registry = this.executionSystem.getExecutorRegistry();
        return registry.has(implementationType);
    }
    /**
     * 销毁
     */
    destroy() {
        this.cleanup();
    }
}

class DOMCache {
    constructor() {
        this.nodeElements = new Map();
        this.connectionElements = new Map();
        this.lastNodeStatus = new Map();
        this.statusTimers = new Map();
    }
    getNode(nodeId) {
        let element = this.nodeElements.get(nodeId);
        if (!element) {
            element = document.querySelector(`[data-node-id="${nodeId}"]`) || undefined;
            if (element) {
                this.nodeElements.set(nodeId, element);
            }
        }
        return element;
    }
    getConnection(connectionKey) {
        let element = this.connectionElements.get(connectionKey);
        if (!element) {
            element = document.querySelector(`[data-connection-id="${connectionKey}"]`) || undefined;
            if (element) {
                this.connectionElements.set(connectionKey, element);
            }
        }
        return element;
    }
    getLastStatus(nodeId) {
        return this.lastNodeStatus.get(nodeId);
    }
    setLastStatus(nodeId, status) {
        this.lastNodeStatus.set(nodeId, status);
    }
    hasStatusChanged(nodeId, newStatus) {
        return this.lastNodeStatus.get(nodeId) !== newStatus;
    }
    getStatusTimer(nodeId) {
        return this.statusTimers.get(nodeId);
    }
    setStatusTimer(nodeId, timerId) {
        this.statusTimers.set(nodeId, timerId);
    }
    clearStatusTimer(nodeId) {
        const timerId = this.statusTimers.get(nodeId);
        if (timerId) {
            clearTimeout(timerId);
            this.statusTimers.delete(nodeId);
        }
    }
    clearAllStatusTimers() {
        this.statusTimers.forEach((timerId) => clearTimeout(timerId));
        this.statusTimers.clear();
    }
    clearNodeCache() {
        this.nodeElements.clear();
    }
    clearConnectionCache() {
        this.connectionElements.clear();
    }
    clearStatusCache() {
        this.lastNodeStatus.clear();
    }
    clearAll() {
        this.clearNodeCache();
        this.clearConnectionCache();
        this.clearStatusCache();
        this.clearAllStatusTimers();
    }
    removeNodeClasses(nodeId, ...classes) {
        const element = this.getNode(nodeId);
        if (element) {
            element.classList.remove(...classes);
        }
    }
    addNodeClasses(nodeId, ...classes) {
        const element = this.getNode(nodeId);
        if (element) {
            element.classList.add(...classes);
        }
    }
    hasNodeClass(nodeId, className) {
        const element = this.getNode(nodeId);
        return element?.classList.contains(className) || false;
    }
    setConnectionAttribute(connectionKey, attribute, value) {
        const element = this.getConnection(connectionKey);
        if (element) {
            element.setAttribute(attribute, value);
        }
    }
    getConnectionAttribute(connectionKey, attribute) {
        const element = this.getConnection(connectionKey);
        return element?.getAttribute(attribute) || null;
    }
    forEachNode(callback) {
        this.nodeElements.forEach((element, nodeId) => {
            callback(element, nodeId);
        });
    }
    forEachConnection(callback) {
        this.connectionElements.forEach((element, connectionKey) => {
            callback(element, connectionKey);
        });
    }
}

var EditorEvent;
(function (EditorEvent) {
    EditorEvent["NODE_CREATED"] = "node:created";
    EditorEvent["NODE_DELETED"] = "node:deleted";
    EditorEvent["NODE_UPDATED"] = "node:updated";
    EditorEvent["NODE_MOVED"] = "node:moved";
    EditorEvent["NODE_SELECTED"] = "node:selected";
    EditorEvent["CONNECTION_ADDED"] = "connection:added";
    EditorEvent["CONNECTION_REMOVED"] = "connection:removed";
    EditorEvent["EXECUTION_STARTED"] = "execution:started";
    EditorEvent["EXECUTION_PAUSED"] = "execution:paused";
    EditorEvent["EXECUTION_RESUMED"] = "execution:resumed";
    EditorEvent["EXECUTION_STOPPED"] = "execution:stopped";
    EditorEvent["EXECUTION_TICK"] = "execution:tick";
    EditorEvent["EXECUTION_NODE_STATUS_CHANGED"] = "execution:node_status_changed";
    EditorEvent["TREE_SAVED"] = "tree:saved";
    EditorEvent["TREE_LOADED"] = "tree:loaded";
    EditorEvent["TREE_VALIDATED"] = "tree:validated";
    EditorEvent["BLACKBOARD_VARIABLE_UPDATED"] = "blackboard:variable_updated";
    EditorEvent["BLACKBOARD_RESTORED"] = "blackboard:restored";
    EditorEvent["CANVAS_ZOOM_CHANGED"] = "canvas:zoom_changed";
    EditorEvent["CANVAS_PAN_CHANGED"] = "canvas:pan_changed";
    EditorEvent["CANVAS_RESET"] = "canvas:reset";
    EditorEvent["COMMAND_EXECUTED"] = "command:executed";
    EditorEvent["COMMAND_UNDONE"] = "command:undone";
    EditorEvent["COMMAND_REDONE"] = "command:redone";
})(EditorEvent || (EditorEvent = {}));
class EditorEventBus {
    constructor() {
        this.listeners = new Map();
        this.eventHistory = [];
        this.maxHistorySize = 100;
    }
    on(event, handler) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event).add(handler);
        return {
            unsubscribe: () => this.off(event, handler)
        };
    }
    once(event, handler) {
        const wrappedHandler = (data) => {
            handler(data);
            this.off(event, wrappedHandler);
        };
        return this.on(event, wrappedHandler);
    }
    off(event, handler) {
        const handlers = this.listeners.get(event);
        if (handlers) {
            handlers.delete(handler);
            if (handlers.size === 0) {
                this.listeners.delete(event);
            }
        }
    }
    emit(event, data) {
        if (this.eventHistory.length >= this.maxHistorySize) {
            this.eventHistory.shift();
        }
        this.eventHistory.push({
            event,
            data,
            timestamp: Date.now()
        });
        const handlers = this.listeners.get(event);
        if (handlers) {
            handlers.forEach((handler) => {
                try {
                    handler(data);
                }
                catch (error) {
                    console.error(`Error in event handler for ${event}:`, error);
                }
            });
        }
    }
    clear(event) {
        if (event) {
            this.listeners.delete(event);
        }
        else {
            this.listeners.clear();
        }
    }
    getListenerCount(event) {
        return this.listeners.get(event)?.size || 0;
    }
    getAllEvents() {
        return Array.from(this.listeners.keys());
    }
    getEventHistory(count) {
        if (count) {
            return this.eventHistory.slice(-count);
        }
        return [...this.eventHistory];
    }
    clearHistory() {
        this.eventHistory = [];
    }
}
let globalEventBus = null;
function getGlobalEventBus() {
    if (!globalEventBus) {
        globalEventBus = new EditorEventBus();
    }
    return globalEventBus;
}
function resetGlobalEventBus() {
    globalEventBus = null;
}

class ExecutionController {
    constructor(config) {
        this.executor = null;
        this.mode = 'idle';
        this.animationFrameId = null;
        this.lastTickTime = 0;
        this.speed = 1.0;
        this.tickCount = 0;
        this.domCache = new DOMCache();
        this.currentNodes = [];
        this.currentConnections = [];
        this.currentBlackboard = {};
        this.stepByStepMode = true;
        this.pendingStatusUpdates = [];
        this.currentlyDisplayedIndex = 0;
        this.lastStepTime = 0;
        this.stepInterval = 200;
        this.config = config;
        this.executor = new BehaviorTreeExecutor();
        this.eventBus = config.eventBus;
        this.hooksManager = config.hooksManager;
    }
    getMode() {
        return this.mode;
    }
    getTickCount() {
        return this.tickCount;
    }
    getSpeed() {
        return this.speed;
    }
    setSpeed(speed) {
        this.speed = speed;
        this.lastTickTime = 0;
    }
    async play(nodes, blackboardVariables, connections) {
        if (this.mode === 'running')
            return;
        this.currentNodes = nodes;
        this.currentConnections = connections;
        this.currentBlackboard = blackboardVariables;
        const context = {
            nodes,
            connections,
            blackboardVariables,
            rootNodeId: this.config.rootNodeId,
            tickCount: 0
        };
        try {
            await this.hooksManager?.triggerBeforePlay(context);
            this.mode = 'running';
            this.tickCount = 0;
            this.lastTickTime = 0;
            if (!this.executor) {
                this.executor = new BehaviorTreeExecutor();
            }
            this.executor.buildTree(nodes, this.config.rootNodeId, blackboardVariables, connections, this.handleExecutionStatusUpdate.bind(this));
            this.executor.start();
            this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
            this.eventBus?.emit(EditorEvent.EXECUTION_STARTED, context);
            await this.hooksManager?.triggerAfterPlay(context);
        }
        catch (error) {
            console.error('Error in play:', error);
            await this.hooksManager?.triggerOnError(error, 'play');
            throw error;
        }
    }
    async pause() {
        try {
            if (this.mode === 'running') {
                await this.hooksManager?.triggerBeforePause();
                this.mode = 'paused';
                if (this.executor) {
                    this.executor.pause();
                }
                if (this.animationFrameId !== null) {
                    cancelAnimationFrame(this.animationFrameId);
                    this.animationFrameId = null;
                }
                this.eventBus?.emit(EditorEvent.EXECUTION_PAUSED);
                await this.hooksManager?.triggerAfterPause();
            }
            else if (this.mode === 'paused') {
                await this.hooksManager?.triggerBeforeResume();
                this.mode = 'running';
                this.lastTickTime = 0;
                if (this.executor) {
                    this.executor.resume();
                }
                this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
                this.eventBus?.emit(EditorEvent.EXECUTION_RESUMED);
                await this.hooksManager?.triggerAfterResume();
            }
        }
        catch (error) {
            console.error('Error in pause/resume:', error);
            await this.hooksManager?.triggerOnError(error, 'pause');
            throw error;
        }
    }
    async stop() {
        try {
            await this.hooksManager?.triggerBeforeStop();
            this.mode = 'idle';
            this.tickCount = 0;
            this.lastTickTime = 0;
            this.lastStepTime = 0;
            this.pendingStatusUpdates = [];
            this.currentlyDisplayedIndex = 0;
            this.domCache.clearAllStatusTimers();
            this.domCache.clearStatusCache();
            this.config.onExecutionStatusUpdate(new Map(), new Map());
            if (this.animationFrameId !== null) {
                cancelAnimationFrame(this.animationFrameId);
                this.animationFrameId = null;
            }
            if (this.executor) {
                this.executor.stop();
            }
            this.eventBus?.emit(EditorEvent.EXECUTION_STOPPED);
            await this.hooksManager?.triggerAfterStop();
        }
        catch (error) {
            console.error('Error in stop:', error);
            await this.hooksManager?.triggerOnError(error, 'stop');
            throw error;
        }
    }
    async reset() {
        await this.stop();
        if (this.executor) {
            this.executor.cleanup();
        }
    }
    step() {
        // 单步执行功能预留
    }
    updateBlackboardVariable(key, value) {
        if (this.executor && this.mode !== 'idle') {
            this.executor.updateBlackboardVariable(key, value);
        }
    }
    getBlackboardVariables() {
        if (this.executor) {
            return this.executor.getBlackboardVariables();
        }
        return {};
    }
    updateNodes(nodes) {
        if (this.mode === 'idle' || !this.executor) {
            return;
        }
        this.currentNodes = nodes;
        this.executor.buildTree(nodes, this.config.rootNodeId, this.currentBlackboard, this.currentConnections, this.handleExecutionStatusUpdate.bind(this));
        this.executor.start();
    }
    clearDOMCache() {
        this.domCache.clearAll();
    }
    destroy() {
        this.stop();
        if (this.executor) {
            this.executor.destroy();
            this.executor = null;
        }
    }
    tickLoop(currentTime) {
        if (this.mode !== 'running') {
            return;
        }
        if (!this.executor) {
            return;
        }
        if (this.stepByStepMode) {
            this.handleStepByStepExecution(currentTime);
        }
        else {
            this.handleNormalExecution(currentTime);
        }
        this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
    }
    handleNormalExecution(currentTime) {
        const baseTickInterval = 16.67;
        const scaledTickInterval = baseTickInterval / this.speed;
        if (this.lastTickTime === 0) {
            this.lastTickTime = currentTime;
        }
        const elapsed = currentTime - this.lastTickTime;
        if (elapsed >= scaledTickInterval) {
            const deltaTime = baseTickInterval / 1000;
            this.executor.tick(deltaTime);
            this.tickCount = this.executor.getTickCount();
            this.config.onTickCountUpdate(this.tickCount);
            this.lastTickTime = currentTime;
        }
    }
    handleStepByStepExecution(currentTime) {
        if (this.lastStepTime === 0) {
            this.lastStepTime = currentTime;
        }
        const stepElapsed = currentTime - this.lastStepTime;
        const actualStepInterval = this.stepInterval / this.speed;
        if (stepElapsed >= actualStepInterval) {
            if (this.currentlyDisplayedIndex < this.pendingStatusUpdates.length) {
                this.displayNextNode();
                this.lastStepTime = currentTime;
            }
            else {
                if (this.lastTickTime === 0) {
                    this.lastTickTime = currentTime;
                }
                const tickElapsed = currentTime - this.lastTickTime;
                const baseTickInterval = 16.67;
                const scaledTickInterval = baseTickInterval / this.speed;
                if (tickElapsed >= scaledTickInterval) {
                    const deltaTime = baseTickInterval / 1000;
                    this.executor.tick(deltaTime);
                    this.tickCount = this.executor.getTickCount();
                    this.config.onTickCountUpdate(this.tickCount);
                    this.lastTickTime = currentTime;
                }
            }
        }
    }
    displayNextNode() {
        if (this.currentlyDisplayedIndex >= this.pendingStatusUpdates.length) {
            return;
        }
        const statusesToDisplay = this.pendingStatusUpdates.slice(0, this.currentlyDisplayedIndex + 1);
        const currentNode = this.pendingStatusUpdates[this.currentlyDisplayedIndex];
        if (!currentNode) {
            return;
        }
        const statusMap = new Map();
        const orderMap = new Map();
        statusesToDisplay.forEach((s) => {
            statusMap.set(s.nodeId, s.status);
            if (s.executionOrder !== undefined) {
                orderMap.set(s.nodeId, s.executionOrder);
            }
        });
        const nodeName = this.currentNodes.find(n => n.id === currentNode.nodeId)?.template.displayName || 'Unknown';
        console.log(`[StepByStep] Displaying ${this.currentlyDisplayedIndex + 1}/${this.pendingStatusUpdates.length} | ${nodeName} | Order: ${currentNode.executionOrder} | ID: ${currentNode.nodeId}`);
        this.config.onExecutionStatusUpdate(statusMap, orderMap);
        this.currentlyDisplayedIndex++;
    }
    handleExecutionStatusUpdate(statuses, logs, runtimeBlackboardVars) {
        this.config.onLogsUpdate([...logs]);
        if (runtimeBlackboardVars) {
            this.config.onBlackboardUpdate(runtimeBlackboardVars);
        }
        if (this.stepByStepMode) {
            const statusesWithOrder = statuses.filter(s => s.executionOrder !== undefined);
            if (statusesWithOrder.length > 0) {
                const minOrder = Math.min(...statusesWithOrder.map(s => s.executionOrder));
                if (minOrder === 1 || this.pendingStatusUpdates.length === 0) {
                    this.pendingStatusUpdates = statusesWithOrder.sort((a, b) => (a.executionOrder || 0) - (b.executionOrder || 0));
                    this.currentlyDisplayedIndex = 0;
                    this.lastStepTime = 0;
                }
                else {
                    const maxExistingOrder = this.pendingStatusUpdates.length > 0
                        ? Math.max(...this.pendingStatusUpdates.map(s => s.executionOrder || 0))
                        : 0;
                    const newStatuses = statusesWithOrder.filter(s => (s.executionOrder || 0) > maxExistingOrder);
                    if (newStatuses.length > 0) {
                        console.log(`[StepByStep] Appending ${newStatuses.length} new nodes, orders:`, newStatuses.map(s => s.executionOrder));
                        this.pendingStatusUpdates = [
                            ...this.pendingStatusUpdates,
                            ...newStatuses
                        ].sort((a, b) => (a.executionOrder || 0) - (b.executionOrder || 0));
                    }
                }
            }
        }
        else {
            const statusMap = new Map();
            const orderMap = new Map();
            statuses.forEach((s) => {
                statusMap.set(s.nodeId, s.status);
                if (s.executionOrder !== undefined) {
                    orderMap.set(s.nodeId, s.executionOrder);
                }
            });
            this.config.onExecutionStatusUpdate(statusMap, orderMap);
        }
    }
    updateConnectionStyles(statusMap, connections) {
        if (!connections)
            return;
        connections.forEach((conn) => {
            const connKey = `${conn.from}-${conn.to}`;
            const pathElement = this.domCache.getConnection(connKey);
            if (!pathElement) {
                return;
            }
            const fromStatus = statusMap[conn.from];
            const toStatus = statusMap[conn.to];
            const isActive = fromStatus === 'running' || toStatus === 'running';
            if (conn.connectionType === 'property') {
                this.domCache.setConnectionAttribute(connKey, 'stroke', '#9c27b0');
                this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2');
            }
            else if (isActive) {
                this.domCache.setConnectionAttribute(connKey, 'stroke', '#ffa726');
                this.domCache.setConnectionAttribute(connKey, 'stroke-width', '3');
            }
            else {
                const isExecuted = this.domCache.hasNodeClass(conn.from, 'executed') &&
                    this.domCache.hasNodeClass(conn.to, 'executed');
                if (isExecuted) {
                    this.domCache.setConnectionAttribute(connKey, 'stroke', '#4caf50');
                    this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2.5');
                }
                else {
                    this.domCache.setConnectionAttribute(connKey, 'stroke', '#0e639c');
                    this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2');
                }
            }
        });
    }
    setConnections(connections) {
        if (this.mode !== 'idle') {
            const currentStatuses = {};
            connections.forEach((conn) => {
                const fromStatus = this.domCache.getLastStatus(conn.from);
                const toStatus = this.domCache.getLastStatus(conn.to);
                if (fromStatus)
                    currentStatuses[conn.from] = fromStatus;
                if (toStatus)
                    currentStatuses[conn.to] = toStatus;
            });
            this.updateConnectionStyles(currentStatuses, connections);
        }
    }
}

class ExecutionHooksManager {
    constructor() {
        this.hooks = new Set();
    }
    register(hook) {
        this.hooks.add(hook);
    }
    unregister(hook) {
        this.hooks.delete(hook);
    }
    clear() {
        this.hooks.clear();
    }
    async triggerBeforePlay(context) {
        for (const hook of this.hooks) {
            if (hook.beforePlay) {
                try {
                    await hook.beforePlay(context);
                }
                catch (error) {
                    console.error('Error in beforePlay hook:', error);
                }
            }
        }
    }
    async triggerAfterPlay(context) {
        for (const hook of this.hooks) {
            if (hook.afterPlay) {
                try {
                    await hook.afterPlay(context);
                }
                catch (error) {
                    console.error('Error in afterPlay hook:', error);
                }
            }
        }
    }
    async triggerBeforePause() {
        for (const hook of this.hooks) {
            if (hook.beforePause) {
                try {
                    await hook.beforePause();
                }
                catch (error) {
                    console.error('Error in beforePause hook:', error);
                }
            }
        }
    }
    async triggerAfterPause() {
        for (const hook of this.hooks) {
            if (hook.afterPause) {
                try {
                    await hook.afterPause();
                }
                catch (error) {
                    console.error('Error in afterPause hook:', error);
                }
            }
        }
    }
    async triggerBeforeResume() {
        for (const hook of this.hooks) {
            if (hook.beforeResume) {
                try {
                    await hook.beforeResume();
                }
                catch (error) {
                    console.error('Error in beforeResume hook:', error);
                }
            }
        }
    }
    async triggerAfterResume() {
        for (const hook of this.hooks) {
            if (hook.afterResume) {
                try {
                    await hook.afterResume();
                }
                catch (error) {
                    console.error('Error in afterResume hook:', error);
                }
            }
        }
    }
    async triggerBeforeStop() {
        for (const hook of this.hooks) {
            if (hook.beforeStop) {
                try {
                    await hook.beforeStop();
                }
                catch (error) {
                    console.error('Error in beforeStop hook:', error);
                }
            }
        }
    }
    async triggerAfterStop() {
        for (const hook of this.hooks) {
            if (hook.afterStop) {
                try {
                    await hook.afterStop();
                }
                catch (error) {
                    console.error('Error in afterStop hook:', error);
                }
            }
        }
    }
    async triggerBeforeStep(deltaTime) {
        for (const hook of this.hooks) {
            if (hook.beforeStep) {
                try {
                    await hook.beforeStep(deltaTime);
                }
                catch (error) {
                    console.error('Error in beforeStep hook:', error);
                }
            }
        }
    }
    async triggerAfterStep(deltaTime) {
        for (const hook of this.hooks) {
            if (hook.afterStep) {
                try {
                    await hook.afterStep(deltaTime);
                }
                catch (error) {
                    console.error('Error in afterStep hook:', error);
                }
            }
        }
    }
    async triggerOnTick(tickCount, deltaTime) {
        for (const hook of this.hooks) {
            if (hook.onTick) {
                try {
                    await hook.onTick(tickCount, deltaTime);
                }
                catch (error) {
                    console.error('Error in onTick hook:', error);
                }
            }
        }
    }
    async triggerOnNodeStatusChange(event) {
        for (const hook of this.hooks) {
            if (hook.onNodeStatusChange) {
                try {
                    await hook.onNodeStatusChange(event);
                }
                catch (error) {
                    console.error('Error in onNodeStatusChange hook:', error);
                }
            }
        }
    }
    async triggerOnExecutionComplete(logs) {
        for (const hook of this.hooks) {
            if (hook.onExecutionComplete) {
                try {
                    await hook.onExecutionComplete(logs);
                }
                catch (error) {
                    console.error('Error in onExecutionComplete hook:', error);
                }
            }
        }
    }
    async triggerOnBlackboardUpdate(variables) {
        for (const hook of this.hooks) {
            if (hook.onBlackboardUpdate) {
                try {
                    await hook.onBlackboardUpdate(variables);
                }
                catch (error) {
                    console.error('Error in onBlackboardUpdate hook:', error);
                }
            }
        }
    }
    async triggerOnError(error, context) {
        for (const hook of this.hooks) {
            if (hook.onError) {
                try {
                    await hook.onError(error, context);
                }
                catch (err) {
                    console.error('Error in onError hook:', err);
                }
            }
        }
    }
}

/**
 * 撤销/重做功能 Hook
 */
function useCommandHistory() {
    const commandManagerRef = useRef(new CommandManager({
        maxHistorySize: 100,
        autoMerge: true
    }));
    const commandManager = commandManagerRef.current;
    const canUndo = useCallback(() => {
        return commandManager.canUndo();
    }, [commandManager]);
    const canRedo = useCallback(() => {
        return commandManager.canRedo();
    }, [commandManager]);
    const undo = useCallback(() => {
        if (commandManager.canUndo()) {
            commandManager.undo();
        }
    }, [commandManager]);
    const redo = useCallback(() => {
        if (commandManager.canRedo()) {
            commandManager.redo();
        }
    }, [commandManager]);
    const getUndoHistory = useCallback(() => {
        return commandManager.getUndoHistory();
    }, [commandManager]);
    const getRedoHistory = useCallback(() => {
        return commandManager.getRedoHistory();
    }, [commandManager]);
    const clear = useCallback(() => {
        commandManager.clear();
    }, [commandManager]);
    // 键盘快捷键
    useEffect(() => {
        const handleKeyDown = (e) => {
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const isCtrlOrCmd = isMac ? e.metaKey : e.ctrlKey;
            if (isCtrlOrCmd && e.key === 'z') {
                e.preventDefault();
                if (e.shiftKey) {
                    redo();
                }
                else {
                    undo();
                }
            }
            else if (isCtrlOrCmd && e.key === 'y') {
                e.preventDefault();
                redo();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [undo, redo]);
    return useMemo(() => ({
        commandManager,
        canUndo: canUndo(),
        canRedo: canRedo(),
        undo,
        redo,
        getUndoHistory,
        getRedoHistory,
        clear
    }), [commandManager, canUndo, canRedo, undo, redo, getUndoHistory, getRedoHistory, clear]);
}

/**
 * 节点操作 Hook
 */
function useNodeOperations(nodeFactory, validator, commandManager) {
    const treeState = useMemo(() => new TreeStateAdapter(), []);
    const createNodeUseCase = useMemo(() => new CreateNodeUseCase(nodeFactory, commandManager, treeState), [nodeFactory, commandManager, treeState]);
    const deleteNodeUseCase = useMemo(() => new DeleteNodeUseCase(commandManager, treeState), [commandManager, treeState]);
    const moveNodeUseCase = useMemo(() => new MoveNodeUseCase(commandManager, treeState), [commandManager, treeState]);
    const updateNodeDataUseCase = useMemo(() => new UpdateNodeDataUseCase(commandManager, treeState), [commandManager, treeState]);
    const createNode = useCallback((template, position, data) => {
        return createNodeUseCase.execute(template, position, data);
    }, [createNodeUseCase]);
    const createNodeByType = useCallback((nodeType, position, data) => {
        return createNodeUseCase.executeByType(nodeType, position, data);
    }, [createNodeUseCase]);
    const deleteNode = useCallback((nodeId) => {
        deleteNodeUseCase.execute(nodeId);
    }, [deleteNodeUseCase]);
    const deleteNodes = useCallback((nodeIds) => {
        deleteNodeUseCase.executeBatch(nodeIds);
    }, [deleteNodeUseCase]);
    const moveNode = useCallback((nodeId, position) => {
        moveNodeUseCase.execute(nodeId, position);
    }, [moveNodeUseCase]);
    const moveNodes = useCallback((moves) => {
        moveNodeUseCase.executeBatch(moves);
    }, [moveNodeUseCase]);
    const updateNodeData = useCallback((nodeId, data) => {
        updateNodeDataUseCase.execute(nodeId, data);
    }, [updateNodeDataUseCase]);
    return useMemo(() => ({
        createNode,
        createNodeByType,
        deleteNode,
        deleteNodes,
        moveNode,
        moveNodes,
        updateNodeData
    }), [createNode, createNodeByType, deleteNode, deleteNodes, moveNode, moveNodes, updateNodeData]);
}

/**
 * 连接操作 Hook
 */
function useConnectionOperations(validator, commandManager) {
    const treeState = useMemo(() => new TreeStateAdapter(), []);
    const addConnectionUseCase = useMemo(() => new AddConnectionUseCase(commandManager, treeState, validator), [commandManager, treeState, validator]);
    const removeConnectionUseCase = useMemo(() => new RemoveConnectionUseCase(commandManager, treeState), [commandManager, treeState]);
    const addConnection = useCallback((from, to, connectionType = 'node', fromProperty, toProperty) => {
        try {
            return addConnectionUseCase.execute(from, to, connectionType, fromProperty, toProperty);
        }
        catch (error) {
            console.error('添加连接失败:', error);
            throw error;
        }
    }, [addConnectionUseCase]);
    const removeConnection = useCallback((from, to, fromProperty, toProperty) => {
        try {
            removeConnectionUseCase.execute(from, to, fromProperty, toProperty);
        }
        catch (error) {
            console.error('移除连接失败:', error);
            throw error;
        }
    }, [removeConnectionUseCase]);
    return useMemo(() => ({
        addConnection,
        removeConnection
    }), [addConnection, removeConnection]);
}

/**
 * 画布交互 Hook
 * 封装画布的缩放、平移等交互逻辑
 */
function useCanvasInteraction() {
    const { offset: canvasOffset, scale: canvasScale, isPanning, panStart, setOffset: setCanvasOffset, setScale: setCanvasScale, setIsPanning, setPanStart, resetView } = useCanvasStore();
    const handleWheel = useCallback((e) => {
        e.preventDefault();
        const delta = e.deltaY;
        const scaleFactor = 1.1;
        if (delta < 0) {
            setCanvasScale(Math.min(canvasScale * scaleFactor, 3));
        }
        else {
            setCanvasScale(Math.max(canvasScale / scaleFactor, 0.1));
        }
    }, [canvasScale, setCanvasScale]);
    const startPanning = useCallback((clientX, clientY) => {
        setIsPanning(true);
        setPanStart({ x: clientX, y: clientY });
    }, [setIsPanning, setPanStart]);
    const updatePanning = useCallback((clientX, clientY) => {
        if (!isPanning)
            return;
        const dx = clientX - panStart.x;
        const dy = clientY - panStart.y;
        setCanvasOffset({
            x: canvasOffset.x + dx,
            y: canvasOffset.y + dy
        });
        setPanStart({ x: clientX, y: clientY });
    }, [isPanning, panStart, canvasOffset, setCanvasOffset, setPanStart]);
    const stopPanning = useCallback(() => {
        setIsPanning(false);
    }, [setIsPanning]);
    const zoomIn = useCallback(() => {
        setCanvasScale(Math.min(canvasScale * 1.2, 3));
    }, [canvasScale, setCanvasScale]);
    const zoomOut = useCallback(() => {
        setCanvasScale(Math.max(canvasScale / 1.2, 0.1));
    }, [canvasScale, setCanvasScale]);
    const zoomToFit = useCallback(() => {
        resetView();
    }, [resetView]);
    const screenToCanvas = useCallback((screenX, screenY) => {
        return {
            x: (screenX - canvasOffset.x) / canvasScale,
            y: (screenY - canvasOffset.y) / canvasScale
        };
    }, [canvasOffset, canvasScale]);
    const canvasToScreen = useCallback((canvasX, canvasY) => {
        return {
            x: canvasX * canvasScale + canvasOffset.x,
            y: canvasY * canvasScale + canvasOffset.y
        };
    }, [canvasOffset, canvasScale]);
    return useMemo(() => ({
        canvasOffset,
        canvasScale,
        isPanning,
        handleWheel,
        startPanning,
        updatePanning,
        stopPanning,
        zoomIn,
        zoomOut,
        zoomToFit,
        screenToCanvas,
        canvasToScreen
    }), [
        canvasOffset,
        canvasScale,
        isPanning,
        handleWheel,
        startPanning,
        updatePanning,
        stopPanning,
        zoomIn,
        zoomOut,
        zoomToFit,
        screenToCanvas,
        canvasToScreen
    ]);
}

/**
 * 默认编辑器配置
 */
const DEFAULT_EDITOR_CONFIG = {
    enableSnapping: true,
    gridSize: 20,
    minZoom: 0.1,
    maxZoom: 3,
    showGrid: true,
    showMinimap: false
};

/**
 * 生成唯一ID
 */
function generateUniqueId() {
    return `node-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
/**
 * 节点工厂实现
 */
class NodeFactory {
    /**
     * 创建节点
     */
    createNode(template, position, data) {
        const nodeId = generateUniqueId();
        const nodeData = {
            ...template.defaultConfig,
            ...data
        };
        return new Node(nodeId, template, nodeData, position, []);
    }
    /**
     * 根据模板类型创建节点
     */
    createNodeByType(nodeType, position, data) {
        const template = this.getTemplateByType(nodeType);
        if (!template) {
            throw new Error(`未找到节点模板: ${nodeType}`);
        }
        return this.createNode(template, position, data);
    }
    /**
     * 克隆节点
     */
    cloneNode(node, newPosition) {
        const position = newPosition || node.position;
        const clonedId = generateUniqueId();
        return new Node(clonedId, node.template, node.data, position, []);
    }
    /**
     * 根据类型获取模板
     */
    getTemplateByType(nodeType) {
        const allTemplates = NodeTemplates.getAllTemplates();
        const template = allTemplates.find((t) => {
            const defaultNodeType = t.defaultConfig.nodeType;
            return defaultNodeType === nodeType;
        });
        return template || null;
    }
}

/**
 * 行为树序列化器实现
 */
class BehaviorTreeSerializer {
    constructor(options = {}) {
        this.options = options;
        this.defaultOptions = {
            version: '1.0.0',
            name: 'Untitled Behavior Tree',
            description: '',
            createdAt: new Date().toISOString(),
            modifiedAt: new Date().toISOString()
        };
        this.defaultOptions = { ...this.defaultOptions, ...options };
    }
    /**
     * 序列化行为树
     */
    serialize(tree, format) {
        const treeObject = tree.toObject();
        if (format === 'json') {
            return JSON.stringify(treeObject, null, 2);
        }
        throw new Error(`不支持的序列化格式: ${format}`);
    }
    /**
     * 反序列化行为树
     */
    deserialize(data, format) {
        if (format === 'json') {
            if (typeof data !== 'string') {
                throw new Error('JSON 格式需要字符串数据');
            }
            const obj = JSON.parse(data);
            return BehaviorTree.fromObject(obj);
        }
        throw new Error(`不支持的反序列化格式: ${format}`);
    }
    /**
     * 导出为运行时资产格式
     * @param tree 行为树
     * @param format 导出格式
     * @param options 可选的序列化选项（覆盖默认值）
     */
    exportToRuntimeAsset(tree, format, options) {
        const nodes = tree.nodes.map((node) => ({
            id: node.id,
            template: node.template,
            data: node.data,
            position: node.position.toObject(),
            children: Array.from(node.children)
        }));
        const connections = tree.connections.map((conn) => conn.toObject());
        const blackboard = tree.blackboard.toObject();
        const finalOptions = { ...this.defaultOptions, ...options };
        finalOptions.modifiedAt = new Date().toISOString();
        const editorFormat = {
            version: finalOptions.version,
            metadata: {
                name: finalOptions.name,
                description: finalOptions.description,
                createdAt: finalOptions.createdAt,
                modifiedAt: finalOptions.modifiedAt
            },
            nodes,
            connections,
            blackboard
        };
        const asset = EditorFormatConverter.toAsset(editorFormat);
        if (format === 'json') {
            return BehaviorTreeAssetSerializer.serialize(asset, { format: 'json', pretty: true });
        }
        else if (format === 'binary') {
            return BehaviorTreeAssetSerializer.serialize(asset, { format: 'binary' });
        }
        throw new Error(`不支持的导出格式: ${format}`);
    }
}

/**
 * 行为树验证器实现
 */
class BehaviorTreeValidator {
    /**
     * 验证整个行为树
     */
    validateTree(tree) {
        const errors = [];
        // 验证所有节点
        for (const node of tree.nodes) {
            const nodeResult = this.validateNode(node);
            errors.push(...nodeResult.errors);
        }
        // 验证所有连接
        for (const connection of tree.connections) {
            const connResult = this.validateConnection(connection, tree);
            errors.push(...connResult.errors);
        }
        // 验证循环引用
        const cycleResult = this.validateNoCycles(tree);
        errors.push(...cycleResult.errors);
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证节点
     */
    validateNode(node) {
        const errors = [];
        // 验证节点必填字段
        if (!node.id) {
            errors.push({
                message: '节点 ID 不能为空',
                nodeId: node.id
            });
        }
        if (!node.template) {
            errors.push({
                message: '节点模板不能为空',
                nodeId: node.id
            });
        }
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证连接
     */
    validateConnection(connection, tree) {
        const errors = [];
        // 验证连接的源节点和目标节点都存在
        const fromNode = tree.nodes.find((n) => n.id === connection.from);
        const toNode = tree.nodes.find((n) => n.id === connection.to);
        if (!fromNode) {
            errors.push({
                message: `连接的源节点不存在: ${connection.from}`
            });
        }
        if (!toNode) {
            errors.push({
                message: `连接的目标节点不存在: ${connection.to}`
            });
        }
        // 不能自己连接自己
        if (connection.from === connection.to) {
            errors.push({
                message: '节点不能连接到自己',
                nodeId: connection.from
            });
        }
        return {
            isValid: errors.length === 0,
            errors
        };
    }
    /**
     * 验证是否会产生循环引用
     */
    validateNoCycles(tree) {
        const errors = [];
        const visited = new Set();
        const recursionStack = new Set();
        const hasCycle = (nodeId) => {
            if (recursionStack.has(nodeId)) {
                return true;
            }
            if (visited.has(nodeId)) {
                return false;
            }
            visited.add(nodeId);
            recursionStack.add(nodeId);
            const node = tree.nodes.find((n) => n.id === nodeId);
            if (node) {
                for (const childId of node.children) {
                    if (hasCycle(childId)) {
                        return true;
                    }
                }
            }
            recursionStack.delete(nodeId);
            return false;
        };
        for (const node of tree.nodes) {
            if (hasCycle(node.id)) {
                errors.push({
                    message: '行为树中存在循环引用',
                    nodeId: node.id
                });
                break;
            }
        }
        return {
            isValid: errors.length === 0,
            errors
        };
    }
}

/**
 * 获取端口在画布逻辑坐标系中的位置
 * 画布逻辑坐标：与 node.position 一致的坐标系，未经过 transform 的逻辑坐标
 *
 * @returns 端口中心点的画布逻辑坐标，如果端口不存在则返回 null
 */
function getPortPosition(canvasRef, canvasOffset, canvasScale, nodes, nodeId, propertyName, portType = 'output') {
    const canvas = canvasRef.current;
    if (!canvas)
        return null;
    let selector;
    if (propertyName) {
        // 检查是否是黑板变量的 __value__ 端口
        if (propertyName === '__value__') {
            selector = `[data-node-id="${nodeId}"][data-port-type="variable-output"]`;
        }
        else {
            // 普通属性端口
            selector = `[data-node-id="${nodeId}"][data-property="${propertyName}"]`;
        }
    }
    else {
        const node = nodes.find((n) => n.id === nodeId);
        if (!node)
            return null;
        if (node.data.nodeType === 'blackboard-variable') {
            selector = `[data-node-id="${nodeId}"][data-port-type="variable-output"]`;
        }
        else {
            if (portType === 'input') {
                selector = `[data-node-id="${nodeId}"][data-port-type="node-input"]`;
            }
            else {
                selector = `[data-node-id="${nodeId}"][data-port-type="node-output"]`;
            }
        }
    }
    const portElement = canvas.querySelector(selector);
    if (!portElement)
        return null;
    const rect = portElement.getBoundingClientRect();
    const canvasRect = canvas.getBoundingClientRect();
    // 步骤1：计算相对于画布容器的坐标（屏幕坐标 -> 容器坐标）
    const containerX = rect.left + rect.width / 2 - canvasRect.left;
    const containerY = rect.top + rect.height / 2 - canvasRect.top;
    // 步骤2：撤销 transform 得到画布逻辑坐标（容器坐标 -> 逻辑坐标）
    // transform: translate(offset.x, offset.y) scale(scale)
    // 逆变换：先减去平移，再除以缩放
    const logicX = (containerX - canvasOffset.x) / canvasScale;
    const logicY = (containerY - canvasOffset.y) / canvasScale;
    return { x: logicX, y: logicY };
}

const ICON_MAP = {
    List,
    GitBranch,
    Layers,
    Shuffle,
    RotateCcw,
    Repeat,
    CheckCircle,
    XCircle,
    CheckCheck,
    HelpCircle,
    Snowflake,
    Timer,
    Clock,
    FileText,
    Edit,
    Calculator,
    Code,
    Equal,
    Dices,
    Settings,
    Database,
    TreePine
};
const ROOT_NODE_TEMPLATE = {
    type: NodeType$1.Composite,
    displayName: '根节点',
    category: '根节点',
    icon: 'TreePine',
    description: '行为树根节点',
    color: '#FFD700',
    defaultConfig: {
        nodeType: 'root'
    },
    properties: []
};

class EditorExtensionRegistry {
    constructor() {
        this.nodeRenderers = new Set();
        this.propertyEditors = new Set();
        this.nodeProviders = new Set();
        this.toolbarButtons = new Set();
        this.panelProviders = new Set();
        this.validators = new Set();
        this.commandProviders = new Set();
    }
    registerNodeRenderer(renderer) {
        this.nodeRenderers.add(renderer);
    }
    unregisterNodeRenderer(renderer) {
        this.nodeRenderers.delete(renderer);
    }
    getNodeRenderer(node) {
        for (const renderer of this.nodeRenderers) {
            if (renderer.canRender(node)) {
                return renderer;
            }
        }
        return undefined;
    }
    registerPropertyEditor(editor) {
        this.propertyEditors.add(editor);
    }
    unregisterPropertyEditor(editor) {
        this.propertyEditors.delete(editor);
    }
    getPropertyEditor(propertyType) {
        for (const editor of this.propertyEditors) {
            if (editor.canEdit(propertyType)) {
                return editor;
            }
        }
        return undefined;
    }
    registerNodeProvider(provider) {
        this.nodeProviders.add(provider);
    }
    unregisterNodeProvider(provider) {
        this.nodeProviders.delete(provider);
    }
    getAllNodeTemplates() {
        const templates = [];
        this.nodeProviders.forEach((provider) => {
            templates.push(...provider.getNodeTemplates());
        });
        return templates;
    }
    registerToolbarButton(button) {
        this.toolbarButtons.add(button);
    }
    unregisterToolbarButton(button) {
        this.toolbarButtons.delete(button);
    }
    getToolbarButtons() {
        return Array.from(this.toolbarButtons).filter((btn) => {
            return btn.isVisible ? btn.isVisible() : true;
        });
    }
    registerPanelProvider(provider) {
        this.panelProviders.add(provider);
    }
    unregisterPanelProvider(provider) {
        this.panelProviders.delete(provider);
    }
    getPanelProviders() {
        return Array.from(this.panelProviders).filter((panel) => {
            return panel.canActivate ? panel.canActivate() : true;
        });
    }
    registerValidator(validator) {
        this.validators.add(validator);
    }
    unregisterValidator(validator) {
        this.validators.delete(validator);
    }
    async validateTree(nodes) {
        const results = [];
        for (const validator of this.validators) {
            try {
                const validationResults = validator.validate(nodes);
                results.push(...validationResults);
            }
            catch (error) {
                console.error(`Error in validator ${validator.name}:`, error);
                results.push({
                    severity: 'error',
                    message: `Validator ${validator.name} failed: ${error}`,
                    code: 'VALIDATOR_ERROR'
                });
            }
        }
        return results;
    }
    registerCommandProvider(provider) {
        this.commandProviders.add(provider);
    }
    unregisterCommandProvider(provider) {
        this.commandProviders.delete(provider);
    }
    getCommandProvider(commandId) {
        for (const provider of this.commandProviders) {
            if (provider.getCommandId() === commandId) {
                return provider;
            }
        }
        return undefined;
    }
    getAllCommandProviders() {
        return Array.from(this.commandProviders);
    }
    clear() {
        this.nodeRenderers.clear();
        this.propertyEditors.clear();
        this.nodeProviders.clear();
        this.toolbarButtons.clear();
        this.panelProviders.clear();
        this.validators.clear();
        this.commandProviders.clear();
    }
}
let globalExtensionRegistry = null;
function getGlobalExtensionRegistry() {
    if (!globalExtensionRegistry) {
        globalExtensionRegistry = new EditorExtensionRegistry();
    }
    return globalExtensionRegistry;
}
function resetGlobalExtensionRegistry() {
    globalExtensionRegistry = null;
}

var index = new BehaviorTreePlugin();

export { AddConnectionCommand, AddConnectionUseCase, BehaviorTree, BehaviorTreeCompiler, BehaviorTreeExecutor, BehaviorTreeModule, BehaviorTreeNodeInspectorProvider, BehaviorTreePlugin, BehaviorTreeSerializer, BehaviorTreeService, BehaviorTreeValidator, Blackboard, BlackboardManager, Connection, CreateNodeCommand, CreateNodeUseCase, DEFAULT_EDITOR_CONFIG, DOMCache, DeleteNodeCommand, DeleteNodeUseCase, DomainError, ValidationError as DomainValidationError, EditorEvent, EditorEventBus, EditorExtensionRegistry, ExecutionController, ExecutionHooksManager, ICON_MAP, MoveNodeCommand, MoveNodeUseCase, Node, NodeFactory, NodeNotFoundError, NodeType, Position, ROOT_NODE_TEMPLATE, RemoveConnectionCommand, RemoveConnectionUseCase, Size, TreeStateAdapter, TreeValidator, UpdateNodeDataCommand, UpdateNodeDataUseCase, ValidateTreeUseCase, index as default, getGlobalEventBus, getGlobalExtensionRegistry, getPortPosition, resetGlobalEventBus, resetGlobalExtensionRegistry, useBehaviorTreeDataStore, useCanvasInteraction, useCanvasStore, useCommandHistory, useConnectionOperations, useExecutionStore, useInteractionStore, useNodeOperations, useSelectionStore, useTreeStore };
//# sourceMappingURL=index.esm.js.map
